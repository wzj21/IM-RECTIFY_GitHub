# Manuscript methods and implementation

This release follows the supplied manuscript while making code provenance and unimplemented experimental components explicit. The manuscript's ethics approvals, patient counts and treatment definitions are author-supplied study descriptions, not facts independently validated by the software.

| Manuscript component | Public implementation | Scope |
|---|---|---|
| Cohort assignment and outcomes | `data.py`, `training.py` | Explicit identity, treatment and task-specific 0/1 labels |
| RNA-defined C1/C2 phenotypes | `omics/01_bulk_transcriptomics.R` | TPM/log2 ssGSEA, consensus clustering and biological C1/C2 orientation |
| limma, WGCNA, enrichment, deconvolution | `omics/01_bulk_transcriptomics.R`, `cibersort_interface.R` | Versioned gene sets and authorized CIBERSORT assets are local inputs |
| Manual 3D primary tumor segmentation | `imaging.py`, `extraction.py` | Manual mask is required for primary feature extraction |
| nnU-Net segmentation | `segmentation.py`, `SEGMENTATION.md` | Independent benchmark interface, not a replacement for manual masks |
| ADC generation | `imaging.py:adc_from_dwi` | Known b-values, log-linear mono-exponential fit, explicit physical units |
| Spatial MRI alignment | `imaging.py:prepare_case` | Physical-space rigid MI reference implementation plus saved transforms and manual QC gate |
| Intratumoral/peritumoral radiomics | `extraction.py` and supplied YAML example | PyRadiomics feature families and physical distance shells |
| Four habitats | `habitats.py` | Patient-local k-means, fixed K=4, deterministic ordering by ADC centre |
| Habitat composition/spatial structure | `habitats.py:spatial_features` | Volumes, proportions, components, entropy/diversity, contact areas and mixing matrix |
| Per-habitat radiomics/cross-habitat contrast | `extraction.py`, `habitats.py` | H1-H4 radiomics, ranges, CV and pairwise differences |
| Patient-level TA-MambaNeXt features | `models/encoder.py`, `encoder_io.py` | Original architecture, 515-D output, trained checkpoint required |
| Habitat-level deep features | `extraction.py` | Apply the verified encoder to each habitat mask; dimension follows checkpoint |
| Spearman, mRMR, L1, bootstrap | `selection.py` | Family-wise selectors fitted only inside each training partition |
| Stage-1 molecular decoder | `training.py`, four MRI fusion models | Positive class C1; decoder choice is locked before downstream testing |
| Stage-2 TNT-pCR prediction | `estimators.py`, six models | Positive class ypT0N0; ICI outcomes excluded from training |
| Nested validation | `training.py` | Patient-level 5 outer folds; inner tuning; optional training-only sigmoid calibration |
| Cross-fitting for both treatment arms | `training.py:outer_splits` | Identical held-out fold model predicts TNT-only and TNT+ICI recipients |
| Institutional and temporal testing | `training.py:apply_locked` | Frozen feature schema, transformation, parameters and threshold |
| AUROC/CI, Brier, calibration, DCA | `evaluation.py` | 1000 patient-stratified bootstrap samples; paired AUROC difference; threshold 0.50 |
| Continuous TNT-score interaction | `interaction.py`, `omics/07_treatment_effect_heterogeneity.R` | Wald interaction, adjusted odds ratios and frozen treatment-specific probability curves |
| CATE, DR quintiles and SHAP | `omics/07_treatment_effect_heterogeneity.R` | Development-fitted grf forests, out-of-bag development inference and external prediction |
| Paired single-cell validation | `omics/08_single_cell_analysis.R` | Seurat, donor-paired composition, CopyKAT, Reactome, CellChat and module scores |
| Trajectory analysis | `omics/08_single_cell_analysis.R:run_tnk_pseudotime` | Optional configurable Slingshot helper with an explicit biological root |
| Multiplex immunofluorescence | Upstream input | Staining and spatial image quantification are not included |

## Architectures

The author-supplied TA-MambaNeXt module uses a 3D ResNet18/50 backbone and three independent refinement taps. A ConvNeXt V2-style block refines stage 2; large-kernel and ConvNeXt blocks refine stage 3; local and global token mixing refine stage 4. Tumor-aware pooling combines global, intratumoral and feature-space peritumoral contexts at each scale. Three scale embeddings are concatenated and projected to 515 learned features. These are 515 learned coordinates, not 512 learned features plus three handcrafted summary statistics.

The Mamba and Transformer global mixers are alternatives. The author architecture can instantiate a fallback, but the research extraction wrapper rejects a requested Mamba checkpoint if Mamba is unavailable. An architecture file alone does not establish the training objective, pretrained data scope or learned weights.

GIFM/TFM use modality-specific `d -> hidden -> latent` branches. GIFM evaluates a shared gate network per token, normalizes scores across modalities with softmax, and feeds the weighted token sum to a classification head. TFM adds CLS and learned modality embeddings, runs a Transformer encoder, and feeds the normalized CLS output to its head. In the public implementation, only fold-local imputation/encoding/scaling precedes these trainable modules.

EFM concatenates fold-selected representations before classification. The public reference uses an inner-tuned logistic or random-forest classifier. LFM fits LR/RF per branch and learns an L2-regularized logistic meta-model from inner-OOF logits, with training-only standardization. The input count varies by modality availability and training-fold feature selection; no single fixed selected feature count is implied.

## Explicit differences from the original scripts

1. Original neural scripts read fixed whole-cohort LASSO tables. The public neural path consumes prescreening inputs as requested in the current manuscript; the original AUCs cannot automatically be attributed to this refactored path.
2. Some original external-validation scripts contain functions that retrain candidates using development data. The public external endpoint only calls frozen prediction and cannot choose a model from external outcomes.
3. Historical scripts can learn fold-specific classification cutoffs and use CRT terminology. This release uses TNT terminology and the manuscript's fixed 0.50 threshold throughout classification evaluation.
4. The full local project contains several habitat generations, including population reference-centre matching and defaults other than K=4. This release makes its K=4 patient-local implementation explicit. It must not be substituted for a different historical extraction lock without regeneration and validation.
5. Original feature-selection scripts include extensive plotting and duplicated utilities. The public code exposes the computational sequence in shared modules; the clinical experiment's full tuning grids and plots are not copied wholesale.

These changes make the public workflow inspectable and method-concordant. They do not retroactively validate an earlier analysis as leakage-free or reproduce its reported numerical results.

