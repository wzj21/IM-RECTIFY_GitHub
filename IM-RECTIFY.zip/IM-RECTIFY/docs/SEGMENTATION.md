# Independent nnU-Net segmentation benchmark

The manuscript's primary masks are manually delineated three-dimensional primary tumors. Automatic segmentation is evaluated independently and must never overwrite primary feature masks.

Export T2WI images and manual labels to a new nnU-Net dataset directory:

```bash
im-rectify nnunet-export --manifest data/segmentation_manifest.csv --output nnUNet_raw/Dataset001_RectalTumor
```

The manifest contains `sample_id,patient_id,case_dir` and uses one baseline image per real patient. The exporter creates `imagesTr`, `labelsTr`, `dataset.json` and a local private case-mapping CSV. For the independent training environment, install the investigator's verified nnU-Net v2 release and configure its raw/preprocessed/results locations. Typical upstream commands are:

```bash
nnUNetv2_plan_and_preprocess -d 1 --verify_dataset_integrity
nnUNetv2_train 1 3d_fullres 0
nnUNetv2_predict -i heldout_images -o heldout_predictions -d 1 -c 3d_fullres -f 0
```

Repeat/ensemble only the folds actually specified by the segmentation study design. Keep the segmentation test population separate from training. Restore predictions to the original physical grid, compare with manual masks, and use `imrectify.segmentation.mask_metrics` for Dice. A training-set Dice is not independent model performance. No segmentation-trained checkpoint or training history is implied by these commands.

