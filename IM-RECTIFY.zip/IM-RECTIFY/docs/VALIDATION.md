# Patient-level validation and locking

## Two distinct outcomes

Stage 1 learns RNA-defined C1/C2. Stage 2 learns observed pCR after TNT only. The labels are not interchangeable. C1 is positive for the IMET decoder; ypT0N0 is positive for TNT-pCR. A high IMET score is evidence of the MRI pattern associated with C1, not direct evidence that ICI benefits that patient.

## Nested cross-fitting

For the internal clinical cohort, real patient identities are assigned to five outer folds jointly across both arms. TNT-only cases are stratified by their observed label; ICI outcomes are ignored even in fold stratification. All records of one patient are assigned together.

For each outer fold:

1. Keep only TNT-only patients from the other folds as outcome-training data.
2. Split those training patients into grouped inner folds.
3. For each candidate, refit imputation, categorical encoding, scaling and the relevant selectors on inner-training patients, then predict the inner validation patients.
4. Select parameters from inner validation performance. Neural epoch count is a candidate setting, not selected on outer-test patients.
5. Optionally obtain training-only OOF probabilities to fit sigmoid calibration.
6. Refit the chosen rule using the outer training TNT-only patients and predict all patients in the outer hold-out, including both arms.

Concatenating these held-out predictions produces continuous `TNT_pCR_score` values for the internal treatment heterogeneity analysis. ICI recipient probabilities estimate the model's TNT-only response prediction; agreement with observed outcomes after ICI is not a standalone validation of TNT-only probability.

LFM uses an additional grouped cross-fitting layer when training its meta-learner. Its base predictions for meta-training are generated without fitting on that same patient's outcome. Feature selection is repeated for those base-training partitions.

## Final locking and external testing

After internal development, the same rules are selected and fitted using all eligible TNT-only development patients. The local generated bundle stores preprocessors, feature names, base models, fusion model, probability calibration and the 0.50 threshold. No study weights are distributed in this public repository.

The final GIFM/TFM epoch count is the median of the counts selected inside the outer-training partitions. Remaining candidate settings are selected within the full development training data, with that epoch count fixed.

`apply_locked` checks feature names and patient overlap and calls prediction only. It does not fit imputers on external data, recalibrate, update weights or select from external AUROC. Evaluation of the TNT-pCR endpoint uses only external TNT-only patients with observed reference pathology.

For stage 1, select the decoder family using the prespecified development comparison, then declare the actual chosen family in the lock configuration. If the largest outer-OOF AUROC is selected after comparing several families, that winner's development estimate has model-selection uncertainty; an independent downstream/external cohort is still needed. This repository does not raise AUROC by searching random seeds and reporting only a favourable run.

## Upstream learned representations

The tabular nested workflow starts from candidate feature tables. To call the entire study nested, learned image encoders, PCA, population habitat references, ComBat and other learned transformations must also respect the relevant train/test boundary. Public extraction defaults to per-patient normalization and habitats; no cohort-wide ComBat/PCA is automatically fitted. The ZIP did not establish a final centre/year ComBat lock, so the release does not claim one was used.

An independently pretrained frozen encoder can be applied to every fold. An encoder fitted on the same evaluation patients, even without outcomes, is not automatically an independent external representation. If image-level training is part of model development, regenerate fold-specific embeddings from training-only encoders rather than using one globally trained table.

## Metrics and inference

Classification metrics use the fixed threshold 0.50. AUROC confidence intervals use stratified patient-level bootstrap of held-out predictions; these intervals are conditional on fitted predictions and do not include full model-retraining uncertainty. Repeated records are averaged to one prediction per real patient for evaluation. The empirical calibration plot is not smoothed into a better-looking curve.

The default is 1000 resamples with percentile limits at 2.5% and 97.5%. Model-pair AUROC differences use identical resampled patients for both models. Undefined precision/NPV draws are omitted and their valid resample counts are reported.

The pCR prediction DCA compares net benefit of selecting patients at a pCR probability threshold; it is not a causal DCA for ICI allocation. `interaction.py` separately fits exploratory logistic interactions with HC3 covariance and bootstrap marginal probability differences. Such observational associations require adequate confounder adjustment and treatment overlap; they do not establish an individualized causal effect. Baseline covariates must be prespecified; post-treatment regimen exposure, pathological stage or treatment-to-surgery consequences cannot be silently included as baseline adjusters.

