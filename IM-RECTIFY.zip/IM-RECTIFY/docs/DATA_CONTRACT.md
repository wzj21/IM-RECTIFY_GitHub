# Data contract

## Identity and outcomes

Every feature table has one unique `sample_id` column. A separate metadata CSV contains:

```csv
sample_id,patient_id,cohort,treatment,label
example_scan_01,example_person_01,internal,0,1
example_scan_02,example_person_02,internal,1,0
```

The rows above describe the format only. The repository contains no actual patient rows. Preserve identifiers as text and preserve leading zeroes. `patient_id` identifies the same real person across all source records and cohorts; deduplicate/enforce a cross-centre identity map before analysis. `sample_id` identifies a single baseline imaging record. Repeated records of one real person must share `patient_id` and remain in one fold; conflicting treatments/outcomes are rejected. Prefer one prespecified baseline record per patient.

| Task | cohort | treatment | label=1 | label=0 |
|---|---|---|---|---|
| Molecular decoding | `molecular` | 0 (unused for this task) | RNA-defined C1 | RNA-defined C2 |
| TNT-pCR development | `internal` | 0 | Observed ypT0N0 | Observed non-pCR |
| Internal ICI recipients | `internal` | 1 | Observed ypT0N0 | Observed non-pCR |
| External/temporal validation | local descriptive name | 0/1 | Observed ypT0N0 | Observed non-pCR |

Missing outcomes remain missing and are excluded from endpoint evaluation, never imputed. TNT+ICI outcomes are not used to fit the TNT-pCR model, its selectors, calibration or hyperparameters.

## Feature tables

`T2WI`, `ADC`, `DCE`, `Clinical` and `IMET` are named branches. Every file is joined by `sample_id`; the metadata order defines prediction order. A missing feature row raises an error by default. `allow_missing_rows=true` must be an explicit development-defined decision, not a repair chosen after seeing external performance.

The extractor emits separate family tables plus `all_features.csv` under each available modality. Aggregate columns carry prefixes such as `intratumoral__`, `peritumoral__`, `habitat__`, `deep__`, `habitat_deep__`. This allows family-wise screening. The filename does not encode a supposedly universal feature count: count is determined by the extraction configuration, software version, valid regions and actual checkpoint dimension, and is recorded during extraction.

Feature CSVs must not contain outcomes, treatment, fold numbers or IDs as numerical predictors. The loader rejects common endpoint/identity field names. Clinical columns must be an explicit pretreatment allowlist. Numeric columns are median-imputed and standardized; categorical columns use training-only mode imputation and one-hot encoding with unknown-level handling. Do not pre-impute an external cohort using its own distribution.

`IMET.csv` contains `sample_id,IMET_score`; `IMET_score=P(C1|MRI)`. Its orientation and decoder artifact must be fixed. For subsequent cohorts it comes from the locked stage-1 model, without any pCR-based refitting.

## Feature-generation provenance

Strict fold-local screening of a precomputed table does not repair a cohort-wide trained image encoder, population habitat model or PCA projection. The public loader requires `feature_provenance=patient_local_or_independently_frozen` for real data. This is an explicit investigator declaration, not proof created by the software.

- Patient-local fixed image operations do not learn from other patients.
- The public habitat example fits each lesion separately, with K=4 fixed and deterministic ADC-based naming.
- A learned encoder used to evaluate a cohort must have been frozen on independent training data or be recomputed separately within the relevant training folds.
- If the encoder, PCA or habitat reference centres were trained on the same evaluation cohort, regenerate fold-specific features and rerun the analysis; do not set the declaration to bypass this requirement.

## Imaging manifest and QC

```csv
sample_id,case_dir
example_scan_01,prepared/example_scan_01
```

`case_dir` is relative to the manifest directory. All input images must be 3D and on the same physical reference grid after preprocessing. The original manual mask must have known T2WI geometry. A matching header or shape alone does not prove anatomical registration.

`data_status.json` records `mask_source=manual`, ADC unit, modality availability and QC. The preprocessing runner initially writes `analysis_ready=false`; an investigator confirms image/ROI overlays and field-of-view coverage before extraction. Missing DCE is never replaced by simulated real-looking features.

## Encoder checkpoint contract

The user-supplied local checkpoint is a dictionary containing:

```python
{
    "config": {...},                    # ExtractorConfig architectural settings
    "state_dict": trained_state_dict,
    "training_provenance": {
        "is_trained": True,
        "data_scope": "describe the actual independent or fold-specific training population",
        "objective": "describe the actual training objective"
    },
    "preprocessing": {
        "input_shape": [D, H, W],
        "crop_margin_mm": actual_margin,
        "normalization": "ROI_zscore"
    }
}
```

Fill these entries from actual training records, not inferred typical values. The public release supplies no such weights. Mamba checkpoints require an actual compatible Mamba implementation; silent fallback is rejected during extraction.

