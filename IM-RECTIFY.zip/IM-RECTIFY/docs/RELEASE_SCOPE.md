# Release scope

Version 0.2.0 includes portable Python MRI/model code and the author-supplied bulk transcriptomic, treatment-effect and single-cell R workflows.

The methods use manual masks, RNA-defined C1/C2, development-only TNT outcome training, patient-level validation and frozen inference. Software verification uses generated inputs only. Real study data, trained weights, final extraction locks and licensed reference assets remain separate inputs.

The example MRI registration, patient-local K=4 habitats and feature configuration are runnable reference settings. Exact study feature counts and numerical results depend on the actual frozen settings and encoder artefacts. The optional Slingshot helper is configurable and does not establish which trajectory method produced historical figures.

Cohort display names are molecular anchoring cohort, training cohort (TNT-only/TNT+ICI), external validation cohort 1, external validation cohort 2, temporal validation cohort and paired single-cell cohort. Machine identifiers are documented in DATA_CONTRACT.md. IMET_score is C1 probability; TNT_pCR_score is TNT-alone pCR probability.

Source fingerprints are in SOURCE_PROVENANCE.json. Verification results are in RELEASE_VERIFICATION.json. No patient data or generated test outputs are included.
