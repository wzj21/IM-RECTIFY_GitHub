# Single-cell RNA-seq: major lineages, T/NK and epithelial subtypes
# Input: a QC- and doublet-filtered Seurat v5 object with RNA raw counts.
# Required cell metadata: sample_id, patient_id, timepoint (Pre/Post),
# phenotype (MRI-predicted C1-like/C2-like). Identifiers stay private.
# Cluster-to-cell-type maps must be curated from marker evidence, not assumed.

suppressPackageStartupMessages({
  library(Seurat)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
})
set.seed(1234)

marker_panels <- list(
  major = c("CD3D", "CD8A", "NKG7", "MS4A1", "MZB1", "EPCAM",
            "COL1A1", "LYZ", "S100A8", "PECAM1", "TPSAB1", "SOX10"),
  tnk = c("CD3D", "CD4", "CD8A", "CCR7", "IL7R", "TCF7", "GZMK",
          "GZMB", "PRF1", "NKG7", "FCGR3A", "FOXP3", "IL2RA",
          "PDCD1", "CXCL13", "TOX", "SLC4A10", "MKI67"),
  epithelial = c("EPCAM", "KRT19", "MUC17", "MUC2", "TFF3",
                 "KRT23", "ASCL2", "UBE2C", "MKI67", "POU2F3",
                 "FEV", "SCGN", "PTPRC")
)

check_input <- function(x) {
  stopifnot(inherits(x, "Seurat"), "RNA" %in% Assays(x))
  cols <- c("sample_id", "patient_id", "timepoint", "phenotype")
  if (!all(cols %in% colnames(x[[]]))) stop("Required metadata columns are missing.")
  m <- x[[]][, cols, drop = FALSE]
  # Historical shorthand is normalized, never treated as an RNA reference label.
  m$phenotype <- sub("^C([12])$", "C\\1-like", as.character(m$phenotype))
  x$phenotype <- m$phenotype
  if (anyNA(m) || any(m$timepoint %notin% c("Pre", "Post")) ||
      any(m$phenotype %notin% c("C1-like", "C2-like")) ||
      !all(c("Pre", "Post") %in% m$timepoint)) {
    stop("Metadata must contain valid, nonmissing timepoints and phenotypes.")
  }
  s <- unique(m)
  if (anyDuplicated(s$sample_id) ||
      anyDuplicated(s[, c("patient_id", "timepoint")]) ||
      any(vapply(split(s$phenotype, s$patient_id),
                 function(z) length(unique(z)) != 1L, logical(1)))) {
    stop("Sample-to-patient/timepoint/phenotype mapping is not one-to-one.")
  }
  if (any(vapply(split(s$timepoint, s$patient_id),
                 function(z) !setequal(z, c("Pre", "Post")), logical(1))))
    stop("The paired analysis requires observed Pre and Post samples for every patient.")
  if (inherits(x[["RNA"]], "Assay5")) x <- JoinLayers(x, assay = "RNA")
  DefaultAssay(x) <- "RNA"
  x
}
`%notin%` <- function(x, table) !(x %in% table)

cluster_cells <- function(x, n_pcs = 20, resolution = 0.2) {
  DefaultAssay(x) <- "RNA"
  x <- NormalizeData(x, verbose = FALSE)
  x <- FindVariableFeatures(x, nfeatures = 2000, verbose = FALSE)
  x <- ScaleData(x, features = VariableFeatures(x), verbose = FALSE)
  k <- min(n_pcs, length(VariableFeatures(x)) - 1L, ncol(x) - 2L)
  if (k < 2L) stop("Too few cells or variable genes for clustering.")
  x <- RunPCA(x, features = VariableFeatures(x), npcs = k, verbose = FALSE)
  x <- FindNeighbors(x, dims = seq_len(k), verbose = FALSE)
  x <- FindClusters(x, resolution = resolution, random.seed = 1234,
                    verbose = FALSE)
  x <- RunUMAP(x, dims = seq_len(k), seed.use = 1234, verbose = FALSE)
  x
}

cluster_markers <- function(x) {
  Idents(x) <- "seurat_clusters"
  FindAllMarkers(x, assay = "RNA", only.pos = TRUE, min.pct = 0.25,
                 logfc.threshold = 0.25, test.use = "wilcox", verbose = FALSE)
}

annotate_clusters <- function(x, map, field) {
  clusters <- as.character(x$seurat_clusters)
  if (is.null(names(map)) || anyDuplicated(names(map)) ||
      any(!unique(clusters) %in% names(map)) || anyNA(map)) {
    stop("Review cluster markers and supply a complete named annotation map.")
  }
  x[[field]] <- unname(as.character(map[clusters]))
  x
}

annotation_plot <- function(x, field, genes) {
  genes <- intersect(genes, rownames(x))
  if (!length(genes)) stop("None of the requested markers are in the object.")
  list(
    umap = DimPlot(x, reduction = "umap", group.by = field,
                   label = TRUE, repel = TRUE) + theme_classic(),
    markers = DotPlot(x, features = genes, group.by = field) + RotatedAxis()
  )
}

# Each cell is counted once; proportions and tests use patients, not cells,
# as independent units. The denominator is the selected lineage per sample.
paired_composition <- function(x, field) {
  m <- x[[]] %>% mutate(cell_state = as.character(.data[[field]]))
  if (anyNA(m$cell_state)) stop("Some cells have no subtype annotation.")
  samples <- distinct(m, sample_id, patient_id, timepoint, phenotype)
  counts <- count(m, sample_id, cell_state, name = "n_cells")
  proportions <- crossing(samples, cell_state = sort(unique(m$cell_state))) %>%
    left_join(counts, by = c("sample_id", "cell_state")) %>%
    mutate(n_cells = replace_na(n_cells, 0L)) %>%
    group_by(sample_id) %>%
    mutate(percentage = 100 * n_cells / sum(n_cells)) %>%
    ungroup()
  paired <- proportions %>%
    select(patient_id, phenotype, timepoint, cell_state, percentage) %>%
    pivot_wider(names_from = timepoint, values_from = percentage) %>%
    filter(!is.na(Pre), !is.na(Post))
  stats <- paired %>% group_by(phenotype, cell_state) %>%
    summarise(n_pairs = n(), median_change = median(Post - Pre),
              p_value = if (n() >= 3L && any(Post != Pre))
                suppressWarnings(wilcox.test(Post, Pre, paired = TRUE,
                                             exact = FALSE)$p.value)
              else NA_real_, .groups = "drop") %>%
    group_by(phenotype) %>%
    mutate(p_adj = p.adjust(p_value, method = "BH")) %>% ungroup()
  list(sample_proportions = proportions, paired = paired, statistics = stats)
}

# CopyKAT: use raw counts and infer CNV separately for each sample.
# Diploid calls are not proof of nonmalignancy; missing calls remain unknown.
# Package-generated private intermediates are retained for explicit manual cleanup.
map_copykat_predictions <- function(pred, cells) {
  if (!all(c("cell.names", "copykat.pred") %in% names(pred)))
    stop("CopyKAT output requires cell.names and copykat.pred columns.")
  if (anyNA(pred$cell.names) || anyDuplicated(pred$cell.names))
    stop("CopyKAT cell identifiers must be observed and unique.")
  if (!length(intersect(cells, pred$cell.names)))
    stop("CopyKAT output has no matching cell.names identifiers.")
  stats::setNames(as.character(pred$copykat.pred[match(cells, pred$cell.names)]), cells)
}

copykat_by_sample <- function(x, normal_labels = c("T/NK cells", "B cell",
                                                  "Fibroblasts", "Endothelial cell")) {
  if (!requireNamespace("copykat", quietly = TRUE)) stop("Install copykat.")
  md <- x[[]]
  predictions <- setNames(rep(NA_character_, ncol(x)), colnames(x))
  for (i in seq_along(unique(md$sample_id))) {
    sid <- unique(md$sample_id)[i]
    cells <- rownames(md)[md$sample_id == sid]
    references <- cells[md[cells, "major_celltype"] %in% normal_labels]
    raw <- as.matrix(GetAssayData(x, assay = "RNA", layer = "counts")[, cells,
                                                                        drop = FALSE])
    run_local <- function() {
      temporary <- tempfile("cnv_")
      dir.create(temporary)
      old <- getwd()
      on.exit(setwd(old), add = TRUE)
      message("Private CopyKAT intermediates retained in: ", temporary)
      setwd(temporary)
      copykat::copykat(rawmat = raw, id.type = "S", ngene.chr = 5,
                      win.size = 25, KS.cut = 0.1, genome = "hg20",
                      norm.cell.names = if (length(references) >= 10L)
                        references else "", sam.name = "analysis",
                      plot.genes = "FALSE", output.seg = "FALSE", n.cores = 1)
    }
    result <- run_local()
    pred <- result$prediction
    if (is.null(pred) || !"copykat.pred" %in% colnames(pred)) {
      stop("CopyKAT did not return valid CNV predictions.")
    }
    predictions[cells] <- map_copykat_predictions(pred, cells)
  }
  x$copykat_prediction <- unname(predictions[colnames(x)])
  x
}

# Enrichment is descriptive for cluster markers, not differential expression
# between patients. Use the expressed-gene universe, without cherry-picking.
reactome_markers <- function(markers, tested_genes) {
  required <- c("clusterProfiler", "ReactomePA", "org.Hs.eg.db")
  if (!all(vapply(required, requireNamespace, logical(1), quietly = TRUE))) {
    stop("Install clusterProfiler, ReactomePA and org.Hs.eg.db.")
  }
  convert <- function(genes) suppressMessages(clusterProfiler::bitr(
    unique(genes), fromType = "SYMBOL", toType = "ENTREZID",
    OrgDb = org.Hs.eg.db::org.Hs.eg.db))
  universe <- convert(tested_genes)$ENTREZID
  if (!length(universe)) stop("No gene IDs mapped to the Reactome universe.")
  results <- lapply(split(markers, markers$cluster), function(z) {
    selected <- z$gene[z$p_val_adj < 0.05 & z$avg_log2FC > 0.25]
    if (length(unique(selected)) < 10L) return(NULL)
    mapped <- convert(selected)$ENTREZID
    if (length(mapped) < 10L) return(NULL)
    enriched <- ReactomePA::enrichPathway(
      gene = unique(mapped), universe = unique(universe), organism = "human",
      pAdjustMethod = "BH", pvalueCutoff = 0.05, readable = TRUE)
    ans <- as.data.frame(enriched)
    if (!nrow(ans)) return(NULL)
    ans$cluster <- as.character(z$cluster[1])
    ans
  })
  bind_rows(results)
}

# CellChat comparisons are pooled exploratory inferences: no manual editing
# of inferred networks and no patient-level causal interpretation.
run_cellchat_groups <- function(x, tnk, epithelial, epithelial_confirmed) {
  if (!requireNamespace("CellChat", quietly = TRUE)) stop("Install CellChat.")
  celltypes <- setNames(paste0("T/NK: ", as.character(tnk$cell_state)), colnames(tnk))
  epi_label <- if (epithelial_confirmed) "CNV-supported epithelial: " else "Epithelial: "
  celltypes[colnames(epithelial)] <- paste0(epi_label, as.character(epithelial$cell_state))
  combined <- subset(x, cells = names(celltypes))
  combined$chat_type <- unname(celltypes[colnames(combined)])
  combined$condition <- paste(combined$phenotype, combined$timepoint, sep = "_")
  conditions <- c("C1-like_Pre", "C1-like_Post", "C2-like_Pre", "C2-like_Post")
  networks <- list()
  for (condition in conditions) {
    cells <- colnames(combined)[combined$condition == condition]
    if (!length(cells)) next
    one <- subset(combined, cells = cells)
    sizes <- table(one$chat_type)
    keep <- names(sizes)[sizes >= 10L]
    if (length(keep) < 2L) next
    one <- subset(one, cells = colnames(one)[one$chat_type %in% keep])
    cc <- CellChat::createCellChat(
      object = GetAssayData(one, assay = "RNA", layer = "data"),
      meta = one[[]], group.by = "chat_type")
    cc@DB <- CellChat::subsetDB(CellChat::CellChatDB.human)
    cc <- CellChat::subsetData(cc)
    cc <- CellChat::identifyOverExpressedGenes(cc)
    cc <- CellChat::identifyOverExpressedInteractions(cc)
    cc <- CellChat::computeCommunProb(cc, type = "triMean",
                                     population.size = FALSE)
    cc <- CellChat::filterCommunication(cc, min.cells = 10)
    cc <- CellChat::computeCommunProbPathway(cc)
    networks[[condition]] <- CellChat::aggregateNet(cc)
  }
  weights <- bind_rows(lapply(names(networks), function(condition) {
    d <- as.data.frame(as.table(networks[[condition]]@net$weight))
    names(d) <- c("sender", "receiver", "strength")
    d$condition <- condition
    d
  }))
  plot <- if (nrow(weights)) ggplot(weights, aes(receiver, sender,
                                                 fill = strength)) +
    geom_tile() + facet_wrap(~condition, nrow = 1) +
    scale_fill_gradient(low = "white", high = "steelblue4") +
    coord_equal() + theme_minimal(base_size = 10) +
    theme(axis.text.x = element_text(angle = 90, hjust = 1)) else NULL
  list(networks = networks, weights = weights, plot = plot)
}

# The three named maps must cover every detected cluster and be reviewed
# against the marker plots. Cluster numbers are dataset-specific.
run_single_cell_analysis <- function(seu, major_map, tnk_map, epithelial_map,
                                     use_copykat = FALSE,
                                     use_reactome = FALSE,
                                     use_cellchat = FALSE,
                                     output_dir = NULL,
                                     pcs = c(major = 20, tnk = 20, epithelial = 15),
                                     resolutions = c(major = 0.2, tnk = 0.4,
                                                     epithelial = 0.2),
                                     functional_gene_sets = NULL,
                                     trajectory_start_state = NULL) {
  x <- check_input(seu)
  major <- cluster_cells(x, pcs[["major"]], resolutions[["major"]])
  major_markers <- cluster_markers(major)
  major <- annotate_clusters(major, major_map, "major_celltype")
  if (use_copykat) major <- copykat_by_sample(major)

  tnk <- subset(major, subset = major_celltype == "T/NK cells")
  tnk <- cluster_cells(tnk, pcs[["tnk"]], resolutions[["tnk"]])
  tnk_markers <- cluster_markers(tnk)
  tnk <- annotate_clusters(tnk, tnk_map, "cell_state")

  epi <- subset(major, subset = major_celltype == "Epithelial cell")
  cnv_confirmed <- "copykat_prediction" %in% colnames(epi[[]])
  if (cnv_confirmed) {
    supported <- colnames(epi)[epi$copykat_prediction == "aneuploid" &
                               !is.na(epi$copykat_prediction)]
    if (length(supported) < 30L) stop("Insufficient CNV-supported epithelial cells.")
    epi <- subset(epi, cells = supported)
  }
  epi <- cluster_cells(epi, pcs[["epithelial"]], resolutions[["epithelial"]])
  epi_markers <- cluster_markers(epi)
  epi <- annotate_clusters(epi, epithelial_map, "cell_state")

  figures <- list(
    major = annotation_plot(major, "major_celltype", marker_panels$major),
    tnk = annotation_plot(tnk, "cell_state", marker_panels$tnk),
    epithelial = annotation_plot(epi, "cell_state", marker_panels$epithelial)
  )
  proportions <- list(
    major = paired_composition(major, "major_celltype"),
    tnk = paired_composition(tnk, "cell_state"),
    epithelial = paired_composition(epi, "cell_state")
  )
  enrichment <- if (use_reactome) {
    expressed <- rownames(epi)[Matrix::rowSums(
      GetAssayData(epi, assay = "RNA", layer = "counts") > 0) >= 5]
    reactome_markers(epi_markers, expressed)
  } else NULL
  communication <- if (use_cellchat)
    run_cellchat_groups(major, tnk, epi, cnv_confirmed) else NULL
  functional <- if (!is.null(functional_gene_sets))
    score_functional_modules(tnk, functional_gene_sets) else NULL
  trajectory <- if (!is.null(trajectory_start_state))
    run_tnk_pseudotime(tnk, trajectory_start_state) else NULL

  if (!is.null(output_dir)) {
    dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
    for (section in names(figures)) {
      ggsave(file.path(output_dir, paste0(section, "_umap.pdf")),
             figures[[section]]$umap, width = 7, height = 5)
      ggsave(file.path(output_dir, paste0(section, "_markers.pdf")),
             figures[[section]]$markers, width = 10, height = 5)
      utils::write.csv(proportions[[section]]$statistics,
                       file.path(output_dir, paste0(section, "_paired_composition.csv")),
                       row.names = FALSE)
    }
    if (!is.null(enrichment))
      utils::write.csv(enrichment, file.path(output_dir, "epithelial_Reactome.csv"),
                       row.names = FALSE)
    if (!is.null(functional)) {
      summaries <- functional$sample_mean_scores %>%
        select(-sample_id, -patient_id) %>% group_by(phenotype, timepoint) %>%
        summarise(across(where(is.numeric), list(mean = mean, sd = sd)),
                  n_patients = n(), .groups = "drop")
      utils::write.csv(summaries, file.path(output_dir, "functional_module_summary.csv"),
                       row.names = FALSE)
    }
    if (!is.null(communication$plot))
      ggsave(file.path(output_dir, "communication_heatmap.pdf"),
             communication$plot, width = 12, height = 5)
  }
  list(major = major, tnk = tnk, epithelial = epi,
       markers = list(major = major_markers, tnk = tnk_markers,
                      epithelial = epi_markers),
       proportions = proportions, enrichment = enrichment,
       communication = communication, functional = functional,
       trajectory = trajectory, figures = figures)
}

# Gene sets and trajectory roots must come from the actual analysis specification.
score_functional_modules <- function(x, gene_sets, ctrl = 100L, seed = 1234L) {
  if (!is.list(gene_sets) || is.null(names(gene_sets)) || anyDuplicated(names(gene_sets)))
    stop("Provide uniquely named, versioned functional gene sets.")
  sets <- lapply(gene_sets, intersect, y = rownames(x))
  if (any(lengths(sets) < 2L)) stop("A module has fewer than two observed genes.")
  scored <- Seurat::AddModuleScore(x, features = sets, assay = "RNA", ctrl = ctrl,
                                    seed = seed, name = "IMRECTIFY_module")
  columns <- paste0("IMRECTIFY_module", seq_along(sets))
  data <- scored[[]] %>%
    select(sample_id, patient_id, timepoint, phenotype, all_of(columns)) %>%
    group_by(sample_id, patient_id, timepoint, phenotype) %>%
    summarise(across(all_of(columns), mean), .groups = "drop")
  names(data)[match(columns, names(data))] <- names(sets)
  list(object = scored, sample_mean_scores = data, gene_sets = sets,
       interpretation = "Patient/sample summaries, not independent-cell hypothesis tests")
}

run_tnk_pseudotime <- function(x, start_state) {
  needed <- c("slingshot", "SingleCellExperiment", "SummarizedExperiment")
  if (!all(vapply(needed, requireNamespace, logical(1), quietly = TRUE)))
    stop("Install slingshot, SingleCellExperiment and SummarizedExperiment.")
  if (length(start_state) != 1L || !start_state %in% x$cell_state)
    stop("Specify an observed, biologically reviewed starting cell state.")
  sce <- SingleCellExperiment::SingleCellExperiment(
    assays = list(counts = Seurat::GetAssayData(x, assay = "RNA", layer = "counts")))
  SingleCellExperiment::reducedDim(sce, "PCA") <- Seurat::Embeddings(x, "pca")
  sce$cell_state <- as.character(x$cell_state)
  fit <- slingshot::slingshot(sce, clusterLabels = "cell_state", reducedDim = "PCA",
                              start.clus = start_state)
  list(trajectory = fit, pseudotime = slingshot::slingPseudotime(fit),
       start_state = start_state,
       interpretation = "Exploratory differentiation ordering, not elapsed treatment time")
}

# Workflow:
# 1. Review cluster_cells(seu, ...) and cluster_markers(...) at each level.
# 2. Curate named major_map, tnk_map and epithelial_map from marker evidence.
# 3. Run run_single_cell_analysis(seu, major_map, tnk_map, epithelial_map,
#                                 use_copykat = TRUE, use_reactome = TRUE,
#                                 use_cellchat = TRUE, output_dir = NULL).
# 4. Do not upload the input Seurat object, per-cell outputs or patient metadata.
