# Treatment-effect heterogeneity: interaction, causal forest, and SHAP
# Requires four patient-level data frames in memory, named:
# development, external_1, external_2, temporal.
# Columns: treatment (0=TNT; 1=TNT+ICI), pcr (0/1), tnt_response_score
# (patient-held-out in development), patient_id, prediction_scope, and covariates below.
# No identifiable records or patient-level predictions are written to disk.

require_hte_packages <- function() {
  needed <- c("grf", "ggplot2")
  absent <- needed[!vapply(needed, requireNamespace, logical(1), quietly = TRUE)]
  if (length(absent)) stop("Required R packages: ", paste(absent, collapse = ", "))
  suppressPackageStartupMessages(library(ggplot2))
}

covariates <- c(
  "age_ge_65", "sex_male", "bmi", "ct_numeric", "cn",
  "tumor_size_ge_5cm", "distance_group_code", "crm_positive",
  "emvi_positive", "cea_gt_5ng_ml", "tnt_response_score"
)
categorical <- setdiff(covariates, c("bmi", "tnt_response_score"))
interaction_formula <- stats::reformulate(
  c("treatment", "tnt_response_score", "treatment:tnt_response_score",
    setdiff(covariates, "tnt_response_score")), response = "pcr"
)

validate_cohort <- function(d, development = FALSE, require_score_provenance = TRUE) {
  required <- c("patient_id", "treatment", "pcr", covariates)
  if (!is.data.frame(d) || !all(required %in% names(d)))
    stop("Each cohort must be a data frame with the documented columns.")
  if (nrow(d) < 25L) stop("Cohort is too small for this analysis.")
  if (anyNA(d$patient_id) || any(!nzchar(trimws(as.character(d$patient_id)))) ||
      anyDuplicated(d$patient_id))
    stop("Supply exactly one prespecified baseline record per real patient.")
  if (!all(vapply(d[setdiff(required, "patient_id")], is.numeric, logical(1))))
    stop("Treatment, outcome and covariates must use numeric coding.")
  if (anyNA(d$treatment) || anyNA(d$pcr) ||
      !all(d$treatment %in% 0:1) || !all(d$pcr %in% 0:1))
    stop("Treatment and pCR must be observed, binary (0/1) variables.")
  if ("label_imputed" %in% names(d) &&
      any(d$label_imputed == 1, na.rm = TRUE))
    stop("Imputed outcomes cannot be used in the effect analysis.")
  if (!all(0:1 %in% d$treatment) || !all(0:1 %in% d$pcr))
    stop("Both treatment groups and outcome classes must be represented.")
  if (any(!is.finite(d$tnt_response_score)) ||
      any(d$tnt_response_score < 0 | d$tnt_response_score > 1))
    stop("The pretreatment TNT response score must be observed and in [0, 1].")
  if (any(vapply(d[covariates], function(x) any(is.infinite(x)), logical(1))))
    stop("Covariates cannot contain infinite values.")
  if ("record_key" %in% names(d) &&
      (anyNA(d$record_key) || anyDuplicated(d$record_key)))
    stop("Optional record_key must be non-missing and unique within each cohort.")
  if (require_score_provenance) {
    if (!"prediction_scope" %in% names(d))
      stop("prediction_scope is required to distinguish held-out and fitted scores.")
    allowed <- if (development)
      c("patient_held_out", "cross_fitted_TNT_probability_for_ICI_recipient") else
      "frozen_external_inference"
    if (anyNA(d$prediction_scope) || any(!d$prediction_scope %in% allowed))
      stop("Invalid score provenance for this cohort; in-sample TNT scores are not accepted.")
  }
  invisible(TRUE)
}

fit_feature_design <- function(d) {
  levels <- lapply(d[categorical], function(x) sort(unique(x)))
  active <- covariates[vapply(d[covariates], function(x) length(unique(x)) > 1L, logical(1))]
  if (!length(active)) stop("No varying pretreatment predictors.")
  z <- d[active]
  for (v in intersect(categorical, active)) z[[v]] <- factor(z[[v]], levels = levels[[v]])
  formula <- stats::reformulate(active, intercept = FALSE)
  X <- stats::model.matrix(formula, z)
  list(X = X, levels = levels, active = active, columns = colnames(X), formula = formula)
}

apply_feature_design <- function(d, design) {
  z <- d[design$active]
  for (v in intersect(categorical, design$active)) {
    if (any(!z[[v]] %in% design$levels[[v]]))
      stop("Unseen validation category for ", v, "; do not silently recode it.")
    z[[v]] <- factor(z[[v]], levels = design$levels[[v]])
  }
  X <- stats::model.matrix(design$formula, z)
  if (!identical(colnames(X), design$columns)) stop("Frozen feature encoding mismatch.")
  X
}

# Missing clinical covariates: MICE is fitted in development only.
# For validation, missing covariates receive development-derived mode/median.
# Neither treatment, pCR nor the pretreatment TNT score is imputed.
training_imputations <- function(d, m = 10L, seed = 2026L) {
  missing <- covariates[vapply(d[covariates], anyNA, logical(1))]
  if (!length(missing)) return(list(d))
  if (!requireNamespace("mice", quietly = TRUE))
    stop("Install the 'mice' package to handle missing covariates.")
  if (any(vapply(d[missing], function(x) all(is.na(x)), logical(1))))
    stop("A covariate has no observed values in development.")
  z <- d[c(covariates, "treatment", "pcr")]
  for (v in c(categorical, "treatment", "pcr")) z[[v]] <- factor(z[[v]])
  methods <- setNames(rep("", ncol(z)), names(z))
  for (v in missing) {
    n_levels <- length(unique(stats::na.omit(z[[v]])))
    if (n_levels < 2L) stop("Cannot impute a variable with only one observed value: ", v)
    methods[v] <- if (v %in% categorical) {
      if (n_levels == 2L) "logreg" else "cart"
    } else "pmm"
  }
  predictors <- mice::make.predictorMatrix(z)
  diag(predictors) <- 0
  predictors[c("treatment", "pcr"), ] <- 0
  imp <- mice::mice(z, m = m, maxit = 10L, method = methods,
                    predictorMatrix = predictors, seed = seed, printFlag = FALSE)
  lapply(seq_len(m), function(j) {
    z1 <- mice::complete(imp, j)
    ans <- d
    for (v in covariates) {
      x <- z1[[v]]
      ans[[v]] <- if (is.factor(x)) as.numeric(as.character(x)) else as.numeric(x)
    }
    if (anyNA(ans[covariates])) stop("Incomplete MICE result.")
    ans
  })
}

imputation_reference <- function(d) {
  vapply(covariates, function(v) {
    x <- d[[v]]
    if (v %in% categorical) {
      tab <- table(x)
      as.numeric(names(tab)[which.max(tab)])
    } else stats::median(x)
  }, numeric(1))
}

apply_reference <- function(d, reference) {
  for (v in covariates) d[[v]][is.na(d[[v]])] <- reference[v]
  if (anyNA(d[covariates])) stop("Validation still contains missing predictors.")
  d
}

# Rubin pooling for scalar estimates when multiple imputation was used.
pool_scalar <- function(q, se) {
  if (any(!is.finite(q)) || any(!is.finite(se)) || any(se < 0))
    stop("Estimate or standard error is unavailable; pooling stopped.")
  m <- length(q)
  u <- mean(se^2)
  b <- if (m > 1L) stats::var(q) else 0
  v <- u + (1 + 1 / m) * b
  df <- if (m == 1L || b < 1e-12) Inf else
    (m - 1) * (1 + u / ((1 + 1 / m) * b))^2
  tcrit <- if (is.infinite(df)) stats::qnorm(.975) else stats::qt(.975, df)
  p <- if (v > 0) 2 * stats::pt(-abs(mean(q) / sqrt(v)), df = df) else NA_real_
  c(estimate = mean(q), se = sqrt(v), low = mean(q) - tcrit * sqrt(v),
    high = mean(q) + tcrit * sqrt(v), p = p)
}

fit_development <- function(d, trees, threads, seed) {
  encoding <- fit_feature_design(d)
  X <- encoding$X; W <- d$treatment; Y <- d$pcr
  if (min(table(W)) < 20L) stop("Insufficient patients in a treatment arm.")
  forest <- grf::causal_forest(
    X, Y, W, num.trees = trees, mtry = min(4L, ncol(X)),
    honesty = TRUE, ci.group.size = 2L, sample.fraction = 0.5,
    num.threads = threads, seed = seed
  )
  propensity <- grf::regression_forest(
    X, W, num.trees = trees, mtry = min(4L, ncol(X)),
    sample.fraction = .5, num.threads = threads, seed = seed + 500000L
  )
  outcome <- lapply(0:1, function(w) grf::regression_forest(
    X[W == w, , drop = FALSE], Y[W == w], num.trees = trees,
    mtry = min(4L, ncol(X)), sample.fraction = .5,
    num.threads = threads, seed = seed + 700000L + 100000L * w
  ))
  interaction_data <- d
  for (v in categorical) if (length(unique(d[[v]])) > 1L)
    interaction_data[[v]] <- factor(d[[v]])
  interaction <- stats::glm(interaction_formula, data = interaction_data, family = stats::binomial())
  if (!isTRUE(interaction$converged)) stop("The interaction model did not converge.")
  encoding$X <- NULL
  list(forest = forest, propensity = propensity, outcome = outcome,
       interaction = interaction, encoding = encoding)
}

predict_cohort <- function(d, models, development = FALSE) {
  X <- apply_feature_design(d, models$encoding); W <- d$treatment; Y <- d$pcr
  cate <- if (development) stats::predict(models$forest)$predictions else
    stats::predict(models$forest, newdata = X)$predictions
  ps <- if (development) stats::predict(models$propensity)$predictions else
    stats::predict(models$propensity, newdata = X)$predictions
  mu0 <- stats::predict(models$outcome[[1]], newdata = X)$predictions
  mu1 <- stats::predict(models$outcome[[2]], newdata = X)$predictions
  if (development) {
    # Own-arm responses use OOB trees; opposite-arm patients were never fitted.
    mu0[W == 0] <- stats::predict(models$outcome[[1]])$predictions
    mu1[W == 1] <- stats::predict(models$outcome[[2]])$predictions
  }
  ps_safe <- pmin(pmax(ps, .025), .975)
  if (development) {
    dr <- as.numeric(grf::get_scores(models$forest))
    a <- grf::average_treatment_effect(models$forest)
    ate <- c(q = unname(a["estimate"]), se = unname(a["std.err"]))
  } else {
    # Exploratory external AIPW: depends on transportability of training nuisances.
    dr <- mu1 - mu0 + W * (Y - mu1) / ps_safe -
      (1 - W) * (Y - mu0) / (1 - ps_safe)
    ate <- c(q = mean(dr), se = stats::sd(dr) / sqrt(length(dr)))
  }
  list(cate = as.numeric(cate), ps = as.numeric(ps), dr = dr,
       mu0 = as.numeric(mu0), mu1 = as.numeric(mu1), ate = ate)
}

quintile_summary <- function(cate, dr, W, name) {
  quintile <- pmin(5L, ceiling(5 * rank(cate, ties.method = "first") / length(cate)))
  do.call(rbind, lapply(split(seq_along(cate), quintile), function(i) {
    data.frame(cohort = name, quintile = quintile[i[1]], n = length(i),
               n_TNT = sum(W[i] == 0), n_TNT_ICI = sum(W[i] == 1),
               predicted_CATE = mean(cate[i]), dr_estimate = mean(dr[i]),
               dr_se = stats::sd(dr[i]) / sqrt(length(i)))
  }))
}

save_fig <- function(p, path, width = 8, height = 5) {
  ggplot2::ggsave(path, plot = p, width = width, height = height, limitsize = FALSE)
}

run_treatment_effects <- function(cohorts, output_dir = "results",
                                  trees = 1000L, threads = 1L,
                                  run_shap = TRUE, seed = 20260924L,
                                  require_score_provenance = TRUE,
                                  baseline_covariates_confirmed = FALSE) {
  require_hte_packages()
  if (!isTRUE(baseline_covariates_confirmed))
    stop("Confirm all covariates are pretreatment, including the meaning of crm_positive.")
  cohort_names <- c("development", "external_1", "external_2", "temporal")
  if (!is.list(cohorts) || !setequal(names(cohorts), cohort_names))
    stop("Supply named data frames: development, external_1, external_2, temporal.")
  cohorts <- cohorts[cohort_names]
  for (nm in cohort_names) validate_cohort(cohorts[[nm]], nm == "development",
                                          require_score_provenance)
  identities <- unlist(lapply(cohorts, function(d) as.character(d$patient_id)), use.names = FALSE)
  if (anyDuplicated(identities)) stop("A real patient appears in more than one cohort.")
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  set.seed(seed)

  train_sets <- training_imputations(cohorts$development, seed = 20261011L)
  references <- lapply(train_sets, imputation_reference)
  models <- lapply(seq_along(train_sets), function(j)
    fit_development(train_sets[[j]], trees, threads, seed + 1000L + j))

  # Formal continuous score-by-treatment Wald interaction, in development only.
  interaction_terms <- lapply(models, function(f) {
    co <- summary(f$interaction)$coefficients
    term <- "treatment:tnt_response_score"
    if (!(term %in% rownames(co))) stop("Interaction term not estimable.")
    c(q = co[term, "Estimate"], se = co[term, "Std. Error"])
  })
  interaction <- pool_scalar(
    vapply(interaction_terms, `[[`, numeric(1), "q"),
    vapply(interaction_terms, `[[`, numeric(1), "se")
  )
  interaction_table <- data.frame(term = "treatment:tnt_response_score",
                                  t(interaction), row.names = NULL)
  interaction_table$adjusted_OR <- exp(interaction_table$estimate)
  interaction_table$OR_CI_low <- exp(interaction_table$low)
  interaction_table$OR_CI_high <- exp(interaction_table$high)
  interaction_table$scale <- "per 1.0 increase in TNT response probability"
  utils::write.csv(interaction_table, file.path(output_dir, "interaction_summary.csv"),
                   row.names = FALSE)

  results <- list(); summary_rows <- list(); quintiles <- list()
  for (nm in cohort_names) {
    d <- cohorts[[nm]]
    data_sets <- if (nm == "development") train_sets else
      lapply(references, function(ref) apply_reference(d, ref))
    individual <- lapply(seq_along(models), function(j)
      predict_cohort(data_sets[[j]], models[[j]], nm == "development"))
    avg <- function(k) rowMeans(do.call(cbind, lapply(individual, `[[`, k)))
    r <- list(cate = avg("cate"), ps = avg("ps"), dr = avg("dr"),
              mu0 = avg("mu0"), mu1 = avg("mu1"))
    estimates <- vapply(individual, function(x) x$ate["q"], numeric(1))
    errors <- vapply(individual, function(x) x$ate["se"], numeric(1))
    ate <- pool_scalar(estimates, errors)
    summary_rows[[nm]] <- data.frame(
      cohort = nm, n = nrow(d), n_TNT = sum(d$treatment == 0),
      n_TNT_ICI = sum(d$treatment == 1), t(ate),
      mean_predicted_CATE = mean(r$cate),
      propensity_outside_0025_0975 = mean(r$ps < .025 | r$ps > .975),
      missing_clinical_cells = sum(is.na(d[setdiff(covariates, "tnt_response_score")]))
    )
    q <- quintile_summary(r$cate, r$dr, d$treatment, nm)
    group <- pmin(5L, ceiling(5 * rank(r$cate, ties.method = "first") / length(r$cate)))
    for (i in seq_len(nrow(q))) {
      rows <- which(group == q$quintile[i])
      pooled <- pool_scalar(vapply(individual, function(z) mean(z$dr[rows]), numeric(1)),
                            vapply(individual, function(z) stats::sd(z$dr[rows]) / sqrt(length(rows)), numeric(1)))
      q$dr_estimate[i] <- pooled["estimate"]
      q$dr_se[i] <- pooled["se"]
      q$dr_low[i] <- pooled["low"]
      q$dr_high[i] <- pooled["high"]
    }
    quintiles[[nm]] <- q
    results[[nm]] <- r  # Kept in memory only; no individual-level export.
  }
  summary_table <- do.call(rbind, summary_rows)
  quintile_table <- do.call(rbind, quintiles)
  utils::write.csv(summary_table, file.path(output_dir, "effect_summary.csv"), row.names = FALSE)
  utils::write.csv(quintile_table, file.path(output_dir, "cate_quintiles.csv"), row.names = FALSE)

  # CATE calibration diagnostics: DR estimates are cohort-level observational summaries.
  p_q <- ggplot(quintile_table, aes(predicted_CATE, dr_estimate)) +
    geom_abline(slope = 1, intercept = 0, linetype = 2, color = "grey60") +
    geom_errorbar(aes(ymin = dr_low, ymax = dr_high), width = .01) +
    geom_point(size = 2) + facet_wrap(~cohort, ncol = 2) +
    labs(x = "Mean predicted CATE", y = "Mean doubly robust score") +
    theme_classic()
  save_fig(p_q, file.path(output_dir, "cate_calibration.pdf"))

  # Distribution and overlap diagnostics; underlying individual data stay in memory.
  plot_data <- do.call(rbind, lapply(cohort_names, function(nm) {
    data.frame(cohort = nm, CATE = results[[nm]]$cate,
               propensity = results[[nm]]$ps,
               treatment = ifelse(cohorts[[nm]]$treatment == 1, "TNT + ICI", "TNT"))
  }))
  plot_data$cohort <- factor(plot_data$cohort, levels = cohort_names)
  p_dist <- ggplot(plot_data, aes(CATE)) +
    geom_histogram(bins = 25, fill = "steelblue", color = "white") +
    geom_vline(xintercept = 0, linetype = 2) +
    facet_wrap(~cohort, scales = "free_y") +
    labs(x = "Predicted CATE (TNT + ICI minus TNT)", y = "Number of patients") +
    theme_classic()
  save_fig(p_dist, file.path(output_dir, "cate_distributions.pdf"))
  p_ps <- ggplot(plot_data, aes(propensity, fill = treatment)) +
    geom_density(alpha = .35) + facet_wrap(~cohort, ncol = 2) +
    labs(x = "Development-model treatment propensity", y = "Density", fill = NULL) +
    theme_classic() + theme(legend.position = "top")
  save_fig(p_ps, file.path(output_dir, "propensity_overlap.pdf"))

  # Treatment-specific probability curves use the same development-fitted models.
  curves <- do.call(rbind, lapply(cohort_names, function(nm) {
    d <- cohorts[[nm]]; r <- results[[nm]]
    ord <- order(d$tnt_response_score)
    bins <- pmin(8L, ceiling(seq_along(ord) * 8L / length(ord)))
    do.call(rbind, lapply(split(ord, bins), function(i) {
      data.frame(cohort = nm, score = mean(d$tnt_response_score[i]),
                 treatment = c("TNT", "TNT + ICI"),
                 predicted_pCR = c(mean(r$mu0[i]), mean(r$mu1[i])))
    }))
  }))
  curves$cohort <- factor(curves$cohort, levels = cohort_names)
  p_inter <- ggplot(curves, aes(score, predicted_pCR, color = treatment,
                                group = treatment)) +
    geom_line(linewidth = .8) + geom_point(size = 1.6) +
    facet_wrap(~cohort, nrow = 1) + coord_cartesian(ylim = c(0, 1)) +
    labs(x = "TNT response score", y = "Model-predicted pCR probability", color = NULL) +
    theme_classic() + theme(legend.position = "top")
  save_fig(p_inter, file.path(output_dir, "treatment_score_curves.pdf"), 11, 3.5)

  if (run_shap) {
    # With MICE, SHAP explains the ensemble on the first completed feature
    # representation; it is not a Rubin-pooled individual SHAP estimate.
    if (!requireNamespace("kernelshap", quietly = TRUE) ||
        !requireNamespace("shapviz", quietly = TRUE))
      stop("Install 'kernelshap' and 'shapviz' to compute SHAP.")
    forest_list <- models
    pred_fun <- function(object, newdata, ...) {
      rowMeans(do.call(cbind, lapply(object, function(f)
        stats::predict(f$forest, newdata = apply_feature_design(as.data.frame(newdata), f$encoding))$predictions)))
    }
    X_background <- train_sets[[1]][covariates]
    set.seed(20260925L)
    X_background <- X_background[sample(nrow(X_background),
                                      min(80L, nrow(X_background))), , drop = FALSE]
    shap_tables <- list()
    for (j in seq_along(cohort_names)) {
      nm <- cohort_names[j]
      d <- if (nm == "development") train_sets[[1]] else
        apply_reference(cohorts[[nm]], references[[1]])
      set.seed(20260925L + j)
      X <- d[covariates]
      X <- X[sample(nrow(X), min(150L, nrow(X))), , drop = FALSE]
      ks <- kernelshap::kernelshap(forest_list, X = X,
                                   bg_X = X_background, pred_fun = pred_fun,
                                   verbose = FALSE)
      shap_tables[[nm]] <- data.frame(
        cohort = nm, feature = colnames(ks$S),
        mean_absolute_SHAP = colMeans(abs(ks$S))
      )
      p_s <- shapviz::sv_importance(shapviz::shapviz(ks), kind = "beeswarm") +
        labs(title = nm, x = "SHAP value for predicted CATE") + theme_classic()
      save_fig(p_s, file.path(output_dir, paste0("shap_", nm, ".pdf")), 8, 6)
    }
    utils::write.csv(do.call(rbind, shap_tables),
                     file.path(output_dir, "shap_importance.csv"), row.names = FALSE)
  }
  invisible(list(summary = summary_table, interaction = interaction_table,
                 quintiles = quintile_table, models = models, predictions = results))
}

# Usage (after preparing de-identified data frames in memory):
# cohorts <- list(development = ..., external_1 = ..., external_2 = ..., temporal = ...)
# analysis <- run_treatment_effects(cohorts)
