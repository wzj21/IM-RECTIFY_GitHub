# Transcriptomic and treatment-effect analyses

## Entry point

```bash
Rscript omics/run_analysis.R --analysis bulk --input private/bulk_arguments.rds --output results/bulk
Rscript omics/run_analysis.R --analysis hte --input private/hte_arguments.rds --output results/treatment_effects
Rscript omics/run_analysis.R --analysis single_cell --input private/single_cell_arguments.rds --output results/single_cell
```

Each RDS is a **private named list of function arguments**. Prepare it locally with `saveRDS(list(...), path)`; do not upload it. Scripts can also be sourced and called directly.

## 01: bulk transcriptomics

`analyze_bulk_transcriptomics(tpm, gene_sets, c1_cluster, clinical=NULL)`

- `tpm`: finite nonnegative gene-symbol-by-sample matrix, unique row/column identifiers.
- `gene_sets`: named list of the actual versioned Reactome immune/metabolic gene sets.
- `c1_cluster`: 1 or 2, assigned by the biological pathway orientation, not by desired outcome associations.
- Optional `clinical`: `sample_id, Therapy, Response, RNA_IMET_cluster`; RNA samples are joined by identity.
- `enrich_bulk_core_genes(result, module)` performs GO/Reactome enrichment with an explicit tested-gene background.
- `cibersort_interface.R` accepts the authorized CIBERSORT function and signature matrix supplied by the investigator.

Outputs include consensus phenotypes, ssGSEA scores, limma contrasts, WGCNA associations and plots. The CLI exports gene/pathway summaries; sample-level objects remain in memory. C1/C2 orientation must match MRI label encoding.

## 07: treatment-effect heterogeneity

`run_treatment_effects(cohorts, output_dir, baseline_covariates_confirmed=TRUE)`

`cohorts` is a named list: `development, external_1, external_2, temporal`. Each data frame has one baseline row per real patient:

`patient_id, treatment, pcr, tnt_response_score, prediction_scope,`
`age_ge_65, sex_male, bmi, ct_numeric, cn, tumor_size_ge_5cm,`
`distance_group_code, crm_positive, emvi_positive, cea_gt_5ng_ml`.

Treatment is 0=TNT-only, 1=TNT+ICI; pCR is observed ypT0N0. Development scores are patient-held-out; validation scores are frozen-model inference. `crm_positive` must denote a verified **pretreatment MRI** variable, never postoperative pathological CRM.

The primary logistic interaction uses continuous TNT response probability. Causal forests and treatment-specific outcome forests are fitted in development; validation inference does not refit these predictors. Development forest predictions use out-of-bag trees. The implementation exports Wald interaction, DR summaries, CATE quintiles, overlap diagnostics, probability curves and optional SHAP. Clinical missingness is handled by development MICE and frozen development reference values for validation. External AIPW summaries assume transportability of development nuisance models; they are observational estimates. SHAP explains model predictions, not biological causality.

## 08: paired single-cell analysis

`run_single_cell_analysis(seu, major_map, tnk_map, epithelial_map, ...)`

- `seu`: QC- and doublet-filtered Seurat object containing RNA counts.
- Metadata: `sample_id, patient_id, timepoint` (Pre/Post), `phenotype` (MRI-defined C1-like/C2-like).
- Every donor has a pre/post pair. Cluster annotation maps are named vectors curated from actual marker evidence.
- Options enable CopyKAT, Reactome and CellChat. Supply actual `functional_gene_sets` for module scoring.
- Optional `trajectory_start_state` enables the configurable Slingshot trajectory helper.
- Composition summaries use paired patients, not cells, as replicates.

Raw read alignment, doublet filtering and multiplex-immunofluorescence image quantification are upstream inputs, not performed by this Seurat entry point. CopyKAT intermediates remain private in its reported working directory.

## Dependencies

See `dependencies.json`. R packages and licensed reference assets are installed/provided separately; none are downloaded by the analysis entry point. Capture the actual environment with `sessionInfo()`. Base-R and optional Seurat interface checks:

```bash
Rscript tests/test_r_integrity.R .
```
