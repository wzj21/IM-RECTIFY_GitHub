#!/usr/bin/env Rscript
# RDS input is a private named list of arguments, never part of the public repository.
if (.Platform$OS.type == "windows" && !isTRUE(l10n_info()[["UTF-8"]])) {
  invisible(try(Sys.setlocale("LC_CTYPE", "Chinese (Simplified)_China.utf8"), silent = TRUE))
}
args <- commandArgs(trailingOnly = TRUE)
if ("--help" %in% args || !length(args)) {
  cat("Rscript omics/run_analysis.R --analysis bulk|hte|single_cell --input private_arguments.rds --output results/run\n")
  quit(status = 0L)
}
value <- function(flag) {
  i <- match(flag, args)
  if (is.na(i) || i == length(args)) stop("Required argument: ", flag)
  args[i + 1L]
}
analysis <- value("--analysis")
input <- value("--input")
output <- value("--output")
scripts <- c(bulk = "01_bulk_transcriptomics.R",
             hte = "07_treatment_effect_heterogeneity.R",
             single_cell = "08_single_cell_analysis.R")
functions <- c(bulk = "analyze_bulk_transcriptomics",
               hte = "run_treatment_effects", single_cell = "run_single_cell_analysis")
if (!analysis %in% names(scripts)) stop("--analysis must be bulk, hte, or single_cell.")
file_arg <- grep("^--file=", commandArgs(), value = TRUE)
folder <- dirname(normalizePath(sub("^--file=", "", file_arg[1]), mustWork = TRUE))
environment <- new.env(parent = globalenv())
sys.source(file.path(folder, scripts[[analysis]]), envir = environment)
parameters <- readRDS(input)
if (!is.list(parameters) || is.null(names(parameters))) stop("Input RDS must hold a named argument list.")
dir.create(output, recursive = TRUE, showWarnings = FALSE)
if (analysis != "bulk") parameters$output_dir <- output
result <- do.call(environment[[functions[[analysis]]]], parameters)
if (analysis == "bulk") {
  utils::write.csv(result$pathway_activity, file.path(output, "pathway_activity.csv"), row.names = FALSE)
  utils::write.csv(result$differential_expression, file.path(output, "differential_expression.csv"), row.names = FALSE)
  utils::write.csv(result$gene_modules, file.path(output, "gene_modules.csv"), row.names = FALSE)
  utils::write.csv(result$module_associations, file.path(output, "module_associations.csv"), row.names = FALSE)
  ggplot2::ggsave(file.path(output, "pathway_PCA.pdf"), result$pca, width = 7, height = 5)
  grDevices::pdf(file.path(output, "pathway_heatmap.pdf"), width = 8, height = 6)
  grid::grid.draw(result$heatmap$gtable)
  grDevices::dev.off()
  if (!is.null(result$treatment_interaction)) {
    utils::write.csv(result$treatment_interaction$rates,
                     file.path(output, "RNA_phenotype_response_rates.csv"), row.names = FALSE)
    utils::write.csv(data.frame(test = "two-sided Wald",
                                p_value = result$treatment_interaction$p_value_Wald),
                     file.path(output, "RNA_phenotype_treatment_interaction.csv"), row.names = FALSE)
    ggplot2::ggsave(file.path(output, "RNA_phenotype_treatment_interaction.pdf"),
                    result$treatment_interaction$plot, width = 7, height = 4)
  }
}
writeLines(capture.output(sessionInfo()), file.path(output, "sessionInfo.txt"))
message("Analysis finished. Private objects and individual predictions were not serialized.")
