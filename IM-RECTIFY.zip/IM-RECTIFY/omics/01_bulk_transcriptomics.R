# Bulk transcriptomic analysis: molecular phenotypes, WGCNA and treatment interaction.
# Supply objects in memory; no local paths, patient identifiers or source files are embedded.
# tpm: numeric gene-by-sample matrix (gene symbols as row names).
# gene_sets: named list of curated gene symbols for each pathway.
# clinical (optional): data frame with sample_id, Therapy (0=TNT, 1=TNT+ICI),
#   Response (0=non-pCR, 1=pCR), and RNA_IMET_cluster (C1/C2).
# Clinical phenotype labels must correspond to the RNA-derived clustering.

analyze_bulk_transcriptomics <- function(tpm, gene_sets, clinical = NULL,
                                         c1_cluster, soft_power = 3L,
                                         seed = 1234L) {
  packages <- c("GSVA", "ConsensusClusterPlus", "limma", "WGCNA",
                "pheatmap", "ggplot2", "uwot")
  missing_packages <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing_packages))
    stop("Required R packages: ", paste(missing_packages, collapse = ", "))
  if (missing(c1_cluster) || length(c1_cluster) != 1L || !c1_cluster %in% 1:2)
    stop("Specify c1_cluster as 1 or 2 after reviewing immune-metabolic patterns.")

  tpm <- as.matrix(tpm)
  if (!is.numeric(tpm) || anyNA(tpm) || any(!is.finite(tpm)) || any(tpm < 0))
    stop("tpm must be a finite, nonnegative numeric matrix.")
  if (is.null(rownames(tpm)) || is.null(colnames(tpm)) ||
      anyDuplicated(rownames(tpm)) || anyDuplicated(colnames(tpm)))
    stop("Gene and sample labels must be present and unique.")
  if (ncol(tpm) < 20L) stop("Too few samples for the clustering/WGCNA workflow.")
  if (!is.list(gene_sets) || is.null(names(gene_sets)) ||
      anyDuplicated(names(gene_sets))) stop("gene_sets must be a named list.")
  set.seed(seed)

  # 1. Pathway activity and consensus clustering ----------------------------
  tpm_variable <- tpm[apply(tpm, 1, stats::sd) > 0, , drop = FALSE]
  scores <- GSVA::gsva(GSVA::ssgseaParam(
    exprData = log2(tpm_variable + 1), geneSets = gene_sets, minSize = 5, maxSize = 500
  ), verbose = FALSE)
  scores <- scores[apply(scores, 1, stats::sd) > 0, , drop = FALSE]
  if (nrow(scores) < 2L) stop("Too few informative pathways after filtering.")
  z <- t(scale(t(scores)))  # Standardize each pathway across samples.

  consensus <- ConsensusClusterPlus::ConsensusClusterPlus(
    d = z, maxK = min(9L, ncol(z) - 1L), reps = 1000L,
    pItem = 0.8, clusterAlg = "km", distance = "euclidean",
    seed = seed, plot = NULL, writeTable = FALSE
  )
  cluster <- consensus[[2L]]$consensusClass[colnames(z)]
  if (anyNA(cluster)) stop("Consensus sample labels are not aligned.")
  phenotype <- factor(ifelse(cluster == c1_cluster, "C1", "C2"),
                      levels = c("C1", "C2"))
  if (any(table(phenotype) == 0L)) stop("Both phenotypes must be represented.")
  colors <- c(C1 = "#E64B35", C2 = "#00A087")

  order_samples <- order(phenotype)
  annotation <- data.frame(Phenotype = phenotype[order_samples],
                           row.names = colnames(z)[order_samples])
  heatmap <- pheatmap::pheatmap(
    z[, order_samples, drop = FALSE], cluster_cols = FALSE,
    show_colnames = FALSE, show_rownames = FALSE, silent = TRUE,
    gaps_col = sum(phenotype == "C1"), annotation_col = annotation,
    annotation_colors = list(Phenotype = colors), border_color = NA
  )

  # 2. Differential pathway activity (descriptive, after clustering) --------
  group <- factor(phenotype, levels = c("C1", "C2"))
  design <- stats::model.matrix(~ 0 + group)
  colnames(design) <- c("C1", "C2")
  fit <- limma::lmFit(z, design)
  fit <- limma::eBayes(limma::contrasts.fit(
    fit, limma::makeContrasts(C1 - C2, levels = design)))
  pathway_table <- limma::topTable(fit, number = Inf, adjust.method = "BH")
  pathway_table$pathway <- rownames(pathway_table)
  gene_fit <- limma::lmFit(log2(tpm_variable + 1), design)
  gene_fit <- limma::eBayes(limma::contrasts.fit(
    gene_fit, limma::makeContrasts(C1 - C2, levels = design)))
  gene_table <- limma::topTable(gene_fit, number = Inf, adjust.method = "BH")
  gene_table$gene <- rownames(gene_table)

  # 3. WGCNA: genes -> signed modules -> phenotype associations -------------
  gene_mean <- rowMeans(tpm)
  gene_cv <- apply(tpm, 1, stats::sd) / pmax(gene_mean, .Machine$double.eps)
  keep <- gene_mean >= 1 & gene_cv >= 0.1
  if (sum(keep) < 30L) stop("Too few genes remain for WGCNA.")
  expression <- t(log2(tpm[keep, , drop = FALSE] + 1))  # samples x genes
  qc <- WGCNA::goodSamplesGenes(expression, verbose = 0)
  expression <- expression[qc$goodSamples, qc$goodGenes, drop = FALSE]
  phenotype_w <- phenotype[match(rownames(expression), colnames(z))]
  if (nrow(expression) < 20L || ncol(expression) < 30L)
    stop("Insufficient data for WGCNA after quality control.")

  power_diagnostics <- WGCNA::pickSoftThreshold(
    expression, powerVector = c(1:10, 12, 14, 16),
    networkType = "signed", verbose = 0
  )$fitIndices
  modules <- WGCNA::blockwiseModules(
    expression, power = soft_power, networkType = "signed",
    TOMType = "signed", minModuleSize = 30,
    minKMEtoStay = 0.3, mergeCutHeight = 0.25,
    maxBlockSize = 5000, numericLabels = FALSE, saveTOMs = FALSE,
    randomSeed = seed, nThreads = 1, verbose = 0
  )
  gene_modules <- data.frame(gene = colnames(expression),
                             module = as.character(modules$colors))
  eigengenes <- modules$MEs
  # Spearman gene significance and within-module eigengene membership.
  gene_modules$gene_significance <- as.numeric(stats::cor(
    expression, as.integer(phenotype_w == "C1"), method = "spearman"))
  kme <- stats::cor(expression, eigengenes, method = "spearman")
  membership_col <- match(paste0("ME", gene_modules$module), colnames(eigengenes))
  gene_modules$module_membership <- vapply(seq_along(membership_col), function(i) {
    if (is.na(membership_col[i]) || gene_modules$module[i] == "grey") NA_real_
    else kme[i, membership_col[i]]
  }, numeric(1))
  eigengene_names <- setdiff(colnames(eigengenes), "MEgrey")
  module_associations <- do.call(rbind, lapply(eigengene_names, function(module) {
    test <- suppressWarnings(stats::cor.test(
      eigengenes[, module], as.integer(phenotype_w == "C1"),
      method = "spearman", exact = FALSE
    ))
    data.frame(module = sub("^ME", "", module),
               rho = unname(test$estimate), p_value = test$p.value)
  }))
  if (is.null(module_associations)) {
    module_associations <- data.frame(module = character(), rho = numeric(),
                                      p_value = numeric())
  }
  module_associations$fdr <- stats::p.adjust(module_associations$p_value, "BH")

  # 4. Dimension reduction --------------------------------------------------
  x <- t(z)  # samples x standardized pathways
  pca <- stats::prcomp(x, center = FALSE, scale. = FALSE)
  pca_coordinates <- data.frame(PC1 = pca$x[, 1], PC2 = pca$x[, 2],
                                Phenotype = group)
  pca_plot <- ggplot2::ggplot(
    pca_coordinates, ggplot2::aes(PC1, PC2, color = Phenotype)
  ) + ggplot2::geom_point(size = 2.6) +
    ggplot2::scale_color_manual(values = colors) +
    ggplot2::theme_classic(base_size = 13)
  set.seed(seed)
  umap <- uwot::umap(x, n_neighbors = 15, min_dist = 0.3,
                     metric = "euclidean", n_components = 3, n_threads = 1)
  umap_coordinates <- data.frame(UMAP1 = umap[, 1], UMAP2 = umap[, 2],
                                 UMAP3 = umap[, 3], Phenotype = group)

  # 5. Exploratory phenotype-by-treatment interaction -----------------------
  interaction <- NULL
  if (!is.null(clinical)) {
    needed <- c("sample_id", "Therapy", "Response", "RNA_IMET_cluster")
    if (!all(needed %in% colnames(clinical)))
      stop("Clinical data require sample_id, Therapy, Response and RNA_IMET_cluster.")
    if (anyNA(clinical$sample_id) || anyDuplicated(clinical$sample_id) ||
        !setequal(as.character(clinical$sample_id), colnames(z)))
      stop("Clinical sample_id must uniquely match the RNA samples; no positional joining.")
    clinical <- clinical[match(colnames(z), as.character(clinical$sample_id)), , drop = FALSE]
    if (!identical(trimws(as.character(clinical$RNA_IMET_cluster)), as.character(phenotype)))
      stop("Supplied clinical phenotypes disagree with RNA-derived cluster orientation.")
    clinical_data <- data.frame(
      therapy = suppressWarnings(as.numeric(as.character(clinical$Therapy))),
      pcr = suppressWarnings(as.numeric(as.character(clinical$Response))),
      phenotype = factor(trimws(as.character(clinical$RNA_IMET_cluster)),
                         levels = c("C1", "C2"))
    )
    if (anyNA(clinical_data) || any(!clinical_data$therapy %in% 0:1) ||
        any(!clinical_data$pcr %in% 0:1))
      stop("Invalid or missing clinical categories.")
    main <- stats::glm(pcr ~ therapy + phenotype, data = clinical_data,
                       family = stats::binomial())
    full <- stats::glm(pcr ~ therapy * phenotype, data = clinical_data,
                       family = stats::binomial())
    if (!isTRUE(full$converged)) stop("RNA phenotype interaction model did not converge.")
    coefficients <- summary(full)$coefficients
    term <- "therapy:phenotypeC2"
    if (!term %in% rownames(coefficients) || any(!is.finite(coefficients[term, ])))
      stop("RNA phenotype interaction term is not estimable.")
    interaction_p <- coefficients[term, "Pr(>|z|)"]
    rates <- expand.grid(phenotype = c("C1", "C2"), therapy = 0:1)
    rates$n <- rates$pcr <- integer(nrow(rates))
    for (i in seq_len(nrow(rates))) {
      y <- with(clinical_data, pcr[phenotype == rates$phenotype[i] &
                                    therapy == rates$therapy[i]])
      rates$n[i] <- length(y)
      rates$pcr[i] <- sum(y)
    }
    if (any(rates$n == 0L)) stop("Each phenotype requires both treatment groups.")
    rates$rate <- 100 * rates$pcr / rates$n
    rates$treatment <- factor(ifelse(rates$therapy == 0, "TNT", "TNT+ICI"),
                              levels = c("TNT", "TNT+ICI"))
    interaction_plot <- ggplot2::ggplot(rates,
      ggplot2::aes(rate, phenotype, color = treatment)) +
      ggplot2::geom_line(ggplot2::aes(group = phenotype), color = "grey70") +
      ggplot2::geom_point(size = 3.5) +
      ggplot2::scale_color_manual(values = c(TNT = "#1687D9",
                                             `TNT+ICI` = "#D81B60")) +
      ggplot2::labs(x = "pCR rate (%)", y = NULL, color = NULL) +
      ggplot2::theme_classic(base_size = 13)
    interaction <- list(rates = rates, p_value_Wald = interaction_p,
                        p_value_LRT = stats::anova(main, full, test = "Chisq")$`Pr(>Chi)`[2],
                        coefficients = coefficients,
                        plot = interaction_plot)
  }

  # Results remain in memory; export only reviewed, de-identified outputs.
  list(phenotype = stats::setNames(phenotype, colnames(z)), scores = scores, consensus = consensus,
       differential_expression = gene_table,
       pathway_activity = pathway_table, gene_modules = gene_modules,
       module_associations = module_associations,
       power_diagnostics = power_diagnostics, heatmap = heatmap,
       pca = pca_plot, umap3d = umap_coordinates,
       treatment_interaction = interaction,
       provenance = list(expression_transform = "log2(TPM + 1)",
                         gene_set_names = names(gene_sets), n_pathways_retained = nrow(scores),
                         consensus_k = 2L, c1_cluster = c1_cluster, seed = seed))
}

# Select the actual associated module explicitly; module colours are not universal.
enrich_bulk_core_genes <- function(results, module, fdr = 0.05, logfc_min = 0) {
  needed <- c("clusterProfiler", "ReactomePA", "org.Hs.eg.db")
  absent <- needed[!vapply(needed, requireNamespace, logical(1), quietly = TRUE)]
  if (length(absent)) stop("Required R packages: ", paste(absent, collapse = ", "))
  if (!module %in% results$gene_modules$module) stop("Module not found in this fitted network.")
  de <- results$differential_expression
  genes <- intersect(de$gene[de$adj.P.Val < fdr & de$logFC > logfc_min],
                     results$gene_modules$gene[results$gene_modules$module == module])
  convert <- function(x) suppressMessages(clusterProfiler::bitr(unique(x),
    fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Hs.eg.db::org.Hs.eg.db))$ENTREZID
  universe <- unique(convert(de$gene))
  selected <- unique(intersect(convert(genes), universe))
  if (length(selected) < 5L) stop("Too few mapped core genes for enrichment.")
  list(core_genes = genes, universe = universe,
       GO = clusterProfiler::enrichGO(selected, universe = universe,
         OrgDb = org.Hs.eg.db::org.Hs.eg.db, keyType = "ENTREZID", ont = "BP",
         pAdjustMethod = "BH", pvalueCutoff = fdr, readable = TRUE),
       Reactome = ReactomePA::enrichPathway(selected, universe = universe,
         organism = "human", pAdjustMethod = "BH", pvalueCutoff = fdr, readable = TRUE))
}

# Example (using anonymized objects):
# results <- analyze_bulk_transcriptomics(tpm, gene_sets, clinical, c1_cluster = 1L)
# C1/C2 labels must be assigned based on biological pathway signatures,
# not assumed from arbitrary consensus-cluster numbering.

# Optional on-screen 3D UMAP figure (does not write patient-level data).
plot_umap3d <- function(results) {
  if (!requireNamespace("plot3D", quietly = TRUE))
    stop("Install plot3D to display the 3D UMAP.")
  coordinates <- results$umap3d
  palette <- c(C1 = "#E64B35", C2 = "#00A087")
  plot3D::scatter3D(
    coordinates$UMAP1, coordinates$UMAP2, coordinates$UMAP3,
    colvar = NULL, col = palette[as.character(coordinates$Phenotype)],
    pch = 16, cex = 1.2, colkey = FALSE, theta = 42, phi = 18,
    xlab = "UMAP 1", ylab = "UMAP 2", zlab = "UMAP 3"
  )
  graphics::legend("topright", legend = names(palette), col = palette,
                   pch = 16, bty = "n")
  invisible(NULL)
}
