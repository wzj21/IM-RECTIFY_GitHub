# CIBERSORT itself and LM22 are not redistributed. Supply an authorized function.
run_cibersort_interface <- function(tpm, signature_file, cibersort_function,
                                     private_work_dir, permutations = 1000L) {
  if (!is.function(cibersort_function)) stop("Supply the authorized CIBERSORT function.")
  tpm <- as.matrix(tpm)
  if (!is.numeric(tpm) || anyNA(tpm) || any(!is.finite(tpm)) || any(tpm < 0) ||
      is.null(rownames(tpm)) || is.null(colnames(tpm)) ||
      anyDuplicated(rownames(tpm)) || anyDuplicated(colnames(tpm)))
    stop("Provide finite, nonnegative gene-by-sample TPM with unique names.")
  if (!file.exists(signature_file)) stop("Authorized signature matrix not found.")
  dir.create(private_work_dir, recursive = TRUE, showWarnings = FALSE)
  work <- normalizePath(private_work_dir, mustWork = TRUE)
  signature_file <- normalizePath(signature_file, mustWork = TRUE)
  mixture <- file.path(work, "private_TPM_mixture.tsv")
  utils::write.table(data.frame(GeneSymbol = rownames(tpm), tpm, check.names = FALSE),
                     mixture, sep = "\t", row.names = FALSE, quote = FALSE)
  old <- getwd()
  on.exit(setwd(old), add = TRUE)
  setwd(work)
  result <- cibersort_function(sig_matrix = signature_file, mixture_file = mixture,
                                perm = permutations, QN = FALSE)
  message("Private deconvolution inputs and outputs retained in: ", work)
  result
}
