# IM-RECTIFY

MRI immune-metabolic decoding and TNT response modelling in pMMR locally advanced rectal cancer.

[中文说明](README_中文.md) | [Data format](docs/DATA_CONTRACT.md) | [Method mapping](docs/METHODS_MAPPING.md) | [R analyses](omics/README.md)

## Workflow

1. Bulk RNA: ssGSEA, consensus clustering, C1/C2 orientation, limma, WGCNA and enrichment.
2. MRI: manual tumour masks, ADC preparation, registration, radiomic and deep feature extraction.
3. Molecular anchoring: compare EFM, GIFM, LFM and TFM; lock an MRI decoder with `IMET_score=P(C1|MRI)`.
4. TNT response: compare CM, IMM, EFM, GIFM, LFM and TFM using only TNT-alone outcomes.
5. Validation: patient-level nested fivefold development, joint-arm cross-fitting and frozen external/temporal inference.
6. Treatment effects: continuous TNT-score interactions, causal forests, doubly robust summaries and SHAP.
7. Paired single-cell analysis: annotation, composition, CopyKAT, enrichment, CellChat, module scores and optional trajectories.

The primary feature pipeline uses **manual 3D masks**. nnU-Net is evaluated separately.

| Model | Definition |
|---|---|
| CM | Pretreatment clinical predictors |
| IMM | Locked IMET score mapped to pCR probability |
| EFM | Fold-selected feature concatenation |
| GIFM | Patient-specific gated latent fusion |
| LFM | Inner-held-out branch probability stacking |
| TFM | Modality-token Transformer fusion |

C1=1 and C2=0 in molecular decoding; ypT0N0=1 in response prediction. IMET probability and TNT pCR probability are separate outputs.

## Installation and tests

Use a dedicated Python 3.9 or 3.11 environment, not a shared Spyder environment.

```powershell
py -3.11 -m venv .venv
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -e ".[test,deep]"
.venv\Scripts\python.exe -m pytest -q
.venv\Scripts\python.exe examples/run_synthetic_demo.py --output outputs/demo
```

For MRI extraction install `.[imaging,deep]`. The imaging extra uses NumPy <2 for PyRadiomics compatibility; use a separate extraction environment when modelling under NumPy 2. Select the appropriate PyTorch CUDA build for the target hardware. A genuine Mamba checkpoint requires its compatible Mamba backend.

## Run the models

Copy the configuration templates and set paths to deidentified feature/metadata tables. Paths are relative to each configuration.

```bash
im-rectify develop --config configs/stage1.template.json --output outputs/molecular
im-rectify predict --model outputs/molecular/locked_models.joblib --config configs/stage2.template.json --output outputs/internal_IMET.csv
im-rectify develop --config configs/stage2.template.json --output outputs/training
im-rectify evaluate --predictions outputs/training/cross_fitted_predictions.csv --task tnt --output outputs/training/evaluation
im-rectify interaction --table outputs/training/cross_fitted_predictions.csv --output outputs/interactions
im-rectify predict --model outputs/training/locked_models.joblib --config configs/external.json --output outputs/external_predictions.csv
```

Before response development, save the decoder's `sample_id,IMET_score` columns to the IMET branch table configured for that cohort. Provide prescreening MRI tables for GIFM/TFM. EFM/LFM screening is fitted within training partitions. ICI outcomes never train the TNT-response predictor. Final neural fitting uses the median epoch count selected within outer-training partitions.

```bash
im-rectify prepare --t2 data/raw/T2WI.nii.gz --mask data/raw/MASK.nii.gz --dwi data/raw/DWI.nii.gz --bvalues 0,500,1000 --dce data/raw/DCE.nii.gz --output data/prepared/case_001
im-rectify extract --manifest data/image_manifest.csv --radiomics-yaml configs/radiomics.example.yaml --output data/features
Rscript omics/run_analysis.R --analysis bulk --input private/bulk_arguments.rds --output results/bulk
Rscript omics/run_analysis.R --analysis hte --input private/hte_arguments.rds --output results/treatment_effects
Rscript omics/run_analysis.R --analysis single_cell --input private/single_cell_arguments.rds --output results/single_cell
Rscript tests/test_r_integrity.R .
python tools/capture_environment.py --output outputs/python_environment.json
python tools/check_release.py
```

Review image/ROI alignment before enabling extraction. Deep extraction requires trained checkpoints; missing real DCE remains missing. See `omics/README.md` for R input objects and dependencies.

## Reproducibility

This is portable methods code. Configuration templates and synthetic examples are not the clinical parameter lock or study results. Real data, trained weights and licensed reference matrices are not distributed. Exact study reproduction requires the corresponding data and frozen analysis artefacts. Source fingerprints and software checks are recorded in `SOURCE_PROVENANCE.json` and `RELEASE_VERIFICATION.json`. Redistribution terms are in `LICENSE_NOTICE.md`.
