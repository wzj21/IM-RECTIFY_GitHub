"""Reject accidental data, trained weights, secrets and private absolute paths."""
from __future__ import annotations

import argparse
from pathlib import Path
import re


ALLOWED_SUFFIXES = {".py", ".r", ".md", ".json", ".yaml", ".yml", ".toml", ".txt"}
EXCLUDED_PARTS = {".git", ".venv", "__pycache__", ".pytest_cache", "build", "dist"}


def inspect(root):
    errors, paths = [], []
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if not path.is_file() or any(part in EXCLUDED_PARTS or part.endswith(".egg-info")
                                     for part in relative.parts):
            continue
        paths.append(path)
        if path.name != ".gitignore" and path.suffix.lower() not in ALLOWED_SUFFIXES:
            errors.append(f"Non-source file: {relative.as_posix()}")
            continue
        text = path.read_text(encoding="utf-8-sig")
        for label, pattern in {
            "private Windows path": r"(?i)\b[A-Z]:[\\/](?:Users|MN|data)[\\/]",
            "private home path": r"/(?:home|Users)/[^\s/]+/",
            "GitHub token": r"\b(?:gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{30,})",
            "private key": r"-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----",
        }.items():
            if re.search(pattern, text):
                errors.append(f"{label}: {relative.as_posix()}")
    return paths, errors


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    paths, errors = inspect(args.root.resolve())
    if errors:
        raise SystemExit("\n".join(errors))
    print(f"SOURCE_ONLY_CHECK_PASSED={len(paths)}")
