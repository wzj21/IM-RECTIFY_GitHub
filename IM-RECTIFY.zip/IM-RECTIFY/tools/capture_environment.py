"""Export software and accelerator versions without collecting private paths."""
from __future__ import annotations

import argparse
import importlib.metadata as metadata
import json
import platform
from pathlib import Path


def collect():
    packages = ["numpy", "pandas", "scipy", "scikit-learn", "statsmodels", "matplotlib",
                "joblib", "torch", "monai", "dynamic-network-architectures", "transformers",
                "SimpleITK", "pyradiomics", "PyWavelets", "nnunetv2", "mamba-ssm"]
    versions = {}
    for package in packages:
        try:
            versions[package] = metadata.version(package)
        except metadata.PackageNotFoundError:
            versions[package] = None
    result = {"python": platform.python_version(), "system": platform.system(),
              "architecture": platform.machine(), "packages": versions}
    if versions["torch"]:
        import torch
        result["accelerator"] = {"cuda_build": torch.version.cuda,
                                 "cudnn_runtime": torch.backends.cudnn.version(),
                                 "cuda_available": torch.cuda.is_available(),
                                 "devices": [torch.cuda.get_device_name(i)
                                             for i in range(torch.cuda.device_count())]}
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(collect(), indent=2), encoding="utf-8")
