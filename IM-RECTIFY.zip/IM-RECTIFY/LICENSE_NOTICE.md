# License notice

This prepared repository has not been assigned a redistribution license by its authors. It can be reviewed on GitHub, but no additional permission to reuse or redistribute the authors' code is granted by this notice. The repository owner can add an appropriate license when the author team has chosen one.

Third-party packages remain subject to their respective licenses. No model weights, third-party gene signature assets or patient data are distributed here.

