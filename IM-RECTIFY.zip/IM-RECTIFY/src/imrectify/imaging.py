"""ADC generation and physical-space MRI alignment using the manual T2WI mask."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np


def adc_from_dwi(signal, bvalues):
    """Mono-exponential least-squares ADC; last axis is b-value, output 10^-3 mm^2/s."""
    if bvalues is None:
        raise ValueError("Supply the actual b-values in s/mm^2 for DWI-to-ADC fitting.")
    bvalues = np.asarray(bvalues, dtype=float)
    signal = np.asarray(signal, dtype=float)
    if bvalues.ndim != 1 or not np.isfinite(bvalues).all():
        raise ValueError("b-values must be a finite one-dimensional sequence.")
    if signal.shape[-1] != len(bvalues) or len(np.unique(bvalues)) < 2 or np.any(bvalues < 0):
        raise ValueError("DWI must have a matching b-value axis and at least two distinct nonnegative b-values.")
    valid = np.isfinite(signal).all(axis=-1) & (signal > 0).all(axis=-1)
    centered = bvalues - bvalues.mean()
    logs = np.log(np.maximum(np.where(np.isfinite(signal), signal, 0), 1e-12))
    adc = -np.sum(logs * centered, axis=-1) / np.sum(centered ** 2) * 1000.0
    adc[~valid] = 0
    return adc.astype(np.float32), {"unit": "10^-3 mm^2/s", "invalid_signal_voxels": int((~valid).sum()),
                                   "negative_adc_voxels": int((adc[valid] < 0).sum()),
                                   "fit": "log(S)=intercept-b*ADC; equal-weight least squares"}


def convert_adc_units(array, source_unit):
    scale = {"mm2/s": 1000.0, "1e-3_mm2/s": 1.0, "1e-6_mm2/s": 0.001}
    if source_unit not in scale:
        raise ValueError("ADC source units must be supplied explicitly; vendor scaling is not guessed.")
    return np.asarray(array, dtype=np.float32) * scale[source_unit]


def same_geometry(first, second, tolerance=1e-4):
    return (first.GetSize() == second.GetSize()
            and np.allclose(first.GetSpacing(), second.GetSpacing(), atol=tolerance, rtol=0)
            and np.allclose(first.GetOrigin(), second.GetOrigin(), atol=tolerance, rtol=0)
            and np.allclose(first.GetDirection(), second.GetDirection(), atol=tolerance, rtol=0))


def image_like(array, reference):
    import SimpleITK as sitk
    image = sitk.GetImageFromArray(np.asarray(array))
    image.CopyInformation(reference)
    return image


def rigid_register(fixed, moving, iterations=100, seed=42):
    import SimpleITK as sitk

    initial = sitk.CenteredTransformInitializer(fixed, moving, sitk.Euler3DTransform(),
                                                sitk.CenteredTransformInitializerFilter.GEOMETRY)
    method = sitk.ImageRegistrationMethod()
    method.SetMetricAsMattesMutualInformation(32)
    method.SetMetricSamplingStrategy(method.RANDOM)
    method.SetMetricSamplingPercentage(0.1, seed)
    method.SetInterpolator(sitk.sitkLinear)
    method.SetOptimizerAsGradientDescent(learningRate=1.0, numberOfIterations=iterations,
                                         convergenceMinimumValue=1e-6, convergenceWindowSize=10)
    method.SetOptimizerScalesFromPhysicalShift()
    method.SetShrinkFactorsPerLevel([4, 2, 1])
    method.SetSmoothingSigmasPerLevel([2, 1, 0])
    method.SmoothingSigmasAreSpecifiedInPhysicalUnitsOn()
    method.SetInitialTransform(initial, inPlace=False)
    transform = method.Execute(sitk.Normalize(fixed), sitk.Normalize(moving))
    registered = sitk.Resample(moving, fixed, transform, sitk.sitkBSpline, 0.0, sitk.sitkFloat32)
    return registered, transform, {"metric": float(method.GetMetricValue()),
                                   "stop": method.GetOptimizerStopConditionDescription()}


def prepare_case(t2_path, mask_path, output, adc_path=None, dwi_path=None, bvalues=None,
                 adc_unit="1e-3_mm2/s", dce_path=None, spacing=1.0, iterations=100):
    import SimpleITK as sitk

    sitk.ProcessObject.SetGlobalDefaultNumberOfThreads(1)
    out = Path(output)
    out.mkdir(parents=True, exist_ok=True)
    t2 = sitk.ReadImage(str(t2_path), sitk.sitkFloat32)
    mask = sitk.ReadImage(str(mask_path), sitk.sitkUInt8)
    if t2.GetDimension() != 3 or not same_geometry(t2, mask):
        raise ValueError("Manual mask must share the original T2WI physical geometry; confirm its source before resampling.")
    mask = sitk.Cast(mask > 0, sitk.sitkUInt8)
    if sitk.GetArrayViewFromImage(mask).sum() < 8:
        raise ValueError("Empty or insufficient manual tumor mask.")
    old_size, old_spacing = np.asarray(t2.GetSize()), np.asarray(t2.GetSpacing())
    size = [int(v) for v in np.maximum(1, np.rint((old_size - 1) * old_spacing / spacing) + 1)]
    reference = sitk.Resample(t2, size, sitk.Transform(), sitk.sitkBSpline, t2.GetOrigin(),
                              [float(spacing)] * 3, t2.GetDirection(), 0.0, sitk.sitkFloat32)
    mask = sitk.Resample(mask, reference, sitk.Transform(), sitk.sitkNearestNeighbor, 0, sitk.sitkUInt8)
    sitk.WriteImage(reference, str(out / "T2WI.nii.gz"))
    sitk.WriteImage(mask, str(out / "MASK.nii.gz"))
    status = {"mask_source": "manual", "reference": "T2WI", "spacing_mm": spacing,
              "ADC_unit": "10^-3 mm^2/s", "registration_requires_visual_review": True,
              "analysis_ready": False, "modalities": {"T2WI": "observed", "DCE": "missing"}}
    if adc_path and dwi_path:
        raise ValueError("Supply an observed ADC OR a DWI source, not both.")
    if adc_path:
        source_adc = sitk.ReadImage(str(adc_path), sitk.sitkFloat32)
        adc = image_like(convert_adc_units(sitk.GetArrayFromImage(source_adc), adc_unit), source_adc)
        status["adc_source"] = "observed"
    elif dwi_path:
        dwi = sitk.ReadImage(str(dwi_path), sitk.sitkFloat32)
        if dwi.GetDimension() != 4:
            raise ValueError("DWI input must be a 4D volume with a supplied b-value per volume.")
        array, audit = adc_from_dwi(np.moveaxis(sitk.GetArrayFromImage(dwi), 0, -1), bvalues)
        template = sitk.Extract(dwi, list(dwi.GetSize()[:3]) + [0], [0, 0, 0, 0])
        adc = image_like(array, template)
        status.update({"adc_source": "derived_from_DWI", "adc_fit": audit})
    else:
        raise ValueError("ADC or DWI is required for the primary T2WI+ADC analysis.")
    for name, moving in [("ADC", adc), ("DCE", sitk.ReadImage(str(dce_path), sitk.sitkFloat32) if dce_path else None)]:
        if moving is None:
            continue
        registered, transform, metrics = rigid_register(reference, moving, iterations=iterations)
        filename = "ADC.nii.gz" if name == "ADC" else "DCE_main_real.nii.gz"
        sitk.WriteImage(registered, str(out / filename))
        sitk.WriteTransform(transform, str(out / f"{name}_fixed_to_moving.tfm"))
        support = image_like(np.ones(tuple(reversed(moving.GetSize())), np.uint8), moving)
        support = sitk.Resample(support, reference, transform, sitk.sitkNearestNeighbor, 0, sitk.sitkUInt8)
        roi = sitk.GetArrayViewFromImage(mask) > 0
        coverage = float((sitk.GetArrayViewFromImage(support)[roi] > 0).mean())
        status["modalities"][name] = {"source": "observed_or_DWI_derived", "tumor_FOV_coverage": coverage,
                                      "registration": metrics}
    (out / "data_status.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
    return status

