"""Checkpoint-required inference for the supplied TA-MambaNeXt architecture."""
from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np


def load_trained_encoder(checkpoint):
    import torch
    from .models.encoder import ExtractorConfig, TAMambaNeXtResNet3D

    checkpoint = Path(checkpoint)
    payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
    required = {"config", "state_dict", "training_provenance", "preprocessing"}
    if not isinstance(payload, dict) or not required.issubset(payload):
        raise ValueError("Encoder checkpoint needs config, state_dict, training_provenance and preprocessing metadata.")
    if payload["training_provenance"].get("is_trained") is not True:
        raise ValueError("Random or unverified encoder weights cannot produce research features.")
    model = TAMambaNeXtResNet3D(ExtractorConfig(**payload["config"]))
    if model.cfg.global_mixer == "mamba" and model.global_mixer.actual_mixer != "mamba":
        raise RuntimeError("Checkpoint requests Mamba, but only a Transformer fallback is available.")
    model.load_state_dict(payload["state_dict"], strict=True)
    model.eval()
    return model, payload, hashlib.sha256(checkpoint.read_bytes()).hexdigest()


def encoder_vector(model, image, mask, spacing_zyx, preprocessing):
    import torch
    from torch.nn import functional as functional
    from .habitats import roi_standardize

    coordinates = np.argwhere(mask)
    if len(coordinates) == 0:
        raise ValueError("Empty ROI for deep feature extraction.")
    shape = preprocessing["input_shape"]
    margin = np.ceil(float(preprocessing["crop_margin_mm"]) / np.asarray(spacing_zyx)).astype(int)
    lower = np.maximum(0, coordinates.min(axis=0) - margin)
    upper = np.minimum(mask.shape, coordinates.max(axis=0) + margin + 1)
    crop = tuple(slice(int(a), int(b)) for a, b in zip(lower, upper))
    if preprocessing["normalization"] != "ROI_zscore":
        raise ValueError("This public runner supports an explicitly declared ROI_zscore checkpoint contract.")
    array = roi_standardize(image, mask)[crop].astype(np.float32)
    roi = mask[crop].astype(np.float32)
    x = functional.interpolate(torch.from_numpy(array)[None, None], size=shape, mode="trilinear", align_corners=False)
    m = functional.interpolate(torch.from_numpy(roi)[None, None], size=shape, mode="nearest")
    with torch.no_grad():
        feature = model(x, m).cpu().numpy().ravel()
    return {f"TA_MambaNeXt_{i:04d}": float(v) for i, v in enumerate(feature)}

