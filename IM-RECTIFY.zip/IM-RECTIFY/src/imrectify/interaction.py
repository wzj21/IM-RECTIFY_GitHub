"""Exploratory treatment-score associations in the combined internal cohort."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


def analyse_interactions(table, output, covariates=(), bootstrap=1000, seed=42,
                         primary_score="TNT_pCR_score", cohort_role="development"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import statsmodels.api as sm
    import statsmodels.formula.api as smf
    from statsmodels.tools.sm_exceptions import PerfectSeparationError

    if primary_score not in {"TNT_pCR_score", "DecisionScore"}:
        raise ValueError("primary_score must be TNT_pCR_score or the optional legacy DecisionScore.")
    required = {"patient_id", "treatment", "label", "TNT_pCR_score", "prediction_scope", *covariates}
    if "IMET_score" in table or primary_score == "DecisionScore":
        required.add("IMET_score")
    if required - set(table):
        raise ValueError(f"Interaction table missing: {sorted(required - set(table))}")
    if table.patient_id.isna().any() or table.patient_id.duplicated().any():
        raise ValueError("Interaction analysis requires one prespecified baseline record per real patient.")
    allowed = {"patient_held_out", "cross_fitted_TNT_probability_for_ICI_recipient"}
    if cohort_role == "external":
        allowed = {"frozen_external_inference"}
    elif cohort_role != "development":
        raise ValueError("cohort_role must be development or external.")
    if table.prediction_scope.isna().any() or not table.prediction_scope.isin(allowed).all():
        raise ValueError("Use patient-held-out scores in development and frozen scores externally.")
    frame = table[list(required)].replace([np.inf, -np.inf], np.nan).dropna().copy()
    if not frame.label.isin([0, 1]).all() or not frame.treatment.isin([0, 1]).all():
        raise ValueError("Observed label/treatment must be binary.")
    if frame.empty or frame.treatment.nunique() != 2 or frame.label.nunique() != 2:
        raise ValueError("Both treatment arms and both outcome classes are required.")
    score_columns = [c for c in ("IMET_score", "TNT_pCR_score") if c in frame]
    for column in score_columns:
        if not frame[column].between(0, 1).all() or frame[column].std(ddof=0) == 0:
            raise ValueError(f"{column}: probabilities must vary and stay in [0,1].")
    standardization = {}
    for original, new in ((c, "IMET_z" if c == "IMET_score" else "TNT_z") for c in score_columns):
        mean, std = float(frame[original].mean()), float(frame[original].std(ddof=0))
        standardization[original] = {"mean": mean, "std": std}
        frame[new] = (frame[original] - mean) / std
    if "IMET_z" in frame:
        frame["DecisionScore"] = frame.IMET_z - frame.TNT_z
    adjustment = "".join(f" + Q('{name}')" for name in covariates)
    formulas = {
        "Primary": f"label ~ treatment * {primary_score}" + adjustment,
        "TNT_standardized": "label ~ treatment * TNT_z" + adjustment,
        "Score_spline": f"label ~ treatment * cr({primary_score}, df=3, constraints='center')" + adjustment,
    }
    if "IMET_z" in frame:
        formulas.update({
            "IMET_sensitivity": "label ~ treatment * IMET_z" + adjustment,
            "Joint_sensitivity": "label ~ treatment * (IMET_z + TNT_z)" + adjustment,
            "DecisionScore_sensitivity": "label ~ treatment * DecisionScore" + adjustment,
        })
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    coefficients, tests = [], []
    models = {}
    for name, formula in formulas.items():
        fitted = smf.glm(formula, data=frame, family=sm.families.Binomial()).fit(cov_type="HC3")
        models[name] = fitted
        interval = fitted.conf_int()
        for term, coefficient in fitted.params.items():
            coefficients.append({"model": name, "term": term, "beta": coefficient,
                                 "adjusted_OR": np.exp(np.clip(coefficient, -700, 700)),
                                 "OR_CI_low": np.exp(np.clip(interval.loc[term, 0], -700, 700)),
                                 "OR_CI_high": np.exp(np.clip(interval.loc[term, 1], -700, 700)),
                                 "p_value": fitted.pvalues[term]})
        indices = [i for i, term in enumerate(fitted.params.index) if "treatment:" in term]
        contrast = np.eye(len(fitted.params))[indices]
        test = fitted.wald_test(contrast, scalar=True)
        tests.append({"model": name, "interaction_p": float(test.pvalue), "interaction_df": len(indices),
                      "test": "joint Wald, HC3 covariance", "n": len(frame)})
    low = max(frame.loc[frame.treatment.eq(t), primary_score].quantile(0.05) for t in (0, 1))
    high = min(frame.loc[frame.treatment.eq(t), primary_score].quantile(0.95) for t in (0, 1))
    if not low < high:
        raise ValueError("Insufficient common score support between treatment groups.")
    grid = np.linspace(low, high, 60)

    def marginal_predictions(model, data):
        probabilities = np.empty((len(grid), 2))
        for i, score in enumerate(grid):
            for treatment in (0, 1):
                evaluation = data.copy()
                evaluation[primary_score] = score
                evaluation["treatment"] = treatment
                probabilities[i, treatment] = model.predict(evaluation).mean()
        return probabilities

    probability = marginal_predictions(models["Primary"], frame)
    rng = np.random.default_rng(seed)
    bootstrap_predictions = []
    failures = 0
    for _ in range(bootstrap):
        indices = np.concatenate([rng.choice(np.flatnonzero(frame.treatment.to_numpy() == t),
                                             size=int(frame.treatment.eq(t).sum()), replace=True) for t in (0, 1)])
        sampled = frame.iloc[indices].copy()
        try:
            model = smf.glm(formulas["Primary"], data=sampled, family=sm.families.Binomial()).fit()
            bootstrap_predictions.append(marginal_predictions(model, sampled))
        except (ValueError, np.linalg.LinAlgError, PerfectSeparationError):
            failures += 1
    delta = probability[:, 1] - probability[:, 0]
    intervals = np.full((2, len(grid)), np.nan)
    if bootstrap_predictions:
        boot = np.asarray(bootstrap_predictions)
        intervals = np.percentile(boot[:, :, 1] - boot[:, :, 0], [2.5, 97.5], axis=0)
    curves = pd.DataFrame({primary_score: grid, "TNT_probability": probability[:, 0],
                           "TNT_ICI_probability": probability[:, 1], "adjusted_risk_difference": delta,
                           "RD_CI_low": intervals[0], "RD_CI_high": intervals[1]})
    pd.DataFrame(coefficients).to_csv(output / "interaction_coefficients.csv", index=False)
    pd.DataFrame(tests).to_csv(output / "interaction_tests.csv", index=False)
    curves.to_csv(output / "marginal_probabilities.csv", index=False)
    figure, axes = plt.subplots(1, 2, figsize=(10, 4), layout="constrained")
    axes[0].plot(grid, probability[:, 0], color="#4d79b0", label="TNT")
    axes[0].plot(grid, probability[:, 1], color="#bf5b52", label="TNT+ICI")
    axes[0].set(xlabel=primary_score, ylabel="Adjusted pCR probability", ylim=(0, 1))
    axes[0].legend(frameon=False)
    axes[1].plot(grid, delta, color="#238b76")
    axes[1].fill_between(grid, intervals[0], intervals[1], color="#238b76", alpha=0.15)
    axes[1].axhline(0, color="0.5", linestyle="--")
    axes[1].set(xlabel=primary_score, ylabel="Adjusted pCR probability difference")
    for extension in ("png", "svg", "pdf"):
        figure.savefig(output / f"exploratory_interaction.{extension}", dpi=300)
    plt.close(figure)
    (output / "analysis_notes.json").write_text(json.dumps({
        "n_input": len(table), "n_complete_case": len(frame), "score_standardization": standardization,
        "primary_score": primary_score, "cohort_role": cohort_role,
        "DecisionScore_sensitivity": "z(IMET_score) - z(TNT_pCR_score), only when IMET is supplied",
        "covariates": list(covariates),
        "bootstrap_success": len(bootstrap_predictions), "bootstrap_failure": failures,
        "interpretation": "Exploratory adjusted associations; treatment was not randomized. No direction is enforced.",
        "score_requirement": "Use patient-held-out TNT predictions internally; never use all-data fitted TNT predictions.",
        "causal_forest": "See omics/07_treatment_effect_heterogeneity.R; no causal treatment-policy DCA is asserted.",
    }, indent=2), encoding="utf-8")
    return pd.DataFrame(tests)

