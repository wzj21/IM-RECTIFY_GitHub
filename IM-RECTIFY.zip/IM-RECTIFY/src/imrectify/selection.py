"""Fold-local encoding, family-wise Spearman/mRMR and bootstrap L1 selection."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import mutual_info_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


class BranchPreprocessor:
    def __init__(self, screen=True, correlation=0.9, mrmr_k=25, lasso_c=1.0,
                 bootstraps=20, stability=0.6, direction=0.7, seed=42, missing_cutoff=0.2):
        self.screen = screen
        self.correlation = correlation
        self.mrmr_k = mrmr_k
        self.lasso_c = lasso_c
        self.bootstraps = bootstraps
        self.stability = stability
        self.direction = direction
        self.seed = seed
        self.missing_cutoff = missing_cutoff

    def fit(self, frame, y, groups=None):
        self.columns_ = list(frame)
        frame = frame.replace([np.inf, -np.inf], np.nan)
        self.missing_rates_ = frame.isna().mean().to_dict()
        self.retained_columns_ = [c for c in frame if self.missing_rates_[c] <= self.missing_cutoff]
        self.audit_ = []
        if not self.retained_columns_:
            self.constant_ = True
            self.encoder_ = None
            self.names_ = np.array([], dtype=str)
            self.selected_ = np.array([], dtype=int)
            return self
        frame = frame.loc[:, self.retained_columns_]
        numeric = list(frame.select_dtypes(include=np.number))
        categorical = [c for c in frame if c not in numeric]
        steps = []
        if numeric:
            steps.append(("numeric", SimpleImputer(strategy="median", keep_empty_features=True), numeric))
        if categorical:
            cat = Pipeline([
                ("impute", SimpleImputer(strategy="most_frequent", keep_empty_features=True)),
                ("encode", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
            ])
            steps.append(("categorical", cat, categorical))
        self.encoder_ = ColumnTransformer(steps, verbose_feature_names_out=False)
        x = np.asarray(self.encoder_.fit_transform(frame), float)
        self.names_ = np.asarray(self.encoder_.get_feature_names_out())
        unscaled_variance = np.var(x, axis=0)
        self.scaler_ = StandardScaler().fit(x)
        x = self.scaler_.transform(x)
        active = np.flatnonzero(np.var(x, axis=0) > 1e-12)
        # A constant branch stays a zero-valued input; no outcome-guided rescue feature is invented.
        self.constant_ = len(active) == 0
        self.audit_ = []
        if self.constant_:
            self.selected_ = np.array([], dtype=int)
            return self
        if not self.screen:
            self.selected_ = active
            return self
        picked = []
        rng = np.random.default_rng(self.seed)
        families = sorted({str(n).split("__", 1)[0] for n in self.names_[active]})
        groups = np.asarray(groups if groups is not None else np.arange(len(y)))
        y = np.asarray(y, dtype=int)
        unique_groups, first = np.unique(groups, return_index=True)
        group_y = y[first]
        for family in families:
            candidates = [i for i in active if str(self.names_[i]).split("__", 1)[0] == family]
            def missing_rate(index):
                name = str(self.names_[index])
                return min((rate for column, rate in self.missing_rates_.items()
                            if name == column or name.startswith(column + "_")), default=0.0)
            candidates.sort(key=lambda j: (missing_rate(j), -unscaled_variance[j], str(self.names_[j])))
            ranks = pd.DataFrame(x[:, candidates]).rank().to_numpy()
            ranks -= ranks.mean(axis=0)
            norms = np.sqrt(np.sum(ranks ** 2, axis=0))
            ranks /= np.maximum(norms, 1e-12)
            kept = []
            # Compute correlations against the retained columns, without a full p-by-p matrix.
            for j in range(len(candidates)):
                if not kept or np.max(np.abs(ranks[:, kept].T @ ranks[:, j])) < self.correlation:
                    kept.append(j)
            candidates = np.asarray(candidates, dtype=int)[kept]
            discrete = np.column_stack([self._discretize(x[:, j]) for j in candidates])
            relevance = np.asarray([mutual_info_score(discrete[:, j], y) for j in range(len(candidates))])
            remaining = list(range(len(candidates)))
            chosen = []
            redundancy = np.zeros(len(candidates))
            while remaining and len(chosen) < self.mrmr_k:
                j = max(remaining, key=lambda i: (relevance[i] - redundancy[i] / max(1, len(chosen)), -i))
                remaining.remove(j)
                chosen.append(j)
                for i in remaining:
                    redundancy[i] += mutual_info_score(discrete[:, i], discrete[:, j])
            candidates = candidates[chosen]
            z = x[:, candidates]
            full = self._lasso().fit(z, y).coef_.ravel()
            coefs = []
            for _ in range(self.bootstraps):
                drawn = np.concatenate([
                    rng.choice(unique_groups[group_y == c], size=int((group_y == c).sum()), replace=True)
                    for c in (0, 1)
                ])
                idx = np.concatenate([np.flatnonzero(groups == g) for g in drawn])
                # Rescale each patient bootstrap within the training partition.
                scale = StandardScaler().fit(z[idx])
                coefs.append(self._lasso().fit(scale.transform(z[idx]), y[idx]).coef_.ravel())
            coefs = np.asarray(coefs) if coefs else full[None, :]
            nonzero = np.abs(coefs) > 1e-8
            frequency = nonzero.mean(axis=0)
            direction = np.maximum((coefs > 1e-8).sum(axis=0), (coefs < -1e-8).sum(axis=0)) / np.maximum(nonzero.sum(axis=0), 1)
            selected = (np.abs(full) > 1e-8) & (frequency >= self.stability) & (direction >= self.direction)
            for j, feature in enumerate(candidates):
                self.audit_.append({"feature": str(self.names_[feature]), "family": family,
                                    "coefficient": float(full[j]), "bootstrap_frequency": float(frequency[j]),
                                    "mean_bootstrap_coefficient": float(coefs[:, j].mean()),
                                    "direction_consistency": float(direction[j]), "selected": bool(selected[j])})
            picked.extend(candidates[selected])
        self.selected_ = np.asarray(picked, dtype=int)
        self.constant_ = len(picked) == 0
        return self

    def _lasso(self):
        return LogisticRegression(penalty="l1", solver="liblinear", C=self.lasso_c,
                                  max_iter=3000, random_state=self.seed)

    @staticmethod
    def _discretize(values):
        edges = np.unique(np.quantile(values, np.linspace(0, 1, 6)))
        return np.digitize(values, edges[1:-1])

    def transform(self, frame):
        if self.encoder_ is None:
            return np.zeros((len(frame), 1))
        if list(frame) != self.columns_:
            frame = frame.loc[:, self.columns_]
        x = np.asarray(self.encoder_.transform(frame.loc[:, self.retained_columns_].replace([np.inf, -np.inf], np.nan)), float)
        x = self.scaler_.transform(x)
        return x[:, self.selected_] if not self.constant_ else np.zeros((len(frame), 1))

    def feature_names(self):
        return self.names_[self.selected_].tolist() if not self.constant_ else ["constant_zero"]

