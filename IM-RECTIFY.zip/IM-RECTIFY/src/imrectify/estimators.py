"""Clinical, IMET, feature fusion, neural fusion and OOF probability stacking."""
from __future__ import annotations

import numpy as np
from scipy.special import logit
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from .selection import BranchPreprocessor


def grouped_splits(y, groups, folds, seed):
    from sklearn.model_selection import StratifiedGroupKFold

    y, groups = np.asarray(y), np.asarray(groups)
    unique, first = np.unique(groups, return_index=True)
    if len(unique) < folds or min(np.bincount(y[first].astype(int), minlength=2)) < folds:
        raise ValueError(f"Need at least {folds} distinct patients in each class for {folds}-fold CV.")
    splits = list(StratifiedGroupKFold(folds, shuffle=True, random_state=seed).split(np.zeros(len(y)), y, groups))
    for train, test in splits:
        if set(groups[train]) & set(groups[test]) or len(np.unique(y[train])) < 2 or len(np.unique(y[test])) < 2:
            raise ValueError("Invalid patient-grouped fold; inspect class/group balance.")
    return splits


def slice_blocks(blocks, indices):
    return {name: frame.iloc[indices].reset_index(drop=True) for name, frame in blocks.items()}


def learner(name, params, seed):
    if name == "RF":
        return RandomForestClassifier(n_estimators=int(params.get("trees", 100)),
                                      max_depth=params.get("max_depth", 4), min_samples_leaf=3,
                                      n_jobs=1, random_state=seed)
    return LogisticRegression(C=float(params.get("C", 1.0)), solver="liblinear",
                              max_iter=3000, random_state=seed)


class FusionModel:
    def __init__(self, kind, selection=None, params=None, seed=42, inner_folds=3):
        if kind not in {"CM", "IMM", "EFM", "LFM", "GIFM", "TFM"}:
            raise ValueError(kind)
        self.kind, self.selection = kind, dict(selection or {})
        self.params, self.seed, self.inner_folds = dict(params or {}), seed, inner_folds

    def fit(self, blocks, y, groups):
        if self.kind == "CM":
            blocks = {"Clinical": blocks["Clinical"]}
        if self.kind == "IMM":
            blocks = {"IMET": blocks["IMET"]}
        self.names_ = list(blocks)
        self.schema_ = {name: list(frame) for name, frame in blocks.items()}
        self.calibrator_ = None
        if self.kind == "LFM":
            self._fit_late(blocks, np.asarray(y), np.asarray(groups))
            return self
        self.preprocessors_, arrays = self._fit_preprocessors(blocks, y, groups)
        if self.kind in {"GIFM", "TFM"}:
            from .models.fusion import NeuralTrainer
            self.classifier_ = NeuralTrainer(self.kind, self.params, self.seed).fit(arrays, y)
        else:
            self.classifier_ = learner(self.params.get("learner", "LR"), self.params, self.seed)
            self.classifier_.fit(np.concatenate(arrays, axis=1), y)
        return self

    def _fit_preprocessors(self, blocks, y, groups):
        preprocessors, arrays = {}, []
        for i, (name, frame) in enumerate(blocks.items()):
            # GIFM/TFM learn feature representations without mRMR/LASSO prescreening.
            screen = self.kind not in {"GIFM", "TFM", "IMM"} and name != "IMET"
            opts = {**self.selection, "lasso_c": self.params.get("lasso_c", self.selection.get("lasso_c", 1.0))}
            prep = BranchPreprocessor(screen=screen, seed=self.seed + i, **opts).fit(frame, y, groups)
            preprocessors[name] = prep
            arrays.append(prep.transform(frame))
        return preprocessors, arrays

    def _fit_late(self, blocks, y, groups):
        pairs = [(name, alg) for name in blocks for alg in ("LR", "RF")]
        oof = np.full((len(y), len(pairs)), np.nan)
        for fold, (train, valid) in enumerate(grouped_splits(y, groups, self.inner_folds, self.seed)):
            pp, arrays = self._fit_preprocessors(slice_blocks(blocks, train), y[train], groups[train])
            for j, (name, algorithm) in enumerate(pairs):
                x = arrays[self.names_.index(name)]
                base = learner(algorithm, self.params, self.seed + fold + j).fit(x, y[train])
                oof[valid, j] = base.predict_proba(pp[name].transform(blocks[name].iloc[valid]))[:, 1]
        if not np.isfinite(oof).all():
            raise RuntimeError("Late-fusion meta-training predictions are incomplete.")
        self.meta_ = make_pipeline(StandardScaler(), LogisticRegression(
            penalty="l2", C=float(self.params.get("meta_C", 1.0)), solver="liblinear", max_iter=3000))
        self.meta_.fit(logit(np.clip(oof, 1e-6, 1 - 1e-6)), y)
        self.preprocessors_, arrays = self._fit_preprocessors(blocks, y, groups)
        self.base_ = []
        for j, (name, algorithm) in enumerate(pairs):
            self.base_.append((name, learner(algorithm, self.params, self.seed + j).fit(
                arrays[self.names_.index(name)], y)))

    def predict(self, blocks):
        arrays = [self.preprocessors_[name].transform(blocks[name]) for name in self.names_]
        if self.kind == "LFM":
            probabilities = np.column_stack([
                base.predict_proba(arrays[self.names_.index(name)])[:, 1] for name, base in self.base_
            ])
            p = self.meta_.predict_proba(logit(np.clip(probabilities, 1e-6, 1 - 1e-6)))[:, 1]
        elif self.kind in {"GIFM", "TFM"}:
            p = self.classifier_.predict(arrays)
        else:
            p = self.classifier_.predict_proba(np.concatenate(arrays, axis=1))[:, 1]
        if self.calibrator_ is not None:
            p = self.calibrator_.predict_proba(logit(np.clip(p, 1e-6, 1 - 1e-6)).reshape(-1, 1))[:, 1]
        return np.asarray(p, float)

    def selection_audit(self):
        return {name: {"selected_features": prep.feature_names(), "selection": prep.audit_}
                for name, prep in self.preprocessors_.items()}

