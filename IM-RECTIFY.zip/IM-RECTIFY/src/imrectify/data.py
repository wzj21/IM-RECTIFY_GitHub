"""Explicit sample identity, label and feature contracts for every cohort."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict

import numpy as np
import pandas as pd


RESERVED = {
    "label", "pcr", "outcome", "target", "treatment", "cohort", "patient_id",
    "sample_id", "fold", "repeat", "split", "prediction", "probability",
    "label_binary", "ypT", "ypN", "trg", "survival", "dfs", "os",
}


def identity_hash(value: str) -> str:
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()


@dataclass
class Dataset:
    metadata: pd.DataFrame
    branches: Dict[str, pd.DataFrame]
    config: dict

    def subset(self, rows) -> "Dataset":
        rows = np.asarray(rows)
        return Dataset(
            self.metadata.iloc[rows].reset_index(drop=True),
            {name: frame.iloc[rows].reset_index(drop=True) for name, frame in self.branches.items()},
            self.config,
        )


def read_csv(path: Path) -> pd.DataFrame:
    # Identifiers stay strings, including leading zeroes.
    frame = pd.read_csv(path, dtype={"sample_id": str, "patient_id": str}, encoding="utf-8-sig")
    frame.columns = frame.columns.str.strip()
    if frame.columns.duplicated().any():
        raise ValueError(f"Duplicate columns: {path}")
    return frame


def load_dataset(config_path, require_label=True, required_branches=None) -> Dataset:
    config_path = Path(config_path).resolve()
    cfg = json.loads(config_path.read_text(encoding="utf-8"))
    root = config_path.parent
    meta = read_csv(root / cfg["metadata"])
    required = {"sample_id", "patient_id", "cohort", "treatment"}
    if not required.issubset(meta):
        raise ValueError(f"Metadata missing: {sorted(required - set(meta))}")
    if meta[list(required)].isna().any().any() or meta.sample_id.duplicated().any():
        raise ValueError("Metadata identities/cohort/treatment must be present; sample_id must be unique.")
    if not meta.treatment.isin([0, 1]).all():
        raise ValueError("treatment must be 0=TNT only or 1=TNT+ICI.")
    if "label" not in meta:
        meta["label"] = np.nan
    numeric = pd.to_numeric(meta.label, errors="coerce")
    invalid = meta.label.notna() & (~numeric.isin([0, 1]))
    if invalid.any():
        raise ValueError("label must be 0/1 or missing; outcomes are never imputed.")
    meta["label"] = numeric
    if require_label and meta.loc[meta.treatment.eq(0), "label"].isna().any():
        raise ValueError("All development TNT-only cases require observed binary labels.")
    for col in ("treatment", "label"):
        if meta.groupby("patient_id")[col].nunique(dropna=True).gt(1).any():
            raise ValueError(f"Conflicting {col} records for the same real patient.")
    branches = {}
    for name, specs in cfg["branches"].items():
        if required_branches is not None and name not in required_branches:
            continue
        pieces = []
        for spec in specs:
            table = read_csv(root / spec["path"])
            if "sample_id" not in table or table.sample_id.isna().any() or table.sample_id.duplicated().any():
                raise ValueError(f"{name}: feature table requires a unique sample_id.")
            columns = spec.get("columns", [c for c in table if c != "sample_id"])
            forbidden = [c for c in columns if c.lower() in {s.lower() for s in RESERVED}]
            if forbidden:
                raise ValueError(f"Outcome/identity columns cannot be features: {forbidden}")
            if set(columns) - set(table):
                raise ValueError(f"{name}: declared feature columns missing.")
            missing = set(meta.sample_id) - set(table.sample_id)
            if missing and not spec.get("allow_missing_rows", False):
                raise ValueError(f"{name}: {len(missing)} samples lack feature rows; no silent intersection is used.")
            part = table.set_index("sample_id").reindex(meta.sample_id)[columns]
            part = part.reset_index(drop=True)
            if spec.get("prefix"):
                part = part.add_prefix(spec["prefix"] + "__")
            pieces.append(part)
        branches[name] = pd.concat(pieces, axis=1)
        if branches[name].columns.duplicated().any() or branches[name].shape[1] == 0:
            raise ValueError(f"{name}: empty or ambiguous feature names; use distinct family prefixes.")
        if name == "IMET":
            values = branches[name].apply(pd.to_numeric, errors="coerce")
            if values.shape[1] != 1 or values.isna().any().any() or not values.iloc[:, 0].between(0, 1).all():
                raise ValueError("IMET branch requires exactly one observed decoder probability in [0,1].")
            branches[name] = values
    if required_branches is not None and set(required_branches) - set(branches):
        raise ValueError(f"Configuration missing locked branches: {sorted(set(required_branches) - set(branches))}")
    if cfg.get("feature_provenance") not in ("patient_local_or_independently_frozen", "synthetic_demo"):
        raise ValueError("Declare feature_provenance. Cohort-wide learned encoders/PCA/habitat centres are not OOF features.")
    return Dataset(meta.reset_index(drop=True), branches, cfg)


def align_to_schema(branches, schema):
    result = {}
    for name, columns in schema.items():
        if name not in branches:
            raise ValueError(f"Locked model requires branch {name}; missing modalities are not simulated.")
        missing = set(columns) - set(branches[name])
        if missing:
            raise ValueError(f"{name}: missing locked features: {sorted(missing)[:10]}")
        result[name] = branches[name].loc[:, columns]
    return result

