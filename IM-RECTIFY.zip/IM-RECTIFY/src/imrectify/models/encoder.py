# PUBLIC RELEASE: author-supplied architecture, without clinical training weights.
# See SOURCE_PROVENANCE.json and docs/METHODS_MAPPING.md for scope and changes.
#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
TA-MambaNeXt-ResNet3D
=====================
A modern 3D MRI feature extractor for ADC / T2WI / DCE.

Design inspirations
-------------------
1) ResNet18/50: stable residual backbone.
2) ConvNeXt V2 (CVPR 2023): depthwise conv + LayerNorm + GELU + GRN.
3) RepLKNet (CVPR 2022): large-kernel depthwise convolution for large receptive fields.
4) MambaVision / visual SSM direction (CVPR 2025): global sequence modeling.
5) Tumor-aware multi-scale pooling: task-specific intra/peritumoral representation.

This implementation is deliberately dependency-light:
- Required: torch, numpy
- Optional: mamba-ssm. If installed and --global-mixer mamba is used, a real Mamba
  block is used on pooled 3D tokens. Otherwise the code can use a Transformer fallback.

Input
-----
image: [B, 1, D, H, W]
mask : [B, 1, D, H, W], binary tumor mask (0/1)

Output
------
feature: [B, feature_dim]
Default feature_dim = 515.
The default output is therefore 515 deep-learning features per case.

Typical usage
-------------
model = build_ta_mambanext_resnet3d(
    backbone="resnet18",
    feature_dim=515,
    global_mixer="mamba",   # or "transformer" / "none"
    use_peritumor=True,
)
feature = model(image, mask)

For ADC/T2WI/DCE, use the same architecture definition. You may train three independent
encoders, or share weights if your upstream training protocol is designed for that.
"""

from __future__ import annotations

import argparse
import json
import math
import warnings
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


# =============================================================================
# 1. Normalization / utility layers
# =============================================================================


class LayerNorm3D(nn.Module):
    """Channel-wise LayerNorm for NCDHW tensors."""

    def __init__(self, channels: int, eps: float = 1e-6):
        super().__init__()
        self.norm = nn.LayerNorm(channels, eps=eps)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.permute(0, 2, 3, 4, 1)  # N D H W C
        x = self.norm(x)
        return x.permute(0, 4, 1, 2, 3).contiguous()


class GRN3D(nn.Module):
    """ConvNeXt V2-style Global Response Normalization for 3D feature maps."""

    def __init__(self, channels: int, eps: float = 1e-6):
        super().__init__()
        self.gamma = nn.Parameter(torch.zeros(1, channels, 1, 1, 1))
        self.beta = nn.Parameter(torch.zeros(1, channels, 1, 1, 1))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        gx = torch.norm(x, p=2, dim=(2, 3, 4), keepdim=True)
        nx = gx / (gx.mean(dim=1, keepdim=True) + self.eps)
        return x + self.gamma * (x * nx) + self.beta


class DropPath(nn.Module):
    """Stochastic depth."""

    def __init__(self, drop_prob: float = 0.0):
        super().__init__()
        self.drop_prob = float(drop_prob)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.drop_prob <= 0.0 or not self.training:
            return x
        keep = 1.0 - self.drop_prob
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)
        rnd = keep + torch.rand(shape, dtype=x.dtype, device=x.device)
        rnd.floor_()
        return x * rnd / keep


# =============================================================================
# 2. ResNet3D backbone
# =============================================================================


class BasicBlock3D(nn.Module):
    expansion = 1

    def __init__(self, in_ch: int, out_ch: int, stride: int = 1):
        super().__init__()
        self.conv1 = nn.Conv3d(in_ch, out_ch, 3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm3d(out_ch)
        self.conv2 = nn.Conv3d(out_ch, out_ch, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm3d(out_ch)
        self.act = nn.ReLU(inplace=True)
        self.down = None
        if stride != 1 or in_ch != out_ch:
            self.down = nn.Sequential(
                nn.Conv3d(in_ch, out_ch, 1, stride=stride, bias=False),
                nn.BatchNorm3d(out_ch),
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x if self.down is None else self.down(x)
        x = self.act(self.bn1(self.conv1(x)))
        x = self.bn2(self.conv2(x))
        return self.act(x + identity)


class Bottleneck3D(nn.Module):
    expansion = 4

    def __init__(self, in_ch: int, planes: int, stride: int = 1):
        super().__init__()
        out_ch = planes * self.expansion
        self.conv1 = nn.Conv3d(in_ch, planes, 1, bias=False)
        self.bn1 = nn.BatchNorm3d(planes)
        self.conv2 = nn.Conv3d(planes, planes, 3, stride=stride, padding=1, bias=False)
        self.bn2 = nn.BatchNorm3d(planes)
        self.conv3 = nn.Conv3d(planes, out_ch, 1, bias=False)
        self.bn3 = nn.BatchNorm3d(out_ch)
        self.act = nn.ReLU(inplace=True)
        self.down = None
        if stride != 1 or in_ch != out_ch:
            self.down = nn.Sequential(
                nn.Conv3d(in_ch, out_ch, 1, stride=stride, bias=False),
                nn.BatchNorm3d(out_ch),
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x if self.down is None else self.down(x)
        x = self.act(self.bn1(self.conv1(x)))
        x = self.act(self.bn2(self.conv2(x)))
        x = self.bn3(self.conv3(x))
        return self.act(x + identity)


class ResNet3DBackbone(nn.Module):
    def __init__(self, depth: int = 18, in_channels: int = 1, base_channels: int = 32):
        super().__init__()
        if depth == 18:
            block, layers = BasicBlock3D, (2, 2, 2, 2)
        elif depth == 50:
            block, layers = Bottleneck3D, (3, 4, 6, 3)
        else:
            raise ValueError("depth must be 18 or 50")

        self.block = block
        self.inplanes = base_channels
        self.stem = nn.Sequential(
            nn.Conv3d(in_channels, base_channels, kernel_size=5, stride=2, padding=2, bias=False),
            nn.BatchNorm3d(base_channels),
            nn.ReLU(inplace=True),
            nn.MaxPool3d(kernel_size=3, stride=2, padding=1),
        )
        self.layer1 = self._make_layer(base_channels, layers[0], stride=1)
        self.layer2 = self._make_layer(base_channels * 2, layers[1], stride=2)
        self.layer3 = self._make_layer(base_channels * 4, layers[2], stride=2)
        self.layer4 = self._make_layer(base_channels * 8, layers[3], stride=2)

        e = block.expansion
        self.channels = (
            base_channels * 2 * e,
            base_channels * 4 * e,
            base_channels * 8 * e,
        )

    def _make_layer(self, planes: int, blocks: int, stride: int):
        layers = [self.block(self.inplanes, planes, stride=stride)]
        self.inplanes = planes * self.block.expansion
        for _ in range(1, blocks):
            layers.append(self.block(self.inplanes, planes, stride=1))
        return nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        x = self.stem(x)
        x = self.layer1(x)
        x2 = self.layer2(x)
        x3 = self.layer3(x2)
        x4 = self.layer4(x3)
        return x2, x3, x4


# =============================================================================
# 3. Modern blocks: ConvNeXt V2 + large-kernel convolution
# =============================================================================


class ConvNeXtV2Block3D(nn.Module):
    """3D adaptation of the ConvNeXt V2 block concept."""

    def __init__(self, channels: int, expansion: int = 4, drop_path: float = 0.0):
        super().__init__()
        hidden = channels * expansion
        self.dw = nn.Conv3d(channels, channels, 7, padding=3, groups=channels)
        self.norm = LayerNorm3D(channels)
        self.pw1 = nn.Conv3d(channels, hidden, 1)
        self.act = nn.GELU()
        self.grn = GRN3D(hidden)
        self.pw2 = nn.Conv3d(hidden, channels, 1)
        self.drop_path = DropPath(drop_path)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.dw(x)
        x = self.norm(x)
        x = self.act(self.pw1(x))
        x = self.grn(x)
        x = self.pw2(x)
        return residual + self.drop_path(x)


class RepLargeKernelBlock3D(nn.Module):
    """
    RepLKNet-inspired large-kernel depthwise residual block.

    3D MRI memory cost grows quickly, so default kernel=7 rather than 31.
    The conceptual contribution is large effective receptive field, not copying the exact 2D kernel size.
    """

    def __init__(self, channels: int, kernel_size: int = 7, drop_path: float = 0.0):
        super().__init__()
        if kernel_size % 2 == 0:
            raise ValueError("kernel_size must be odd")
        p = kernel_size // 2
        self.large = nn.Conv3d(
            channels, channels, kernel_size, padding=p, groups=channels, bias=False
        )
        self.small = nn.Conv3d(channels, channels, 3, padding=1, groups=channels, bias=False)
        self.norm = LayerNorm3D(channels)
        self.ffn = nn.Sequential(
            nn.Conv3d(channels, channels * 4, 1),
            nn.GELU(),
            GRN3D(channels * 4),
            nn.Conv3d(channels * 4, channels, 1),
        )
        self.drop_path = DropPath(drop_path)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.large(x) + self.small(x)
        y = self.norm(y)
        y = self.ffn(y)
        return x + self.drop_path(y)


# =============================================================================
# 4. Global context: real Mamba when available, Transformer fallback
# =============================================================================


class GlobalTokenMixer3D(nn.Module):
    def __init__(
        self,
        channels: int,
        mixer: str = "mamba",
        token_grid: Sequence[int] = (4, 4, 4),
        transformer_heads: int = 8,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.channels = channels
        self.mixer_name = mixer.lower()
        self.token_grid = tuple(int(x) for x in token_grid)
        self.pre = LayerNorm3D(channels)
        self.post = nn.Conv3d(channels, channels, 1)

        if self.mixer_name == "mamba":
            try:
                from mamba_ssm import Mamba
                self.mixer = Mamba(d_model=channels, d_state=16, d_conv=4, expand=2)
                self.actual_mixer = "mamba"
            except Exception:
                warnings.warn(
                    "mamba_ssm is unavailable; falling back to TransformerEncoder. "
                    "Install with `pip install mamba-ssm` to use real Mamba.",
                    RuntimeWarning,
                )
                self.mixer = self._make_transformer(channels, transformer_heads, dropout)
                self.actual_mixer = "transformer_fallback"
        elif self.mixer_name == "transformer":
            self.mixer = self._make_transformer(channels, transformer_heads, dropout)
            self.actual_mixer = "transformer"
        elif self.mixer_name == "none":
            self.mixer = nn.Identity()
            self.actual_mixer = "none"
        else:
            raise ValueError("mixer must be mamba / transformer / none")

    @staticmethod
    def _make_transformer(channels: int, heads: int, dropout: float):
        # Make heads valid for arbitrary ResNet50 channels.
        valid = [h for h in range(min(heads, channels), 0, -1) if channels % h == 0]
        h = valid[0]
        layer = nn.TransformerEncoderLayer(
            d_model=channels,
            nhead=h,
            dim_feedforward=channels * 2,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        return nn.TransformerEncoder(layer, num_layers=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.pre(x)
        pooled = F.adaptive_avg_pool3d(x, self.token_grid)
        b, c, d, h, w = pooled.shape
        tokens = pooled.flatten(2).transpose(1, 2)  # B,L,C
        tokens = self.mixer(tokens)
        pooled = tokens.transpose(1, 2).reshape(b, c, d, h, w)
        pooled = F.interpolate(pooled, size=residual.shape[-3:], mode="trilinear", align_corners=False)
        return residual + self.post(pooled)


# =============================================================================
# 5. Tumor-aware multi-scale pooling
# =============================================================================


def masked_average(feature: torch.Tensor, mask: torch.Tensor, eps: float = 1e-6):
    num = (feature * mask).sum(dim=(2, 3, 4))
    den = mask.sum(dim=(2, 3, 4)).clamp_min(eps)
    return num / den


class TumorAwarePool3D(nn.Module):
    """
    For each scale, pool three complementary representations:
      global context + intratumoral mask + peritumoral ring.
    """

    def __init__(self, channels: int, out_dim: int = 128, use_peritumor: bool = True):
        super().__init__()
        self.use_peritumor = use_peritumor
        n_parts = 3 if use_peritumor else 2
        self.proj = nn.Sequential(
            nn.Linear(channels * n_parts, out_dim),
            nn.LayerNorm(out_dim),
            nn.GELU(),
        )

    def forward(self, x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        m = F.interpolate(mask.float(), size=x.shape[-3:], mode="nearest")
        m = (m > 0.5).float()
        global_vec = x.mean(dim=(2, 3, 4))
        intra = masked_average(x, m)

        parts = [global_vec, intra]
        if self.use_peritumor:
            # Relative ring in feature space. Kernel 5 gives a modest context band at each scale.
            dil = F.max_pool3d(m, kernel_size=5, stride=1, padding=2)
            ring = (dil - m).clamp(0.0, 1.0)
            ring_count = ring.sum(dim=(2, 3, 4), keepdim=False)
            peri = masked_average(x, ring)
            # If the ring vanishes because the crop is too tight, use global context as a stable fallback.
            peri = torch.where((ring_count > 0).expand_as(peri), peri, global_vec)
            parts.append(peri)

        return self.proj(torch.cat(parts, dim=1))


# =============================================================================
# 6. Final extractor
# =============================================================================


@dataclass
class ExtractorConfig:
    backbone: str = "resnet18"
    in_channels: int = 1
    base_channels: int = 32
    feature_dim: int = 515
    scale_dim: int = 128
    large_kernel: int = 7
    global_mixer: str = "mamba"
    use_peritumor: bool = True
    dropout: float = 0.25


class TAMambaNeXtResNet3D(nn.Module):
    """Tumor-aware modernized ResNet3D feature extractor."""

    def __init__(self, cfg: ExtractorConfig):
        super().__init__()
        self.cfg = cfg
        depth = 18 if cfg.backbone.lower() == "resnet18" else 50
        if cfg.backbone.lower() not in {"resnet18", "resnet50"}:
            raise ValueError("backbone must be resnet18 or resnet50")

        self.backbone = ResNet3DBackbone(depth, cfg.in_channels, cfg.base_channels)
        c2, c3, c4 = self.backbone.channels

        # Stage 2: ConvNeXt V2-style local modernization.
        self.modern2 = ConvNeXtV2Block3D(c2, drop_path=0.03)

        # Stage 3: large-kernel morphology modeling + ConvNeXt V2 refinement.
        self.modern3 = nn.Sequential(
            RepLargeKernelBlock3D(c3, kernel_size=cfg.large_kernel, drop_path=0.05),
            ConvNeXtV2Block3D(c3, drop_path=0.05),
        )

        # Stage 4: global sequence/context modeling.
        self.modern4_local = ConvNeXtV2Block3D(c4, drop_path=0.08)
        self.global_mixer = GlobalTokenMixer3D(c4, mixer=cfg.global_mixer, token_grid=(4, 4, 4))

        self.pool2 = TumorAwarePool3D(c2, cfg.scale_dim, cfg.use_peritumor)
        self.pool3 = TumorAwarePool3D(c3, cfg.scale_dim, cfg.use_peritumor)
        self.pool4 = TumorAwarePool3D(c4, cfg.scale_dim, cfg.use_peritumor)

        self.fusion = nn.Sequential(
            nn.Linear(cfg.scale_dim * 3, cfg.feature_dim * 2),
            nn.LayerNorm(cfg.feature_dim * 2),
            nn.GELU(),
            nn.Dropout(cfg.dropout),
            nn.Linear(cfg.feature_dim * 2, cfg.feature_dim),
            nn.LayerNorm(cfg.feature_dim),
        )

    def forward(
        self,
        image: torch.Tensor,
        mask: torch.Tensor,
        return_multiscale: bool = False,
    ):
        if image.ndim != 5 or mask.ndim != 5:
            raise ValueError("image and mask must be [B,C,D,H,W]")
        x2, x3, x4 = self.backbone(image)
        x2 = self.modern2(x2)
        x3 = self.modern3(x3)
        x4 = self.global_mixer(self.modern4_local(x4))

        z2 = self.pool2(x2, mask)
        z3 = self.pool3(x3, mask)
        z4 = self.pool4(x4, mask)
        feature = self.fusion(torch.cat([z2, z3, z4], dim=1))

        if return_multiscale:
            return {
                "feature": feature,
                "stage2_embedding": z2,
                "stage3_embedding": z3,
                "stage4_embedding": z4,
                "global_mixer": self.global_mixer.actual_mixer,
            }
        return feature


def build_ta_mambanext_resnet3d(
    backbone: str = "resnet18",
    feature_dim: int = 515,
    global_mixer: str = "mamba",
    use_peritumor: bool = True,
    base_channels: int = 32,
) -> TAMambaNeXtResNet3D:
    return TAMambaNeXtResNet3D(
        ExtractorConfig(
            backbone=backbone,
            feature_dim=feature_dim,
            global_mixer=global_mixer,
            use_peritumor=use_peritumor,
            base_channels=base_channels,
        )
    )


# =============================================================================
# 7. Extraction helpers
# =============================================================================


@torch.no_grad()
def extract_features(
    model: nn.Module,
    image: torch.Tensor,
    mask: torch.Tensor,
    device: Optional[torch.device] = None,
) -> np.ndarray:
    if device is None:
        device = next(model.parameters()).device
    model.eval()
    feature = model(image.to(device), mask.to(device))
    return feature.detach().cpu().numpy()


def load_checkpoint(model: nn.Module, checkpoint: Path, strict: bool = True):
    payload = torch.load(checkpoint, map_location="cpu")
    state = payload.get("state_dict", payload) if isinstance(payload, dict) else payload
    model.load_state_dict(state, strict=strict)
    return model


def save_checkpoint(model: TAMambaNeXtResNet3D, path: Path, extra: Optional[Dict] = None):
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "architecture": "TA-MambaNeXt-ResNet3D",
        "config": asdict(model.cfg),
        "global_mixer_actual": model.global_mixer.actual_mixer,
        "state_dict": model.state_dict(),
    }
    if extra:
        payload["extra"] = extra
    torch.save(payload, path)


# =============================================================================
