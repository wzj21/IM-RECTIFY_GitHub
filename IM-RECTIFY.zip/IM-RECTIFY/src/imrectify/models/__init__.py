"""MRI encoder and tabular multimodal fusion architectures."""

