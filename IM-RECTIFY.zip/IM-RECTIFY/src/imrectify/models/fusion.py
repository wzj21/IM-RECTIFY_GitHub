"""GIFM/TFM architectures adapted from the supplied five-branch scripts."""
from __future__ import annotations

import numpy as np
import torch
from torch import nn


def branch_encoder(dimension, hidden=48, latent=24, dropout=0.35):
    return nn.Sequential(
        nn.Linear(dimension, hidden), nn.LayerNorm(hidden), nn.GELU(), nn.Dropout(dropout),
        nn.Linear(hidden, latent), nn.LayerNorm(latent), nn.GELU(),
    )


class GatedFusion(nn.Module):
    def __init__(self, dimensions, hidden=48, latent=24, dropout=0.35):
        super().__init__()
        self.encoders = nn.ModuleList([branch_encoder(d, hidden, latent, dropout) for d in dimensions])
        self.gate = nn.Sequential(nn.Linear(latent, latent), nn.GELU(), nn.Linear(latent, 1))
        self.head = nn.Sequential(nn.Linear(latent, 32), nn.GELU(), nn.Dropout(dropout), nn.Linear(32, 1))

    def forward(self, *inputs, return_weights=False):
        tokens = torch.stack([encoder(x) for encoder, x in zip(self.encoders, inputs)], dim=1)
        weights = torch.softmax(self.gate(tokens).squeeze(-1), dim=1)
        fused = torch.sum(tokens * weights.unsqueeze(-1), dim=1)
        logits = self.head(fused).squeeze(-1)
        return (logits, weights) if return_weights else logits


class TransformerFusion(nn.Module):
    def __init__(self, dimensions, hidden=48, latent=24, dropout=0.35, heads=2):
        super().__init__()
        if latent % heads:
            raise ValueError("latent must be divisible by heads.")
        self.encoders = nn.ModuleList([branch_encoder(d, hidden, latent, dropout) for d in dimensions])
        self.cls = nn.Parameter(torch.zeros(1, 1, latent))
        self.modality_embeddings = nn.Parameter(torch.zeros(1, len(dimensions) + 1, latent))
        layer = nn.TransformerEncoderLayer(
            d_model=latent, nhead=heads, dim_feedforward=latent * 2, dropout=dropout,
            activation="gelu", batch_first=True, norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(layer, num_layers=1, enable_nested_tensor=False)
        self.norm = nn.LayerNorm(latent)
        self.head = nn.Sequential(nn.Linear(latent, 32), nn.GELU(), nn.Dropout(dropout), nn.Linear(32, 1))
        nn.init.normal_(self.cls, std=0.02)
        nn.init.normal_(self.modality_embeddings, std=0.02)

    def forward(self, *inputs):
        tokens = torch.stack([encoder(x) for encoder, x in zip(self.encoders, inputs)], dim=1)
        cls = self.cls.expand(tokens.shape[0], -1, -1)
        sequence = torch.cat([cls, tokens], dim=1) + self.modality_embeddings
        return self.head(self.norm(self.transformer(sequence)[:, 0])).squeeze(-1)


class NeuralTrainer:
    """Fixed-epoch fitting; epoch count is chosen inside development inner folds."""
    def __init__(self, kind, params=None, seed=42):
        self.kind, self.params, self.seed = kind, dict(params or {}), seed

    def fit(self, arrays, y):
        import random
        from torch.utils.data import DataLoader, TensorDataset

        random.seed(self.seed)
        np.random.seed(self.seed)
        torch.manual_seed(self.seed)
        # Serial CPU is the portable public default. GPU use is an explicit local choice.
        torch.set_num_threads(int(self.params.get("threads", 1)))
        self.device_ = str(self.params.get("device", "cpu"))
        dims = [a.shape[1] for a in arrays]
        self.architecture_ = {"dimensions": dims, "hidden": int(self.params.get("hidden", 48)),
                              "latent": int(self.params.get("latent", 24)),
                              "dropout": float(self.params.get("dropout", 0.35))}
        cls = GatedFusion if self.kind == "GIFM" else TransformerFusion
        self.network_ = cls(**self.architecture_).to(self.device_)
        tensors = [torch.as_tensor(a, dtype=torch.float32) for a in arrays]
        target = torch.as_tensor(np.asarray(y), dtype=torch.float32)
        dataset = TensorDataset(*tensors, target)
        generator = torch.Generator().manual_seed(self.seed)
        loader = DataLoader(dataset, batch_size=int(self.params.get("batch_size", 16)),
                            shuffle=True, generator=generator, num_workers=0)
        optimizer = torch.optim.AdamW(self.network_.parameters(), lr=float(self.params.get("lr", 3e-4)),
                                      weight_decay=float(self.params.get("weight_decay", 5e-3)))
        counts = np.bincount(np.asarray(y, dtype=int), minlength=2)
        if not np.all(counts > 0):
            raise ValueError("Neural fitting requires both observed outcome classes.")
        positive_weight = float(np.clip(np.sqrt(counts[0] / counts[1]), 0.75, 2.5))
        criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(positive_weight, device=self.device_))
        epochs = int(self.params.get("epochs", 40))
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(epochs, 1), eta_min=1e-6)
        self.training_settings_ = {"positive_weight": positive_weight, "epochs": epochs,
                                   "scheduler": "cosine", "minimum_lr": 1e-6}
        self.loss_ = []
        for _ in range(epochs):
            self.network_.train()
            total = 0.0
            for batch in loader:
                *xs, outcome = [tensor.to(self.device_) for tensor in batch]
                optimizer.zero_grad(set_to_none=True)
                loss = criterion(self.network_(*xs), outcome)
                loss.backward()
                nn.utils.clip_grad_norm_(self.network_.parameters(), 1.0)
                optimizer.step()
                total += float(loss.detach()) * len(outcome)
            self.loss_.append(total / len(y))
            scheduler.step()
        self.network_.to("cpu").eval()
        return self

    def predict(self, arrays, return_weights=False):
        tensors = [torch.as_tensor(a, dtype=torch.float32) for a in arrays]
        self.network_.eval()
        probabilities, weights = [], []
        with torch.no_grad():
            for start in range(0, len(arrays[0]), 128):
                xs = [x[start:start + 128] for x in tensors]
                if return_weights and self.kind == "GIFM":
                    logits, gate = self.network_(*xs, return_weights=True)
                    weights.append(gate.numpy())
                else:
                    logits = self.network_(*xs)
                probabilities.append(torch.sigmoid(logits).numpy())
        p = np.concatenate(probabilities)
        return (p, np.concatenate(weights)) if weights else p

