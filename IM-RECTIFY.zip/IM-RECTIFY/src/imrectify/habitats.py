"""K=4 patient-local habitats, physical composition and spatial interfaces."""
from __future__ import annotations

from itertools import combinations

import numpy as np
from scipy import ndimage
from sklearn.cluster import KMeans


def roi_standardize(array, mask):
    values = np.asarray(array, float)[mask]
    if not np.isfinite(values).all():
        raise ValueError("Nonfinite intratumoral image intensities.")
    lo, hi = np.percentile(values, [0.5, 99.5])
    clipped = np.clip(np.asarray(array, float), lo, hi)
    return (clipped - clipped[mask].mean()) / max(float(clipped[mask].std()), 1e-8)


def cluster_habitats(images, mask, seed=42):
    if "ADC" not in images or "T2WI" not in images:
        raise ValueError("Patient-local habitats require T2WI+ADC; real DCE is optional.")
    names = [n for n in ("T2WI", "ADC", "DCE") if n in images]
    x = np.column_stack([roi_standardize(images[n], mask)[mask] for n in names])
    if len(x) < 16 or len(np.unique(x, axis=0)) < 4:
        raise ValueError("Not enough distinct lesion voxels for four habitats.")
    model = KMeans(n_clusters=4, n_init=20, random_state=seed).fit(x)
    # Fixed ordinal naming avoids cohort-wide centre fitting and arbitrary cluster label permutations.
    adc_index = names.index("ADC")
    order = np.lexsort((model.cluster_centers_[:, 0], model.cluster_centers_[:, adc_index]))
    mapping = np.zeros(4, dtype=int)
    mapping[order] = np.arange(1, 5)
    labels = np.zeros(mask.shape, dtype=np.uint8)
    labels[mask] = mapping[model.labels_]
    return labels, {"k": 4, "method": "patient-local k-means",
                    "naming": "ascending standardized ADC, then T2WI", "modalities": names,
                    "centres": model.cluster_centers_[order].tolist()}


def spatial_features(labels, spacing_zyx=(1, 1, 1)):
    mask = labels > 0
    counts = np.bincount(labels[mask], minlength=5)[1:5].astype(float)
    total = max(float(counts.sum()), 1)
    p = counts / total
    voxel_volume = float(np.prod(spacing_zyx))
    positive = p[p > 0]
    entropy = float(-np.sum(positive * np.log(positive)))
    result = {"composition__shannon_entropy": entropy,
              "composition__simpson_diversity": float(1 - np.sum(p ** 2)),
              "composition__pielou_evenness": entropy / np.log(4)}
    for i in range(1, 5):
        components, n = ndimage.label(labels == i, structure=ndimage.generate_binary_structure(3, 1))
        sizes = np.bincount(components.ravel())[1:]
        result.update({f"H{i}__volume_mm3": counts[i - 1] * voxel_volume,
                       f"H{i}__fraction": p[i - 1], f"H{i}__components": int(n),
                       f"H{i}__largest_component_mm3": float(sizes.max(initial=0)) * voxel_volume,
                       f"H{i}__fragmentation": float(1 - sizes.max(initial=0) / max(counts[i - 1], 1))})
    adjacency = np.zeros((4, 4), float)
    total_faces = 0.0
    for axis in range(3):
        left, right = [slice(None)] * 3, [slice(None)] * 3
        left[axis], right[axis] = slice(None, -1), slice(1, None)
        a, b = labels[tuple(left)], labels[tuple(right)]
        changed = (a > 0) & (b > 0) & (a != b)
        area = float(np.prod([v for j, v in enumerate(spacing_zyx) if j != axis]))
        for i, j in combinations(range(1, 5), 2):
            contact = np.sum(changed & (((a == i) & (b == j)) | ((a == j) & (b == i)))) * area
            adjacency[i - 1, j - 1] += contact
            adjacency[j - 1, i - 1] += contact
        total_faces += float(changed.sum()) * area
    for i, j in combinations(range(1, 5), 2):
        contact = float(adjacency[i - 1, j - 1])
        result[f"contact__H{i}_H{j}_mm2"] = contact
        result[f"boundary_fraction__H{i}_H{j}"] = contact / max(total_faces, 1e-12)
    # Row-normalized contact mixing matrix; definition is explicit rather than an ambiguous MSI acronym.
    mixing = adjacency / np.maximum(adjacency.sum(axis=1, keepdims=True), 1e-12)
    for i in range(4):
        for j in range(4):
            result[f"mixing__H{i + 1}_H{j + 1}"] = float(mixing[i, j])
    result["interface__area_mm2"] = total_faces
    result["interface__area_per_volume_mm_inverse"] = total_faces / max(total * voxel_volume, 1e-12)
    return result


def cross_habitat_features(features):
    keys = sorted(set.intersection(*(set(features[i]) for i in range(1, 5))))
    result = {}
    for key in keys:
        values = np.asarray([features[i][key] for i in range(1, 5)], float)
        if not np.isfinite(values).all():
            continue
        result[f"cross__{key}__range"] = float(np.ptp(values))
        result[f"cross__{key}__CV"] = float(values.std() / abs(values.mean())) if abs(values.mean()) > 1e-8 else np.nan
        for i, j in combinations(range(4), 2):
            result[f"cross__{key}__H{i + 1}_minus_H{j + 1}"] = float(values[i] - values[j])
    return result

