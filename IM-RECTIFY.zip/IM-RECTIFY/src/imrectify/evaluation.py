"""Unsmoothed ROC, empirical calibration and net benefit from held-out probabilities."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import logit
from sklearn.calibration import calibration_curve
from sklearn.metrics import brier_score_loss, confusion_matrix, roc_auc_score, roc_curve


COLORS = {"CM": "#737373", "IMM": "#b56b9b", "EFM": "#d99a39", "GIFM": "#238b76", "LFM": "#4d79b0", "TFM": "#bf5b52"}


def _point_metrics(y, p):
    tn, fp, fn, tp = confusion_matrix(y, p >= 0.5, labels=[0, 1]).ravel()
    sensitivity, specificity = tp / (tp + fn), tn / (tn + fp)
    return {"AUROC": roc_auc_score(y, p), "Brier": brier_score_loss(y, p),
            "sensitivity": sensitivity, "specificity": specificity,
            "balanced_accuracy": 0.5 * (sensitivity + specificity),
            "accuracy": (tp + tn) / len(y),
            "precision": tp / (tp + fp) if tp + fp else np.nan,
            "NPV": tn / (tn + fn) if tn + fn else np.nan,
            "F1": 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else np.nan}


def summarize(y, p, bootstrap=1000, seed=42):
    y, p = np.asarray(y), np.asarray(p, float)
    if y.ndim != 1 or p.ndim != 1 or len(y) != len(p) or not np.isin(y, [0, 1]).all():
        raise ValueError("Outcome and probability vectors must align, with observed 0/1 outcomes.")
    if len(np.unique(y)) != 2 or not np.isfinite(p).all() or np.any((p < 0) | (p > 1)):
        raise ValueError("Evaluation requires two observed classes and finite probabilities in [0,1].")
    if int(bootstrap) != bootstrap or bootstrap < 0:
        raise ValueError("bootstrap must be a nonnegative integer.")
    y = y.astype(int)
    tn, fp, fn, tp = confusion_matrix(y, p >= 0.5, labels=[0, 1]).ravel()
    rng = np.random.default_rng(seed)
    point = _point_metrics(y, p)
    draws = {name: [] for name in point}
    for _ in range(bootstrap):
        sample = np.concatenate([rng.choice(np.flatnonzero(y == c), size=int((y == c).sum()), replace=True) for c in (0, 1)])
        values = _point_metrics(y[sample], p[sample])
        for name, value in values.items():
            if np.isfinite(value):
                draws[name].append(value)
    intervals = {}
    for name, values in draws.items():
        low, high = np.percentile(values, [2.5, 97.5]) if values else (np.nan, np.nan)
        intervals.update({name + "_CI_low": low, name + "_CI_high": high,
                          name + "_CI_valid_resamples": len(values)})
    intercept = slope = np.nan
    from statsmodels.tools.sm_exceptions import PerfectSeparationError
    try:
        import statsmodels.api as sm
        fitted = sm.GLM(y, sm.add_constant(logit(np.clip(p, 1e-6, 1 - 1e-6))), family=sm.families.Binomial()).fit()
        intercept, slope = map(float, fitted.params)
    except (ValueError, np.linalg.LinAlgError, PerfectSeparationError):
        pass
    return {"n": len(y), "pcr_or_positive_n": int(y.sum()), **point, **intervals, "threshold": 0.5,
            "calibration_intercept": intercept, "calibration_slope": slope,
            "TN": int(tn), "FP": int(fp), "FN": int(fn), "TP": int(tp)}


def net_benefit(y, p, thresholds):
    y, p = np.asarray(y), np.asarray(p)
    return np.asarray([np.mean((p >= t) & (y == 1)) - np.mean((p >= t) & (y == 0)) * t / (1 - t) for t in thresholds])


def evaluate(table, output, tnt_only=True, bootstrap=1000):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    data = table.loc[table.label.notna()].copy()
    if tnt_only:
        data = data.loc[data.treatment.eq(0)].copy()
    columns = [c for c in table if c.startswith("prob_")]
    # One statistical unit per real patient, including repeated imaging records.
    if data.groupby("patient_id").label.nunique().gt(1).any():
        raise ValueError("Conflicting patient outcomes.")
    data = data.groupby("patient_id", as_index=False).agg({"label": "first", **{c: "mean" for c in columns}})
    y = data.label.to_numpy()
    metrics, source = [], []
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "svg.fonttype": "none",
                         "axes.spines.top": False, "axes.spines.right": False})
    figs = {key: plt.subplots(figsize=(5.0, 4.2), layout="constrained") for key in ("ROC", "calibration", "DCA")}
    thresholds = np.linspace(0.01, 0.99, 99)
    for column in columns:
        name = column.removeprefix("prob_")
        p = data[column].to_numpy(float)
        result = {"model": name, **summarize(y, p, bootstrap)}
        metrics.append(result)
        color = COLORS.get(name, "#333333")
        fpr, tpr, _ = roc_curve(y, p)
        figs["ROC"][1].plot(fpr, tpr, color=color, lw=1.6, label=f"{name}: {result['AUROC']:.3f}")
        observed, predicted = calibration_curve(y, p, n_bins=min(8, len(y)), strategy="quantile")
        figs["calibration"][1].plot(predicted, observed, "o-", ms=3, color=color, label=name)
        benefit = net_benefit(y, p, thresholds)
        figs["DCA"][1].plot(thresholds, benefit, color=color, lw=1.4, label=name)
        source.extend({"model": name, "threshold": t, "net_benefit": b} for t, b in zip(thresholds, benefit))
    for name, (figure, axis) in figs.items():
        if name in {"ROC", "calibration"}:
            axis.plot([0, 1], [0, 1], "--", color="0.65", lw=0.9)
            axis.set(xlim=(0, 1), ylim=(0, 1), xlabel="1 - specificity" if name == "ROC" else "Predicted probability",
                     ylabel="Sensitivity" if name == "ROC" else "Observed proportion")
        else:
            prevalence = y.mean()
            axis.plot(thresholds, prevalence - (1 - prevalence) * thresholds / (1 - thresholds),
                      "--", color="0.55", lw=0.9, label="Treat all")
            axis.axhline(0, color="0.3", lw=0.9, label="Treat none")
            axis.set(xlim=(0, 1), ylim=(-0.05, max(float(prevalence), 0.1) + 0.05),
                     xlabel="Threshold probability", ylabel="Net benefit")
        axis.legend(frameon=False, fontsize=8)
        for extension in ("png", "svg", "pdf"):
            figure.savefig(output / f"{name}.{extension}", dpi=300)
        plt.close(figure)
    pd.DataFrame(metrics).to_csv(output / "performance.csv", index=False)
    comparisons = []
    for i, first in enumerate(columns):
        for second in columns[i + 1:]:
            comparisons.append({"model_A": first.removeprefix("prob_"),
                                "model_B": second.removeprefix("prob_"),
                                **paired_auroc_difference(y, data[first], data[second], bootstrap)})
    pd.DataFrame(comparisons).to_csv(output / "paired_AUROC_comparisons.csv", index=False)
    pd.DataFrame(source).to_csv(output / "DCA_source_data.csv", index=False)
    (output / "evaluation_notes.json").write_text(json.dumps({
        "threshold": 0.5, "bootstrap": bootstrap, "unit": "real patient", "TNT_only_filter": tnt_only,
        "CI_scope": "conditional on the available held-out predictions; model fitting uncertainty is not re-estimated",
        "DCA_scope": "pCR prediction net benefit; this is not a causal ICI treatment-policy DCA",
    }, indent=2), encoding="utf-8")
    return metrics


def paired_auroc_difference(y, first, second, bootstrap=1000, seed=42):
    """Patient-paired percentile CI; predictions are fixed, not refitted."""
    y, first, second = np.asarray(y), np.asarray(first, float), np.asarray(second, float)
    summarize(y, first, bootstrap=0)
    summarize(y, second, bootstrap=0)
    if int(bootstrap) != bootstrap or bootstrap < 0:
        raise ValueError("bootstrap must be a nonnegative integer.")
    rng = np.random.default_rng(seed)
    draws = []
    for _ in range(bootstrap):
        indices = np.concatenate([rng.choice(np.flatnonzero(y == c), int((y == c).sum()), replace=True)
                                  for c in (0, 1)])
        draws.append(roc_auc_score(y[indices], first[indices]) -
                     roc_auc_score(y[indices], second[indices]))
    low, high = np.percentile(draws, [2.5, 97.5]) if draws else (np.nan, np.nan)
    return {"AUROC_difference": roc_auc_score(y, first) - roc_auc_score(y, second),
            "CI_low": low, "CI_high": high, "valid_resamples": len(draws)}

