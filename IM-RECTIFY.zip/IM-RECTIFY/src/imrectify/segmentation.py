"""Separate nnU-Net dataset export and independent mask evaluation."""
from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd

from .imaging import same_geometry


def export_nnunet(manifest, output):
    import SimpleITK as sitk

    manifest = Path(manifest).resolve()
    frame = pd.read_csv(manifest, dtype={"sample_id": str, "patient_id": str})
    if not {"sample_id", "patient_id", "case_dir"}.issubset(frame) or frame.sample_id.duplicated().any():
        raise ValueError("nnU-Net manifest requires sample_id, real patient_id, case_dir.")
    if frame.patient_id.duplicated().any():
        raise ValueError("Select one baseline scan per patient before this independent segmentation benchmark export.")
    output = Path(output)
    if output.exists() and any(output.iterdir()):
        raise FileExistsError("Choose a new, empty nnU-Net export directory.")
    for folder in ("imagesTr", "labelsTr"):
        (output / folder).mkdir(parents=True, exist_ok=True)
    mappings = []
    for i, record in enumerate(frame.to_dict("records")):
        case = manifest.parent / record["case_dir"]
        image = sitk.ReadImage(str(case / "T2WI.nii.gz"))
        mask = sitk.ReadImage(str(case / "MASK.nii.gz"))
        if not same_geometry(image, mask):
            raise ValueError("nnU-Net training image and manual reference mask must share physical geometry.")
        name = f"case_{i:05d}"
        mappings.append({"nnunet_case": name, "sample_id": record["sample_id"], "patient_id": record["patient_id"]})
        shutil.copy2(case / "T2WI.nii.gz", output / "imagesTr" / f"{name}_0000.nii.gz")
        sitk.WriteImage(sitk.Cast(mask > 0, sitk.sitkUInt8), str(output / "labelsTr" / f"{name}.nii.gz"))
    pd.DataFrame(mappings).to_csv(output / "case_mapping_private.csv", index=False)
    (output / "dataset.json").write_text(json.dumps({
        "channel_names": {"0": "T2WI"}, "labels": {"background": 0, "tumor": 1},
        "numTraining": len(frame), "file_ending": ".nii.gz",
    }, indent=2), encoding="utf-8")


def mask_metrics(reference, prediction):
    import SimpleITK as sitk

    reference = sitk.ReadImage(str(reference))
    prediction = sitk.ReadImage(str(prediction))
    if not same_geometry(reference, prediction):
        raise ValueError("Masks must be restored to the same original physical grid before evaluation.")
    a, b = sitk.GetArrayFromImage(reference) > 0, sitk.GetArrayFromImage(prediction) > 0
    denominator = int(a.sum() + b.sum())
    dice = float(2 * (a & b).sum() / denominator) if denominator else 1.0
    return {"Dice": dice, "reference_voxels": int(a.sum()), "prediction_voxels": int(b.sum())}

