"""Patient-level nested cross-fitting and final development-only model locking."""
from __future__ import annotations

import json
import platform
from copy import deepcopy
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from scipy.special import logit
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedGroupKFold

from .data import align_to_schema, identity_hash
from .estimators import FusionModel, grouped_splits, slice_blocks


def training_mask(metadata, task):
    if task == "imet":
        if not metadata.cohort.eq("molecular").all() or metadata.label.isna().any():
            raise ValueError("IMET training requires molecular-cohort RNA-derived C1/C2 labels.")
        return np.ones(len(metadata), dtype=bool)
    if task == "tnt":
        return metadata.treatment.eq(0).to_numpy()
    raise ValueError("task must be imet or tnt.")


def outer_splits(metadata, task, folds=5, seed=42):
    eligible = training_mask(metadata, task)
    groups = metadata.patient_id.to_numpy()
    # ICI outcomes do not even contribute to outer-fold stratification.
    strata = np.where(eligible, "observed_" + metadata.label.astype(str), "ICI_outcome_blind")
    splitter = StratifiedGroupKFold(folds, shuffle=True, random_state=seed)
    result = []
    for train, test in splitter.split(np.zeros(len(metadata)), strata, groups):
        fit = train[eligible[train]]
        if set(groups[fit]) & set(groups[test]):
            raise RuntimeError("Real-patient overlap across outer folds.")
        if len(np.unique(metadata.label.iloc[fit])) < 2:
            raise ValueError("An outer training partition has only one observed class.")
        result.append((fit, test))
    return result


def candidates(cfg, kind):
    values = cfg.get("candidates", {}).get(kind)
    if values:
        return values
    if kind in {"GIFM", "TFM"}:
        return [{"epochs": 40}, {"epochs": 80}]
    return [{"C": 0.1, "lasso_c": 0.5}, {"C": 1.0, "lasso_c": 1.0}]


def tuned_fit(blocks, y, groups, kind, cfg, seed):
    inner_folds = int(cfg.get("inner_folds", 3))
    splits = grouped_splits(y, groups, inner_folds, seed)
    records = []
    for candidate in candidates(cfg, kind):
        prediction = np.full(len(y), np.nan)
        for j, (train, valid) in enumerate(splits):
            model = FusionModel(kind, cfg.get("selection"), candidate, seed + j, inner_folds)
            model.fit(slice_blocks(blocks, train), y[train], groups[train])
            prediction[valid] = model.predict(slice_blocks(blocks, valid))
        records.append({"parameters": candidate, "inner_auroc": float(roc_auc_score(y, prediction))})
    # Stable candidate order breaks ties; outer-test outcomes are never read here.
    best = max(range(len(records)), key=lambda i: records[i]["inner_auroc"])
    parameters = records[best]["parameters"]
    calibration = None
    if cfg.get("calibration", "none") == "sigmoid":
        p = np.full(len(y), np.nan)
        for j, (train, valid) in enumerate(splits):
            model = FusionModel(kind, cfg.get("selection"), parameters, seed + j, inner_folds)
            model.fit(slice_blocks(blocks, train), y[train], groups[train])
            p[valid] = model.predict(slice_blocks(blocks, valid))
        calibration = LogisticRegression(C=1e6, solver="lbfgs", max_iter=3000).fit(
            logit(np.clip(p, 1e-6, 1 - 1e-6)).reshape(-1, 1), y)
    elif cfg.get("calibration", "none") != "none":
        raise ValueError("Supported calibration: none, sigmoid.")
    final = FusionModel(kind, cfg.get("selection"), parameters, seed, inner_folds).fit(blocks, y, groups)
    final.calibrator_ = calibration
    return final, {"candidates": records, "selected": parameters,
                   "calibration": cfg.get("calibration", "none")}


def develop(dataset, output, models=None, lock=True):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    cfg, meta, blocks = dataset.config, dataset.metadata, dataset.branches
    task = cfg["task"]
    models = models or cfg.get("models", ["EFM", "GIFM", "LFM", "TFM"])
    if task == "imet" and set(models) & {"CM", "IMM"}:
        raise ValueError("CM/IMM are stage-2 comparators, not molecular decoder branches.")
    seed = int(cfg.get("seed", 42))
    folds = outer_splits(meta, task, int(cfg.get("outer_folds", 5)), seed)
    predictions = meta.copy()
    if task == "tnt" and "IMET" in blocks:
        if blocks["IMET"].shape[1] != 1:
            raise ValueError("The IMET branch must contain exactly one locked score.")
        predictions["IMET_score"] = blocks["IMET"].iloc[:, 0].to_numpy(float)
    predictions["outer_fold"] = -1
    audits = []
    for kind in models:
        p = np.full(len(meta), np.nan)
        for fold, (train, test) in enumerate(folds):
            print(f"[{task}/{kind}] outer fold {fold + 1}/{len(folds)}", flush=True)
            subset = dataset.subset(train)
            y = subset.metadata.label.to_numpy(dtype=int)
            groups = subset.metadata.patient_id.to_numpy()
            model, tuning = tuned_fit(subset.branches, y, groups, kind, cfg, seed + 100 * fold)
            p[test] = model.predict(slice_blocks(blocks, test))
            predictions.loc[test, "outer_fold"] = fold + 1
            audits.append({"model": kind, "fold": fold + 1, "n_train": len(train), "n_test": len(test),
                           "n_ici_in_outcome_training": int(subset.metadata.treatment.sum()) if task == "tnt" else 0,
                           "training_patient_hashes": sorted({identity_hash(g) for g in groups}),
                           "test_patient_hashes": sorted({identity_hash(g) for g in meta.patient_id.iloc[test]}),
                           "tuning": tuning, "features": model.selection_audit()})
        if not np.isfinite(p).all():
            raise RuntimeError("Incomplete out-of-fold predictions.")
        predictions[f"prob_{kind}"] = p
    primary = cfg.get("primary_model", "GIFM")
    if primary not in models:
        raise ValueError("primary_model must be one of the developed models.")
    score_column = "IMET_score" if task == "imet" else "TNT_pCR_score"
    predictions[score_column] = predictions[f"prob_{primary}"]
    predictions["prediction_scope"] = "patient_held_out"
    if task == "tnt":
        predictions.loc[meta.treatment.eq(1), "prediction_scope"] = "cross_fitted_TNT_probability_for_ICI_recipient"
    predictions.to_csv(output / "cross_fitted_predictions.csv", index=False)
    (output / "fold_audit.json").write_text(json.dumps(audits, indent=2), encoding="utf-8")
    if lock:
        eligible = np.flatnonzero(training_mask(meta, task))
        train = dataset.subset(eligible)
        bundle = {"format_version": 1, "task": task, "primary_model": primary, "models": {},
                  "label_positive": "RNA-defined C1" if task == "imet" else "pCR (ypT0N0)",
                  "threshold": 0.5, "schema": {k: list(v) for k, v in blocks.items()},
                  "training_patient_hashes": sorted({identity_hash(g) for g in train.metadata.patient_id}),
                  "feature_provenance": cfg["feature_provenance"], "runtime": {"python": platform.python_version()},
                  "config": cfg}
        final_audits = {}
        for kind in models:
            print(f"[{task}/{kind}] refitting eligible development patients for lock", flush=True)
            final_cfg = deepcopy(cfg)
            if kind in {"GIFM", "TFM"}:
                epochs = [row["tuning"]["selected"].get("epochs", 40)
                          for row in audits if row["model"] == kind]
                locked_epochs = int(np.median(epochs))
                final_cfg.setdefault("candidates", {})[kind] = [
                    {**candidate, "epochs": locked_epochs} for candidate in candidates(cfg, kind)]
            fitted, audit = tuned_fit(train.branches, train.metadata.label.to_numpy(dtype=int),
                                      train.metadata.patient_id.to_numpy(), kind, final_cfg, seed)
            if kind in {"GIFM", "TFM"}:
                audit["locked_epochs_rule"] = "median of outer-training selections"
            bundle["models"][kind] = fitted
            final_audits[kind] = {**audit, "features": fitted.selection_audit()}
        joblib.dump(bundle, output / "locked_models.joblib", compress=3)
        public_manifest = {k: v for k, v in bundle.items() if k not in {"models", "training_patient_hashes"}}
        public_manifest["fitting_audit"] = final_audits
        (output / "locked_manifest.json").write_text(json.dumps(public_manifest, indent=2), encoding="utf-8")
    return predictions


def apply_locked(bundle_path, dataset, output):
    # Only load locally trusted model files. No fit, tuning or calibration occurs in this function.
    bundle = joblib.load(bundle_path)
    overlap = {identity_hash(g) for g in dataset.metadata.patient_id} & set(bundle["training_patient_hashes"])
    if overlap:
        raise ValueError(f"External inference overlaps {len(overlap)} development patient identities.")
    blocks = align_to_schema(dataset.branches, bundle["schema"])
    table = dataset.metadata.copy()
    if bundle["task"] == "tnt" and "IMET" in blocks:
        table["IMET_score"] = blocks["IMET"].iloc[:, 0].to_numpy(float)
    for name, model in bundle["models"].items():
        table[f"prob_{name}"] = model.predict(blocks)
    score = "IMET_score" if bundle["task"] == "imet" else "TNT_pCR_score"
    table[score] = table[f"prob_{bundle['primary_model']}"]
    table["prediction_scope"] = "frozen_external_inference"
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    table.to_csv(output, index=False)
    return table

