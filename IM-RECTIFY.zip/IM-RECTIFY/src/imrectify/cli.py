"""Portable entry points; public examples use only synthetic tabular data."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(prog="im-rectify")
    commands = parser.add_subparsers(dest="command", required=True)
    train = commands.add_parser("develop", help="Nested patient-level validation and development-only lock")
    train.add_argument("--config", required=True)
    train.add_argument("--output", required=True)
    train.add_argument("--no-lock", action="store_true")
    predict = commands.add_parser("predict", help="Frozen external inference; no model refitting")
    predict.add_argument("--model", required=True)
    predict.add_argument("--config", required=True)
    predict.add_argument("--output", required=True)
    evaluate = commands.add_parser("evaluate", help="AUROC, Brier, fixed-0.50 metrics and curves")
    evaluate.add_argument("--predictions", required=True)
    evaluate.add_argument("--output", required=True)
    evaluate.add_argument("--task", choices=("imet", "tnt"), required=True)
    evaluate.add_argument("--bootstrap", type=int, default=1000)
    prep = commands.add_parser("prepare", help="ADC generation and rigid T2WI-referenced registration")
    prep.add_argument("--t2", required=True)
    prep.add_argument("--mask", required=True)
    prep.add_argument("--adc")
    prep.add_argument("--adc-unit", choices=("mm2/s", "1e-3_mm2/s", "1e-6_mm2/s"), default="1e-3_mm2/s")
    prep.add_argument("--dwi")
    prep.add_argument("--bvalues", help="Comma-separated b-values in s/mm^2")
    prep.add_argument("--dce")
    prep.add_argument("--output", required=True)
    feature = commands.add_parser("extract", help="Radiomics/habitats and checkpoint-required deep extraction")
    feature.add_argument("--manifest", required=True)
    feature.add_argument("--radiomics-yaml", required=True)
    feature.add_argument("--encoder-checkpoints", help="JSON mapping modality to a trained checkpoint")
    feature.add_argument("--output", required=True)
    nnunet = commands.add_parser("nnunet-export", help="Independent manual-mask segmentation benchmark")
    nnunet.add_argument("--manifest", required=True)
    nnunet.add_argument("--output", required=True)
    interaction = commands.add_parser("interaction", help="Exploratory combined-arm score-treatment interactions")
    interaction.add_argument("--table", required=True)
    interaction.add_argument("--covariates", default="", help="Comma-separated prespecified pretreatment variables")
    interaction.add_argument("--bootstrap", type=int, default=1000)
    interaction.add_argument("--primary-score", choices=("TNT_pCR_score", "DecisionScore"), default="TNT_pCR_score")
    interaction.add_argument("--cohort-role", choices=("development", "external"), default="development")
    interaction.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.command == "develop":
        from .data import load_dataset
        from .training import develop
        develop(load_dataset(args.config), args.output, lock=not args.no_lock)
    elif args.command == "predict":
        import joblib
        from .data import load_dataset
        from .training import apply_locked
        schema = joblib.load(args.model)["schema"]
        apply_locked(args.model, load_dataset(args.config, require_label=False, required_branches=schema), args.output)
    elif args.command == "evaluate":
        import pandas as pd
        from .evaluation import evaluate
        evaluate(pd.read_csv(args.predictions, dtype={"patient_id": str}), args.output,
                 tnt_only=args.task == "tnt", bootstrap=args.bootstrap)
    elif args.command == "prepare":
        from .imaging import prepare_case
        prepare_case(args.t2, args.mask, args.output, args.adc, args.dwi,
                     [float(v) for v in args.bvalues.split(",")] if args.bvalues else None,
                     adc_unit=args.adc_unit, dce_path=args.dce)
    elif args.command == "extract":
        from .extraction import extract_manifest
        checkpoints = json.loads(Path(args.encoder_checkpoints).read_text()) if args.encoder_checkpoints else None
        extract_manifest(args.manifest, args.output, args.radiomics_yaml, checkpoints)
    elif args.command == "nnunet-export":
        from .segmentation import export_nnunet
        export_nnunet(args.manifest, args.output)
    elif args.command == "interaction":
        import pandas as pd
        from .interaction import analyse_interactions
        analyse_interactions(pd.read_csv(args.table, dtype={"patient_id": str}), args.output,
                             [x.strip() for x in args.covariates.split(",") if x.strip()], args.bootstrap,
                             primary_score=args.primary_score, cohort_role=args.cohort_role)


if __name__ == "__main__":
    main()

