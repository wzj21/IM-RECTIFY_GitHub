"""Sequential extraction of manual-mask radiomics, habitats and optional deep features."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import ndimage

from .habitats import cluster_habitats, cross_habitat_features, roi_standardize, spatial_features
from .imaging import image_like, same_geometry


def numerical_features(result):
    return {str(k): float(np.asarray(v)) for k, v in result.items()
            if not str(k).startswith("diagnostics_") and np.asarray(v).size == 1}


def extract_case(case_dir, radiomics_yaml, encoder_checkpoints=None, shell_mm=(3.0, 5.0, 10.0)):
    import SimpleITK as sitk
    from radiomics import featureextractor

    sitk.ProcessObject.SetGlobalDefaultNumberOfThreads(1)
    directory = Path(case_dir)
    status = json.loads((directory / "data_status.json").read_text(encoding="utf-8"))
    if status.get("mask_source") != "manual":
        raise ValueError("Primary modelling requires a manual tumor mask.")
    if status.get("analysis_ready") is not True:
        raise ValueError("Confirm visual registration QC and set analysis_ready=true before extracting research features.")
    mask_image = sitk.ReadImage(str(directory / "MASK.nii.gz"), sitk.sitkUInt8)
    mask = sitk.GetArrayFromImage(mask_image) > 0
    spacing = tuple(reversed(mask_image.GetSpacing()))
    images, arrays = {}, {}
    for modality, filename in {"T2WI": "T2WI.nii.gz", "ADC": "ADC.nii.gz", "DCE": "DCE_main_real.nii.gz"}.items():
        path = directory / filename
        if not path.is_file():
            if modality == "DCE":
                continue
            raise FileNotFoundError(path)
        images[modality] = sitk.ReadImage(str(path), sitk.sitkFloat32)
        if not same_geometry(images[modality], mask_image):
            raise ValueError(f"{modality} is not on the manual-mask reference grid.")
        arrays[modality] = sitk.GetArrayFromImage(images[modality])
    labels, habitat_audit = cluster_habitats(arrays, mask)
    extractor = featureextractor.RadiomicsFeatureExtractor(str(radiomics_yaml))
    outside_distance = ndimage.distance_transform_edt(~mask, sampling=spacing)
    results, errors = {}, []
    for modality in images:
        standardized = image_like(roi_standardize(arrays[modality], mask).astype(np.float32), mask_image)
        groups = {"intratumoral": {}, "peritumoral": {}, "habitat": {}, "deep": {}, "habitat_deep": {}}

        def radiomics(region, region_name):
            try:
                if region.sum() < 8:
                    raise ValueError("Fewer than eight voxels in region.")
                roi = image_like(region.astype(np.uint8), mask_image)
                return numerical_features(extractor.execute(standardized, roi))
            except (ValueError, RuntimeError) as exc:
                errors.append({"modality": modality, "region": region_name, "error": str(exc)})
                return {}

        groups["intratumoral"] = radiomics(mask, "tumor")
        previous = 0.0
        for radius in shell_mm:
            shell = (~mask) & (outside_distance > previous) & (outside_distance <= radius)
            prefix = f"shell_{previous:g}_{radius:g}mm"
            groups["peritumoral"].update({f"{prefix}__{k}": v for k, v in radiomics(shell, prefix).items()})
            previous = radius
        subregions = {i: radiomics(labels == i, f"H{i}") for i in range(1, 5)}
        for i, values in subregions.items():
            groups["habitat"].update({f"H{i}__{k}": v for k, v in values.items()})
        groups["habitat"].update(cross_habitat_features(subregions))
        if encoder_checkpoints and modality in encoder_checkpoints:
            from .encoder_io import encoder_vector, load_trained_encoder
            model, payload, digest = load_trained_encoder(encoder_checkpoints[modality])
            groups["deep"] = encoder_vector(model, arrays[modality], mask, spacing, payload["preprocessing"])
            for i in range(1, 5):
                if (labels == i).sum() >= 8:
                    vector = encoder_vector(model, arrays[modality], labels == i, spacing, payload["preprocessing"])
                    groups["habitat_deep"].update({f"H{i}__{k}": v for k, v in vector.items()})
            habitat_audit.setdefault("encoder_checkpoints_sha256", {})[modality] = digest
        results[modality] = groups
    return results, labels, {"habitats": habitat_audit, "spatial": spatial_features(labels, spacing),
                              "errors": errors, "actual_modalities": list(images)}


def extract_manifest(manifest, output, radiomics_yaml, encoder_checkpoints=None):
    import SimpleITK as sitk

    manifest = Path(manifest).resolve()
    table = pd.read_csv(manifest, dtype={"sample_id": str})
    if set(("sample_id", "case_dir")) - set(table) or table.sample_id.duplicated().any():
        raise ValueError("Imaging manifest needs unique sample_id and case_dir.")
    output = Path(output)
    rows, joint, audit = {}, [], []
    family_files = {"intratumoral": "01_intratumoral.csv", "peritumoral": "02_peritumoral.csv",
                    "habitat": "03_habitat.csv", "deep": "04_deep.csv", "habitat_deep": "05_habitat_deep.csv"}
    for record in table.to_dict("records"):
        case = manifest.parent / record["case_dir"]
        features, labels, info = extract_case(case, radiomics_yaml, encoder_checkpoints)
        for modality, groups in features.items():
            for family, values in groups.items():
                if values:
                    rows.setdefault((modality, family), []).append({"sample_id": record["sample_id"], **values})
        joint.append({"sample_id": record["sample_id"], **info["spatial"]})
        label_dir = output / "habitat_maps" / record["sample_id"]
        label_dir.mkdir(parents=True, exist_ok=True)
        template = sitk.ReadImage(str(case / "MASK.nii.gz"))
        sitk.WriteImage(image_like(labels, template), str(label_dir / "H1_H4.nii.gz"))
        audit.append({"sample_id": record["sample_id"], **info})
        print(f"[features] {record['sample_id']}: {', '.join(features)}", flush=True)
    for (modality, family), values in rows.items():
        folder = output / modality
        folder.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(values).to_csv(folder / family_files[family], index=False)
    for modality in sorted({m for m, _ in rows}):
        pieces = []
        for (name, family), values in rows.items():
            if name == modality:
                pieces.append(pd.DataFrame(values).set_index("sample_id").add_prefix(family + "__"))
        pd.concat(pieces, axis=1).reset_index().to_csv(output / modality / "all_features.csv", index=False)
    output.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(joint).to_csv(output / "habitat_spatial.csv", index=False)
    record = {"radiomics_yaml_sha256": hashlib.sha256(Path(radiomics_yaml).read_bytes()).hexdigest(),
              "status": "Deep outputs exist only when trained checkpoints were supplied.", "cases": audit}
    (output / "feature_extraction_audit.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
    return record

