"""Create explicitly synthetic inputs. No study results are reproduced by this example."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import expit


def make_cohort(folder, task, n=80, seed=42, external=False):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    ids = [f"SYN_{folder.name}_{i:04d}" for i in range(n)]
    signal = rng.normal(size=n)
    treatment = np.zeros(n, int) if task == "imet" else np.r_[np.zeros(n * 3 // 4, int), np.ones(n - n * 3 // 4, int)]
    label = rng.binomial(1, expit(0.8 * signal + 0.3 * treatment))
    clinical = pd.DataFrame({"sample_id": ids, "age": rng.normal(60, 9, n),
                             "cT": rng.choice(["T3", "T4"], n), "sex": rng.choice([0, 1], n)})
    metadata = pd.DataFrame({"sample_id": ids, "patient_id": ids, "cohort": "molecular" if task == "imet" else "external" if external else "internal",
                             "treatment": treatment, "label": label})
    metadata.to_csv(folder / "metadata.csv", index=False)
    branches = {}
    for name in ("T2WI", "ADC", "DCE"):
        matrix = rng.normal(size=(n, 12))
        matrix[:, :3] += signal[:, None] * np.array([0.9, 0.5, -0.3])[None]
        matrix[rng.random(matrix.shape) < 0.02] = np.nan
        frame = pd.DataFrame(matrix, columns=[f"feature_{j:02d}" for j in range(12)])
        frame.insert(0, "sample_id", ids)
        frame.to_csv(folder / f"{name}.csv", index=False)
        branches[name] = [{"path": f"{name}.csv", "prefix": "synthetic"}]
    if task == "tnt":
        clinical.to_csv(folder / "Clinical.csv", index=False)
        # A synthetic proxy, not an actual RNA-derived or MRI-derived study score.
        pd.DataFrame({"sample_id": ids, "IMET_score": expit(signal + rng.normal(0, 0.5, n))}).to_csv(folder / "IMET.csv", index=False)
        branches.update({"Clinical": [{"path": "Clinical.csv", "prefix": "baseline"}],
                         "IMET": [{"path": "IMET.csv", "prefix": "locked_IMET", "columns": ["IMET_score"]}]})
    models = ["EFM", "GIFM", "LFM", "TFM"] if task == "imet" else ["CM", "IMM", "EFM", "GIFM", "LFM", "TFM"]
    config = {"task": task, "metadata": "metadata.csv", "branches": branches, "models": models,
              "primary_model": "GIFM", "outer_folds": 5, "inner_folds": 2, "seed": seed,
              "feature_provenance": "synthetic_demo", "calibration": "none",
              "selection": {"correlation": 0.9, "mrmr_k": 5, "bootstraps": 2,
                            "stability": 0.5, "direction": 0.5},
              "candidates": {m: [{"epochs": 2, "hidden": 12, "latent": 8, "batch_size": 16}]
                             if m in {"GIFM", "TFM"} else [{"C": 1.0, "lasso_c": 1.0, "trees": 12}]
                             for m in models},
              "notice": "SYNTHETIC SMOKE TEST ONLY. These settings are not study hyperparameters."}
    (folder / "config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    return folder / "config.json"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="outputs/synthetic_inputs")
    args = parser.parse_args()
    root = Path(args.output)
    for name, task, seed, external in (("molecular", "imet", 42, False), ("internal", "tnt", 43, False),
                                       ("external", "tnt", 44, True)):
        print(make_cohort(root / name, task, seed=seed, external=external))


if __name__ == "__main__":
    main()

