"""One-click synthetic demonstration, including all six stage-2 model families."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from make_synthetic_data import make_cohort
from imrectify.data import load_dataset
from imrectify.evaluation import evaluate
from imrectify.training import apply_locked, develop


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="outputs/synthetic_demo")
    parser.add_argument("--stage", choices=("molecular", "tnt", "all"), default="all")
    args = parser.parse_args()
    root = Path(args.output).resolve()
    root.mkdir(parents=True, exist_ok=True)
    completed = []
    for name, task, seed in (("molecular", "imet", 42), ("internal", "tnt", 43)):
        if args.stage not in ("all", "molecular" if task == "imet" else "tnt"):
            continue
        config = make_cohort(root / "inputs" / name, task, n=80, seed=seed)
        if task == "tnt" and "molecular" in completed:
            molecular = apply_locked(root / "molecular" / "locked_models.joblib", load_dataset(config),
                                      root / name / "locked_IMET_inference.csv")
            molecular[["sample_id", "IMET_score"]].to_csv(config.parent / "IMET.csv", index=False)
        result = develop(load_dataset(config), root / name)
        evaluate(result, root / name / "evaluation", tnt_only=task == "tnt", bootstrap=100)
        completed.append(name)
    if "internal" in completed:
        external = make_cohort(root / "inputs" / "external", "tnt", n=60, seed=44, external=True)
        if "molecular" in completed:
            molecular = apply_locked(root / "molecular" / "locked_models.joblib", load_dataset(external),
                                      root / "external" / "locked_IMET_inference.csv")
            molecular[["sample_id", "IMET_score"]].to_csv(external.parent / "IMET.csv", index=False)
        prediction = apply_locked(root / "internal" / "locked_models.joblib", load_dataset(external),
                                   root / "external" / "frozen_predictions.csv")
        evaluate(prediction, root / "external" / "evaluation", bootstrap=100)
        completed.append("frozen_external_inference")
    (root / "SYNTHETIC_ONLY.json").write_text(json.dumps({
        "data": "100% generated, no real patients", "completed": completed,
        "interpretation": "Software smoke test. Do not use these metrics in the manuscript.",
    }, indent=2), encoding="utf-8")
    print(f"Synthetic demonstration complete: {root}")


if __name__ == "__main__":
    main()

