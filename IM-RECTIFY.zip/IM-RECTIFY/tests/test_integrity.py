from __future__ import annotations

import copy
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from imrectify.data import Dataset, load_dataset
from imrectify.imaging import adc_from_dwi, convert_adc_units
from imrectify.habitats import cluster_habitats, spatial_features
from imrectify.selection import BranchPreprocessor
from imrectify.training import outer_splits, tuned_fit, apply_locked


def dataset(n=60):
    rng = np.random.default_rng(5)
    label = np.tile([0, 1], n // 2)
    treatment = np.r_[np.zeros(n - 20, int), np.ones(20, int)]
    metadata = pd.DataFrame({"sample_id": [f"S{i}" for i in range(n)], "patient_id": [f"P{i}" for i in range(n)],
                             "cohort": "internal", "treatment": treatment, "label": label})
    blocks = {"T2WI": pd.DataFrame(rng.normal(size=(n, 4)), columns=[f"f{i}" for i in range(4)]),
              "Clinical": pd.DataFrame({"age": rng.normal(60, 7, n), "cT": ["T3", "T4"] * (n // 2)}),
              "IMET": pd.DataFrame({"IMET_score": rng.uniform(0, 1, n)})}
    return Dataset(metadata, blocks, {"task": "tnt"})


def test_adc_known_signal_and_units():
    b = np.array([0, 500, 1000])
    signal = np.ones((3, 4, 5, 1)) * 1000 * np.exp(-b * 0.0012)
    adc, audit = adc_from_dwi(signal, b)
    assert np.allclose(adc, 1.2, atol=1e-5)
    assert audit["invalid_signal_voxels"] == 0
    assert np.allclose(convert_adc_units(adc / 1000, "mm2/s"), adc)


def test_grouped_folds_and_ici_outcome_blindness():
    data = dataset()
    # Include a second image record for one patient: both must remain in one fold.
    data.metadata = pd.concat([data.metadata, data.metadata.iloc[[0]]], ignore_index=True)
    data.metadata.loc[len(data.metadata) - 1, "sample_id"] = "second_image_same_patient"
    first = outer_splits(data.metadata, "tnt", 5, 42)
    shuffled = data.metadata.copy()
    shuffled.loc[shuffled.treatment.eq(1), "label"] = 1 - shuffled.loc[shuffled.treatment.eq(1), "label"]
    second = outer_splits(shuffled, "tnt", 5, 42)
    for (train, test), (other_train, other_test) in zip(first, second):
        assert np.array_equal(train, other_train) and np.array_equal(test, other_test)
        assert data.metadata.treatment.iloc[train].eq(0).all()
        assert not set(data.metadata.patient_id.iloc[train]) & set(data.metadata.patient_id.iloc[test])


def test_preprocessor_frozen_at_transform():
    frame = pd.DataFrame({"family__x": [1.0, np.nan, 3, 4], "family__category": ["a", "b", "a", "a"]})
    prep = BranchPreprocessor(screen=False).fit(frame, [0, 1, 0, 1])
    means = prep.scaler_.mean_.copy()
    columns = prep.feature_names()
    result = prep.transform(pd.DataFrame({"family__x": [1000.0], "family__category": ["unknown"]}))
    assert np.isfinite(result).all()
    assert np.array_equal(means, prep.scaler_.mean_) and columns == prep.feature_names()


def test_external_inference_never_fits_and_checks_patient_identity(monkeypatch):
    import joblib
    from imrectify.data import identity_hash

    class Frozen:
        def fit(self, *args, **kwargs):
            raise AssertionError("External inference must never call fit.")

        def predict(self, blocks):
            return np.full(len(blocks["IMET"]), 0.4)

    data = dataset()
    bundle = {"task": "tnt", "primary_model": "IMM", "models": {"IMM": Frozen()},
              "schema": {"IMET": ["IMET_score"]}, "training_patient_hashes": []}
    monkeypatch.setattr(joblib, "load", lambda _: bundle)
    monkeypatch.setattr(pd.DataFrame, "to_csv", lambda *args, **kwargs: None)
    result = apply_locked("local_model", data, "predictions.csv")
    assert np.all(result.TNT_pCR_score == 0.4)
    bundle["training_patient_hashes"] = [identity_hash("P0")]
    with pytest.raises(ValueError, match="overlaps"):
        apply_locked("local_model", data, "predictions.csv")


def test_no_silent_intersection_and_no_outcome_features(monkeypatch):
    import imrectify.data as data_module
    data = dataset()
    configuration = {"metadata": "metadata.csv", "feature_provenance": "synthetic_demo",
                     "branches": {"T2WI": [{"path": "features.csv"}]}}
    monkeypatch.setattr(Path, "read_text", lambda *args, **kwargs: json.dumps(configuration))
    features = pd.DataFrame({"sample_id": data.metadata.sample_id.iloc[:-1], "x": 1.0})
    monkeypatch.setattr(data_module, "read_csv", lambda path: data.metadata.copy() if path.name == "metadata.csv" else features.copy())
    with pytest.raises(ValueError, match="lack feature rows"):
        load_dataset("config.json")
    features = pd.DataFrame({"sample_id": data.metadata.sample_id, "label": data.metadata.label})
    with pytest.raises(ValueError, match="cannot be features"):
        load_dataset("config.json")


@pytest.mark.parametrize("kind", ["CM", "IMM", "EFM", "LFM", "GIFM", "TFM"])
def test_model_fit_and_predict(kind):
    if kind in {"GIFM", "TFM"}:
        pytest.importorskip("torch")
    data = dataset()
    indices = np.arange(40)
    train = data.subset(indices)
    parameters = {"epochs": 1, "hidden": 8, "latent": 8, "trees": 5}
    config = {"inner_folds": 2, "selection": {"mrmr_k": 3, "bootstraps": 1,
                                             "stability": 0.0, "direction": 0.0},
              "candidates": {kind: [parameters]}}
    model, _ = tuned_fit(train.branches, train.metadata.label.to_numpy(), train.metadata.patient_id.to_numpy(), kind, config, 9)
    p = model.predict(data.subset(np.arange(40, 60)).branches)
    assert p.shape == (20,) and np.isfinite(p).all() and ((p >= 0) & (p <= 1)).all()


def test_four_habitats_and_physical_interfaces():
    rng = np.random.default_rng(42)
    mask = np.ones((5, 6, 7), bool)
    images = {"T2WI": rng.normal(size=mask.shape), "ADC": rng.normal(size=mask.shape)}
    labels, audit = cluster_habitats(images, mask)
    assert set(np.unique(labels)) == {1, 2, 3, 4} and audit["k"] == 4
    features = spatial_features(labels, (2, 1, 1))
    assert np.isclose(sum(features[f"H{i}__fraction"] for i in range(1, 5)), 1)
    assert features["interface__area_mm2"] > 0


def test_encoder_515_dimensions():
    torch = pytest.importorskip("torch")
    from imrectify.models.encoder import build_ta_mambanext_resnet3d
    torch.set_num_threads(1)
    model = build_ta_mambanext_resnet3d(base_channels=4, global_mixer="transformer").eval()
    image = torch.randn(1, 1, 32, 32, 32)
    mask = torch.zeros_like(image)
    mask[:, :, 8:24, 8:24, 8:24] = 1
    with torch.no_grad():
        result = model(image, mask)
    assert result.shape == (1, 515) and torch.isfinite(result).all()


def test_random_checkpoint_rejected(monkeypatch):
    torch = pytest.importorskip("torch")
    from imrectify.encoder_io import load_trained_encoder
    path = Path("random_untrained_checkpoint.pt")
    monkeypatch.setattr(torch, "load", lambda *args, **kwargs: {"state_dict": {}})
    with pytest.raises(ValueError, match="training_provenance"):
        load_trained_encoder(path)

