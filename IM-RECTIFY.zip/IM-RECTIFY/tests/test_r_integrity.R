# Base-R interface tests. Real biological and treatment-effect results are not tested here.
if (.Platform$OS.type == "windows" && !isTRUE(l10n_info()[["UTF-8"]])) {
  invisible(try(Sys.setlocale("LC_CTYPE", "Chinese (Simplified)_China.utf8"), silent = TRUE))
}
args <- commandArgs(trailingOnly = TRUE)
repo <- if (length(args)) normalizePath(args[1], mustWork = TRUE) else normalizePath(".")
files <- list.files(file.path(repo, "omics"), pattern = "\\.R$", full.names = TRUE)
invisible(lapply(files, parse))
checks <- 1L
expect_error <- function(expression) {
  value <- tryCatch({force(expression); FALSE}, error = function(e) TRUE)
  if (!value) stop("Expected validation error was not raised.")
}
hte <- new.env(parent = globalenv())
sys.source(file.path(repo, "omics", "07_treatment_effect_heterogeneity.R"), envir = hte)
pooled <- hte$pool_scalar(c(.1, .2), c(.05, .06))
stopifnot(abs(pooled["estimate"] - .15) < 1e-10, pooled["low"] < pooled["high"])
checks <- checks + 1L
set.seed(11)
d <- as.data.frame(setNames(replicate(length(hte$covariates), rbinom(40, 1, .5),
                                     simplify = FALSE), hte$covariates))
d$bmi <- runif(40, 18, 30)
d$tnt_response_score <- runif(40)
d$patient_id <- paste0("SYN_R_", seq_len(40))
d$treatment <- rep(0:1, 20)
d$pcr <- rep(c(0, 1, 1, 0), 10)
d$prediction_scope <- "patient_held_out"
hte$validate_cohort(d, development = TRUE)
bad <- d; bad$patient_id[2] <- bad$patient_id[1]
expect_error(hte$validate_cohort(bad, development = TRUE))
bad <- d; bad$prediction_scope <- "in_sample"
expect_error(hte$validate_cohort(bad, development = TRUE))
checks <- checks + 3L
design <- hte$fit_feature_design(d)
stopifnot(identical(colnames(hte$apply_feature_design(d, design)), design$columns))
bad <- d; bad$cn[1] <- 99
expect_error(hte$apply_feature_design(bad, design))
checks <- checks + 2L
expressions <- parse(file.path(repo, "omics", "08_single_cell_analysis.R"))
mapper <- new.env(parent = globalenv())
for (expression in expressions) {
  if (is.call(expression) && identical(expression[[1]], as.name("<-")) &&
      identical(expression[[2]], as.name("map_copykat_predictions"))) eval(expression, mapper)
}
prediction <- data.frame(cell.names = c("SYN_CELL_B", "SYN_CELL_A"),
                          copykat.pred = c("diploid", "aneuploid"))
mapped <- mapper$map_copykat_predictions(prediction, c("SYN_CELL_A", "SYN_CELL_B", "UNKNOWN"))
stopifnot(identical(unname(mapped), c("aneuploid", "diploid", NA_character_)))
expect_error(mapper$map_copykat_predictions(prediction, "NO_MATCH"))
checks <- checks + 2L
if (all(vapply(c("Seurat", "dplyr", "tidyr", "ggplot2"), requireNamespace,
               logical(1), quietly = TRUE))) {
  sc <- new.env(parent = globalenv())
  sys.source(file.path(repo, "omics", "08_single_cell_analysis.R"), envir = sc)
  counts <- matrix(rpois(25 * 80, 2), 25, 80,
                   dimnames = list(paste0("SYN_GENE_", 1:25), paste0("SYN_CELL_", 1:80)))
  x <- Seurat::CreateSeuratObject(counts)
  x$sample_id <- rep(paste0("SYN_SAMPLE_", 1:8), each = 10)
  x$patient_id <- rep(paste0("SYN_DONOR_", 1:4), each = 20)
  x$timepoint <- rep(rep(c("Pre", "Post"), each = 10), 4)
  x$phenotype <- rep(c("C1", "C1", "C2", "C2"), each = 20)
  x <- sc$check_input(x)
  stopifnot(setequal(x$phenotype, c("C1-like", "C2-like")))
  x$cell_state <- rep(rep(c("State_A", "State_B"), each = 5), 8)
  result <- sc$paired_composition(x, "cell_state")
  stopifnot(nrow(result$paired) == 8L, all(result$sample_proportions$percentage == 50))
  checks <- checks + 2L
  cat("SEURAT_SYNTHETIC_INTERFACE=passed\n")
} else cat("SEURAT_SYNTHETIC_INTERFACE=skipped_missing_optional_packages\n")
cat("R_CHECKS_PASSED=", checks, "\n", sep = "")
