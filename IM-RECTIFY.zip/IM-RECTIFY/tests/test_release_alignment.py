"""Publication interfaces tested only with generated, nonclinical inputs."""
import json

import numpy as np
import pandas as pd
import pytest

from imrectify.evaluation import paired_auroc_difference, summarize
from imrectify.interaction import analyse_interactions
from imrectify.selection import BranchPreprocessor


def test_all_prediction_metrics_have_bootstrap_intervals():
    result = summarize([0, 0, 1, 1, 0, 1], [0.1, 0.4, 0.7, 0.9, 0.6, 0.3], bootstrap=12)
    for metric in ("AUROC", "accuracy", "sensitivity", "specificity", "balanced_accuracy", "F1", "Brier", "precision", "NPV"):
        assert 0 <= result[metric + "_CI_low"] <= result[metric + "_CI_high"] <= 1
        assert 0 < result[metric + "_CI_valid_resamples"] <= 12


def test_evaluation_rejects_fractional_outcomes_and_misaligned_vectors():
    with pytest.raises(ValueError, match="0/1"):
        summarize([0, 1.8, 1], [0.2, 0.3, 0.8], bootstrap=1)
    with pytest.raises(ValueError, match="align"):
        summarize([0, 1], [0.2], bootstrap=1)


def test_paired_bootstrap_uses_same_patient_draws_for_both_models():
    y = np.array([0, 0, 0, 1, 1, 1])
    p = np.array([0.1, 0.2, 0.6, 0.3, 0.8, 0.9])
    result = paired_auroc_difference(y, p, p, bootstrap=20)
    assert result["AUROC_difference"] == result["CI_low"] == result["CI_high"] == 0
    assert result["valid_resamples"] == 20


def test_missingness_screen_is_learned_only_in_training():
    frame = pd.DataFrame({"good": [0, 1, 2, 3, 4], "missing": [np.nan, np.nan, 1, 2, 3]})
    prep = BranchPreprocessor(screen=False).fit(frame, [0, 1, 0, 1, 0])
    assert prep.retained_columns_ == ["good"]
    assert prep.transform(pd.DataFrame({"good": [100], "missing": [100]})).shape == (1, 1)


def test_fully_missing_branch_remains_explicit_constant():
    prep = BranchPreprocessor(screen=False).fit(pd.DataFrame({"x": [np.nan] * 4}), [0, 1, 0, 1])
    assert prep.feature_names() == ["constant_zero"]
    assert np.array_equal(prep.transform(pd.DataFrame({"x": [3, 4]})), np.zeros((2, 1)))


def interaction_input(n=150):
    rng = np.random.default_rng(710)
    score = rng.uniform(0.05, 0.95, n)
    treatment = np.tile([0, 1], n // 2)
    p = 1 / (1 + np.exp(-(-0.4 + 1.2 * score + treatment * (0.7 - 0.9 * score))))
    return pd.DataFrame({"patient_id": [f"SYN_PERSON_{i}" for i in range(n)],
                         "label": rng.binomial(1, p), "treatment": treatment,
                         "TNT_pCR_score": score, "prediction_scope": "patient_held_out"})


def test_current_primary_interaction_uses_tnt_score_without_requiring_imet(tmp_path):
    table = interaction_input()
    analyse_interactions(table, tmp_path, bootstrap=2)
    notes = json.loads((tmp_path / "analysis_notes.json").read_text())
    coefficients = pd.read_csv(tmp_path / "interaction_coefficients.csv")
    assert notes["primary_score"] == "TNT_pCR_score"
    primary = coefficients.loc[coefficients.model == "Primary", "term"]
    assert "treatment:TNT_pCR_score" in set(primary)
    assert not primary.str.contains("DecisionScore").any()


def test_interaction_rejects_fitted_development_scores(tmp_path):
    table = interaction_input()
    table["prediction_scope"] = "in_sample"
    with pytest.raises(ValueError, match="held-out"):
        analyse_interactions(table, tmp_path, bootstrap=0)
